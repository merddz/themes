<?php
// Version: 2.0; EmailTemplates

global $context, $birthdayEmails;

// Important! Before editing these language files please read the text at the top of index.english.php.
// Since all of these strings are being used in emails, numeric entities should be used.
// Do not translate anything that is between {}, they are used as replacement variables and MUST remain exactly how they are.
//   Additionally do not translate the @additioinal_parmas: line or the variable names in the lines that follow it.  You may
//   translate the description of the variable.  Do not translate @description:, however you may translate the rest of that line.
// Do not use block comments in this file, they will have special meaning.
$txt['scheduled_approval_email_topic'] = 'Aşağıdaki konular onaylanmayı bekliyor:';
$txt['scheduled_approval_email_msg'] = 'Aşağıdaki iletiler onaylanmayı bekliyor:';
$txt['scheduled_approval_email_attach'] = 'Aşağıdaki eklentiler onaylanmayı bekliyor:';
$txt['scheduled_approval_email_event'] = 'Aşağıdaki etkinlikler onaylanmayı bekliyor:';

$txt['emails'] = array(
	'resend_activate_message' => array(
		/*
			@additional_params: resend_activate_message
				REALNAME: The display name for the member receiving the email.
				USERNAME:  The user name for the member receiving the email.
				ACTIVATIONLINK:  The url link to activate the member's account.
				ACTIVATIONCODE:  The code needed to activate the member's account.
				ACTIVATIONLINKWITHOUTCODE: The url to the page where the activation code can be entered.
				FORGOTPASSWORDLINK: The url to the "forgot password" page.
			@description: 
		*/
		'subject' => '{FORUMNAME}: Hoşgeldiniz!',
		'body' => '{REALNAME}, artık sizde bir {FORUMNAME} üyesisiniz! Kullanıcı adınız {USERNAME} olarak belirlenmiştir. Eğer şifrenizi unuttuysanız aşağıdaki adresten şifrenizi sıfırlayabilirsiniz:
{FORGOTPASSWORDLINK}

Giriş yapabilmeden önce hesabınızı aktifleştirmeniz gerekmektedir. Üyeliğinizi tamamlamak için lütfen bu adrese tıklayınız:

{ACTIVATIONLINK}

Eğer yukarıdaki adres ile ilgili sorunlar yaşarsanız, {ACTIVATIONLINKWITHOUTCODE} adresini ziyaret edebilir ve "{ACTIVATIONCODE}" kodunu kullanarak üyeliğinizi aktifleştirebilirsiniz.

{REGARDS}',
	),

	'resend_pending_message' => array(
		/* 
			@additional_params: resend_pending_message
				REALNAME: The display name for the member receiving the email.
				USERNAME:  The user name for the member receiving the email.
			@description: 
		*/
		'subject' => '{FORUMNAME}: Hoşgeldiniz!',
		'body' => 'Sayın {REALNAME}, {FORUMNAME} üyeliği için yapmış olduğunuz başvuru elimize ulaşmıştır.

Kayıt olmak için kullandığınız isim: {USERNAME}.

Forum\'a giriş yapabilmeniz ve diğer özelliklerinden faydalanabilmeniz için, başvurunuzun gözden geçirilip onaylanması gerekmektedir.

{REGARDS}',
	),
	'mc_group_approve' => array(
		/*
			@additional_params: mc_group_approve
				USERNAME: The user name for the member receiving the email.
				GROUPNAME: The name of the membergroup that the user was accepted into.
			@description: The request to join a particular membergroup has been accepted.
		*/
		'subject' => 'Grup Üyelik Talebiniz Kabul Edilmiştir',
		'body' => 'Değerli {USERNAME},

{FORUMNAME} - "{GROUPNAME}" grubuna katılmak için yapmış olduğunuz başvuru incelenmiş ve üyeliğiniz onaylanmıştır.

{REGARDS}',
	),
	'mc_group_reject' => array(
		/*
			@additional_params: mc_group_reject
				USERNAME: The user name for the member receiving the email.
				GROUPNAME: The name of the membergroup that the user was rejected from.
			@description: The request to join a particular membergroup has been rejected.
		*/
		'subject' => 'Grup Üyelik Talebiniz Reddedilmiştir',
		'body' => 'Sayın {USERNAME},

{FORUMNAME} - "{GROUPNAME}" grubuna katılmak için yapmış olduğunuz başvuru incelenmiş ve talebiniz reddedilmiştir.

{REGARDS}',
	),
	'mc_group_reject_reason' => array(
		/*
			@additional_params: mc_group_reject_reason
				USERNAME: The user name for the member receiving the email.
				GROUPNAME: The name of the membergroup that the user was rejected from.
				REASON: Reason for the rejection.
			@description: The request to join a particular membergroup has been rejected with a reason given.
		*/
		'subject' => 'Grup Üyelik Talebiniz Reddedilmiştir',
		'body' => 'Sayın {USERNAME},

{FORUMNAME} - "{GROUPNAME}" grubuna katılmak için yapmış olduğunuz başvuru incelenmiş ve talebiniz reddedilmiştir.

Reddedilme sebebiniz: {REASON}

{REGARDS}',
	),
	'admin_approve_accept' => array(
		/*
			@additional_params: admin_approve_accept
				NAME: The display name of the member.
				USERNAME: The user name for the member receiving the email.
				PROFILELINK: The URL of the profile page.
				FORGOTPASSWORDLINK: The URL of the "forgot password" page.
			@description:
		*/
		'subject' => '{FORUMNAME}: Hoşgeldiniz!',
		'body' => 'Hoşgeldiniz, {USERNAME}!

Üyelik talebiniz yöneticiler tarafından gözden geçirilmiş ve aktifleştirilmiştir. Kullanıcı adınız: {USERNAME}

Eğer şifrenizi unuttuysanız aşağıdaki adresten şifrenizi sıfırlayabilirsiniz:
{FORGOTPASSWORDLINK}

{REGARDS}',
	),
	'admin_approve_activation' => array(
		/*
			@additional_params: admin_approve_activation
				USERNAME: The user name for the member receiving the email.
				ACTIVATIONLINK:  The url link to activate the member's account.
				ACTIVATIONLINKWITHOUTCODE: The url to the page where the activation code can be entered.
				ACTIVATIONCODE: The activation code.
			@description:
		*/
		'subject' => '{FORUMNAME}: Hoşgeldiniz!',
		'body' => 'Welcome, {USERNAME}!

{FORUMNAME} için yapmış olduğunuz üyelik talebi yöneticiler tarafından gözden geçirilmiş ve onaylanmıştır. Giriş yapmadan önce üyeliğinizi aktifleştirmeniz gerekmektedir.  Hesabınızı aktifleştirmek için lütfen aşağıdaki bağlantıya tıklayınız:
{ACTIVATIONLINK}

Eğer yukarıdaki adres ile ilgili sorunlar yaşarsanız, {ACTIVATIONLINKWITHOUTCODE} adresini ziyaret edebilir ve "{ACTIVATIONCODE}" kodunu kullanarak üyeliğinizi aktifleştirebilirsiniz.

{REGARDS}',
	),
	'admin_approve_reject' => array(
		/*
			@additional_params: admin_approve_reject
				USERNAME: The user name for the member receiving the email.
			@description:
		*/
		'subject' => 'Üyeliğiniz Reddedilmiştir',
		'body' => '{USERNAME},

Üzgünüz fakat {FORUMNAME} için yapmış olduğunuz üyelik başvurusu reddedilmiştir.

{REGARDS}',
	),
	'admin_approve_delete' => array(
		/*
			@additional_params: admin_approve_delete
				USERNAME: The user name for the member receiving the email.
			@description:
		*/
		'subject' => 'Hesabınız Silinmiştir',
		'body' => '{USERNAME},

{FORUMNAME} de/da bulunan hesabınız silinmiştir.  Silinmenin sebebi üyeliğinizi aktifleştirmemiş olmanız olabilir.

{REGARDS}',
	),
	'admin_approve_remind' => array(
		/*
			@additional_params: admin_approve_remind
				USERNAME: The user name for the member receiving the email.
				ACTIVATIONLINK:  The url link to activate the member's account.
				ACTIVATIONLINKWITHOUTCODE: The url to the page where the activation code can be entered.
				ACTIVATIONCODE: The activation code.
			@description:
		*/
		'subject' => 'Kayıt Hatırlatması',
		'body' => '{USERNAME},
{FORUMNAME} için yapmış olduğunuz üyelik kaydını hala aktifleştirmemiş bulunmaktasınız.

Lütfen hesabınızı aktifleştirmek için aşağıdaki bağlantıya tıklayınız:
{ACTIVATIONLINK}

{REGARDS}',
	),
	'admin_register_activate' => array(
		/*
			@additional_params:
				USERNAME: The user name for the member receiving the email.
				ACTIVATIONLINK:  The url link to activate the member's account.
				ACTIVATIONLINKWITHOUTCODE: The url to the page where the activation code can be entered.
				ACTIVATIONCODE: The activation code.
			@description:
		*/
		'subject' => '{FORUMNAME}: Hoşgeldiniz!',
		'body' => 'Artık sizde bir {FORUMNAME} üyesisiniz! Kullanıcı adınız: {USERNAME} ve şifreniz: {PASSWORD} olarak belirlenmiştir.

Giriş yapmadan önce aşağıdaki bağlantıdan üyeliğinizi aktifleştirin:

{ACTIVATIONLINK}

Eğer aktivasyon bağlantısıyla ilgili bir probleminiz olursa, lütfen {ACTIVATIONLINKWITHOUTCODE} adresine girin ve "{ACTIVATIONCODE}" kodunu girin.

{REGARDS}',
	),
	'admin_register_immediate' => array(
		'subject' => '{FORUMNAME}: Hoşgeldiniz!',
		'body' => 'Artık sizde bir {FORUMNAME} üyesisiniz! Kullanıcı adınız: {USERNAME} ve şifreniz: {PASSWORD} olarak belirlenmiştir.

{REGARDS}',
	),
	'new_announcement' => array(
		/*
			@additional_params: new_announcement
				TOPICSUBJECT: The subject of the topic being announced.
				MESSAGE: The message body of the first post of the announced topic.
				TOPICLINK: A link to the topic being announced.
			@description:

		*/
		'subject' => 'Duyuru: {TOPICSUBJECT}',
		'body' => '{MESSAGE}

Eğer gelecekte duyuru iletileri almak istemiyorsanız, bu seçeneği profilinizde bulunan "Duyuru" bölümünü kullanarak kolayca yapabilirsiniz.

Duyurunun tümünü aşağıdaki bağlantıyı kullanarak görüntüleyebilirsiniz:
{TOPICLINK}

{REGARDS}',
	),
	'notify_boards_once_body' => array(
		/*
			@additional_params: notify_boards_once_body
				TOPICSUBJECT: The subject of the topic causing the notification
				TOPICLINK: A link to the topic.
				MESSAGE: This is the body of the message.
				UNSUBSCRIBELINK: Link to unsubscribe from notifications.
			@description:
		*/
		'subject' => 'Yeni Konu: {TOPICSUBJECT}',
		'body' => 'Haberdar edilmeyi seçtiğiniz bir bölümde, \'{TOPICSUBJECT}\' başlıklı bir konu açılmıştır.

Konuyu görüntülemek için aşağıdaki bağlantıya tıklayınız:
{TOPICLINK}

Bu bölümde daha fazla konu açılsa bile bu konuyu görüntülemezseniz, bölümle ilgili yeni bir duyuru gelmeyecektir.

Konunun metni:
{MESSAGE}

Bu bölümden daha fazla duyuru almak istemiyorsanız, aşağıdaki bağlantıya tıklayınız:
{UNSUBSCRIBELINK}

{REGARDS}',
	),
	'notify_boards_once' => array(
		/*
			@additional_params: notify_boards_once
				TOPICSUBJECT: The subject of the topic causing the notification
				TOPICLINK: A link to the topic.
				UNSUBSCRIBELINK: Link to unsubscribe from notifications.
			@description:
		*/
		'subject' => 'Yeni Konu: {TOPICSUBJECT}',
		'body' => 'Haberdar edilmeyi seçtiğiniz bir bölümde, \'{TOPICSUBJECT}\' başlıklı bir konu açılmıştır.

Konuyu görüntülemek için aşağıdaki bağlantıya tıklayınız:
{TOPICLINK}

Bu konuyu okumadığınız takdirde bu bölüme gönderilen yeni konulardan haberdar edilmeyeceksiniz.

Bu bölümden daha fazla duyuru almak istemiyorsanız, aşağıdaki bağlantıya tıklayınız:
{UNSUBSCRIBELINK}

{REGARDS}',
	),
	'notify_boards_body' => array(
		/*
			@additional_params: notify_boards_body
				TOPICSUBJECT: The subject of the topic causing the notification
				TOPICLINK: A link to the topic.
				MESSAGE: This is the body of the message.
				UNSUBSCRIBELINK: Link to unsubscribe from notifications.
			@description:
		*/
		'subject' => 'Yeni Konu: {TOPICSUBJECT}',
		'body' => 'Haberdar edilmeyi seçtiğiniz bir bölümde, \'{TOPICSUBJECT}\' başlıklı bir konu açılmıştır

Konuyu görüntülemek için aşağıdaki bağlantıya tıklayınız:
{TOPICLINK}

Konunun metni:
{MESSAGE}

Bu bölümden daha fazla duyuru almak istemiyorsanız, aşağıdaki bağlantıya tıklayınız:
{UNSUBSCRIBELINK}

{REGARDS}',
	),
	'notify_boards' => array(
		/*
			@additional_params: notify_boards
				TOPICSUBJECT: The subject of the topic causing the notification
				TOPICLINK: A link to the topic.
				UNSUBSCRIBELINK: Link to unsubscribe from notifications.
			@description:
		*/
		'subject' => 'Yeni Konu: {TOPICSUBJECT}',
		'body' => 'Haberdar edilmeyi seçtiğiniz bir bölümde, \'{TOPICSUBJECT}\' başlıklı bir konu açılmıştır.

Konuyu görüntülemek için aşağıdaki bağlantıya tıklayınız:
{TOPICLINK}

Bu bölümden daha fazla duyuru almak istemiyorsanız, aşağıdaki bağlantıya tıklayınız:
{UNSUBSCRIBELINK}

{REGARDS}',
	),
	'request_membership' => array(
		/*
			@additional_params: request_membership
				RECPNAME: The name of the person recieving the email
				APPYNAME: The name of the person applying for group membership
				GROUPNAME: The name of the group being applied to.
				REASON: The reason given by the applicant for wanting to join the group.
				MODLINK: Link to the group moderation page.
			@description:
		*/
		'subject' => 'Yeni Grup Başvurusu',
		'body' => '{RECPNAME},
		
{APPYNAME}, "{GROUPNAME}" adlı gruba katılmak için başvuruda bulunmuştur. Üyenin katılmak için belirttiği sebep aşağıdadır:

{REASON}

Aşağıdaki bağlantıya tıklarayak başvuruyu reddedebilir veya kabul edebilirsiniz:

{MODLINK}

{REGARDS}',
	),
	'paid_subscription_reminder' => array(
		/*
			@additional_params: scheduled_approval
				REALNAME: The real (display) name of the person receiving the email.
				PROFILE_LINK: Link to profile of member receiving email where can renew.
				SUBSCRIPTION: Name of the subscription.
				END_DATE: Date it expires.
			@description:
		*/
		'subject' => '{FORUMNAME} Sitesindeki Aboneliğiniz Sona Erecektir',
		'body' => '{REALNAME},

{FORUMNAME} sitesindeki aboneliğiniz sona ermek üzeredir. Eğer otomatik yenilemeyi aktif ettiyseniz herhangi bir işlem yapmanıza gerek yoktur fakat diğer durumlarda siteye girip ücretli abonelikler bölümünden aboneliğinizin süresini artırmanız gerekmektedir. Detaylı bilgi:

Abonelik Adı: {SUBSCRIPTION}
Süresinin Dolacağı Tarih: {END_DATE}

Ücretli aboneliklerinizi düzenlemek için şu adresi ziyaret ediniz:
{PROFILE_LINK}

{REGARDS}',
	),
	'activate_reactivate' => array(
		/*
			@additional_params: activate_reactivate
				ACTIVATIONLINK:  The url link to reactivate the member's account.
				ACTIVATIONCODE:  The code needed to reactivate the member's account.
				ACTIVATIONLINKWITHOUTCODE: The url to the page where the activation code can be entered.
			@description: 
		*/
		'subject' => '{FORUMNAME}: Tekrar Hoşgeldiniz!',
		'body' => 'E-Posta adresinizin tekrar onaylanabilmesi için üyeliğiniz devre dışı bırakılmıştır.  Üyeliğinizi tekrar aktifleştirmek için aşağıdaki bağlantıya tıklayınız:
{ACTIVATIONLINK}

Eğer yukarıdaki adres ile ilgili sorunlar yaşarsanız, {ACTIVATIONLINKWITHOUTCODE} adresini ziyaret edebilir ve "{ACTIVATIONCODE}" kodunu kullanarak üyeliğinizi aktifleştirebilirsiniz.

{REGARDS}',
	),
	'forgot_password' => array(
		/*
			@additional_params: forgot_password
				REALNAME: The real (display) name of the person receiving the reminder.
				REMINDLINK: The link to reset the password.
				IP: The IP address of the requester.
				MEMBERNAME: 
			@description: 
		*/
		'subject' => '{FORUMNAME} İçin Yeni Parola',
		'body' => 'Sayın {REALNAME},
Bu e-posta, forum\'da bulunan \'Şifremi Unuttum\' fonksiyonu kullanıldığı için gönderilmiştir. Yeni bir şifre atamak için lütfen aşağıdaki adrese tıklayınız:
{REMINDLINK}

IP: {IP}
Kullanıcı Adı: {MEMBERNAME}

{REGARDS}',
	),
	'forgot_openid' => array(
		/*
			@additional_params: forgot_password
				REALNAME: The real (display) name of the person receiving the reminder.
				IP: The IP address of the requester.
				OPENID: The members OpenID identity.
			@description:
		*/
		'subject' => '{FORUMNAME} İçin OpenID Hatırlatması',
		'body' => 'Sayın {REALNAME},
Bu e-posta adresi OpenID\'nin unutulduğuna dair işlemde bulunulduğu için gönderilmiştir. Hesabınız ile ilişkilendirilmiş OpenID aşağıda bulunmaktadır:
{OPENID}

IP: {IP}
Kullanıcı Adı: {MEMBERNAME}

{REGARDS}',
	),
	'scheduled_approval' => array(
		/*
			@additional_params: scheduled_approval
				REALNAME: The real (display) name of the person receiving the email.
				BODY: The generated body of the mail.
			@description:
		*/
		'subject' => '{FORUMNAME}: Onay Bekleyen Konuların Özeti',
		'body' => '{REALNAME},
		
Bu e-posta onay bekleyen tüm ileti ve konuları içermektedir.

{BODY}

İncelemek için lütfen giriş yapınız:
{SCRIPTURL}

{REGARDS}',
	),
	'send_topic' => array(
		/*
			@additional_params: send_topic
				TOPICSUBJECT: The subject of the topic being sent.
				SENDERNAME: The name of the member sending the topic.
				RECPNAME: The name of the person receiving the email.
				TOPICLINK: A link to the topic being sent.
			@description:
		*/
		'subject' => 'Konu: {TOPICSUBJECT} (Gönderen: {SENDERNAME})',
		'body' => 'Değerli {RECPNAME},
{FORUMNAME} da bulunan "{TOPICSUBJECT}" başlıklı konuyu görtüntülemenizi rica etmekteyim:

{TOPICLINK}

Teşekkürler,

{SENDERNAME}',
	),
	'send_topic_comment' => array(
		/*
			@additional_params: send_topic_comment
				TOPICSUBJECT: The subject of the topic being sent.
				SENDERNAME: The name of the member sending the topic.
				RECPNAME: The name of the person receiving the email.
				TOPICLINK: A link to the topic being sent.
				COMMENT: A comment left by the sender.
			@description:
		*/
		'subject' => 'Konu: {TOPICSUBJECT} (Gönderen: {SENDERNAME})',
		'body' => 'Değerli {RECPNAME},
{FORUMNAME} da bulunan "{TOPICSUBJECT}" başlıklı konuyu görtüntülemenizi rica etmekteyim:

{TOPICLINK}

Konu ile ilgili yorumum:
{COMMENT}

Teşekkürler,

{SENDERNAME}',
	),
	'send_email' => array(
		/*
			@additional_params: send_email
				EMAILSUBJECT: The subject the user wants to email.
				EMAILBODY: The body the user wants to email.
				SENDERNAME: The name of the member sending the email.
				RECPNAME: The name of the person receiving the email.
			@description:
		*/
		'subject' => '{EMAILSUBJECT}',
		'body' => '{EMAILBODY}',
	),
	'report_to_moderator' => array(
		/* 
			@additional_params: report_to_moderator
				TOPICSUBJECT: The subject of the reported post.
				POSTERNAME: The report post's author's name.
				REPORTERNAME: The name of the person reporting the post.
				TOPICLINK: The url of the post that is being reported.
				REPORTLINK: The url of the moderation center report.
				COMMENT: The comment left by the reporter, hopefully to explain why they are reporting the post.
			@description: When a user reports a post this email is sent out to moderators and admins of that board.
		*/
		'subject' => 'Rapor Edilen İleti: {TOPICSUBJECT} - {POSTERNAME}',
		'body' => 'Yöneticisi olduğunuz bir bölümde bulunan, {POSTERNAME} adlı kullanıcının göndermiş olduğu "{TOPICSUBJECT}" başlıklı konu, {REPORTERNAME} tarafından rapor edilmiştir:

Konu: {TOPICLINK}
Moderasyon Merkezi: {REPORTLINK}

Rapor Sebebi:
{COMMENT}

{REGARDS}',
	),
	'change_password' => array(
		/*
			@additional_params: change_password
				USERNAME: The user name for the member receiving the email.
				PASSWORD: The password for the member.
			@description:
		*/
		'subject' => 'Yeni Şifreniz',
		'body' => 'Merhaba, {USERNAME}!

{FORUMNAME} da bulunan üyeliğiniz ile bilgiler değiştirilmiş ve şifreniz sıfırlanmıştır. Yeni kullanıcı detaylarınız aşağıdadır:

Şifreniz "{PASSWORD}" olarak değiştirilmiştir.

Şifrenizi giriş yaptıktan sonra profil sayfanıza giderek değiştirebilirsiniz:
{SCRIPTURL}?action=profile

{REGARDS}',
	),
	'register_activate' => array(
		/*
			@additional_params: register_activate
				REALNAME: The display name for the member receiving the email.
				USERNAME: The user name for the member receiving the email.
				PASSWORD: The password for the member.
				ACTIVATIONLINK:  The url link to reactivate the member's account.
				ACTIVATIONLINKWITHOUTCODE: The url to the page where the activation code can be entered.
				ACTIVATIONCODE:  The code needed to reactivate the member's account.
				FORGOTPASSWORDLINK: The url to the "forgot password" page.
			@description:
		*/
		'subject' => '{FORUMNAME}: Hoşgeldiniz!',
		'body' => 'Artık sizde bir {FORUMNAME} üyesisiniz! Kullanıcı adınız {USERNAME} ve şifreniz {PASSWORD} olarak belirlenmiştir.

Giriş yapabilmeden önce hesabınızı aktifleştirmeniz gerekmektedir. Üyeliğinizi tamamlamak için lütfen bu adrese tıklayınız:

{ACTIVATIONLINK}

Eğer yukarıdaki adres ile ilgili sorunlar yaşarsanız, {ACTIVATIONLINKWITHOUTCODE} adresini ziyaret edebilir ve "{ACTIVATIONCODE}" kodunu kullanarak üyeliğinizi aktifleştirebilirsiniz.

{REGARDS}',
	),
	'register_openid_activate' => array(
		/*
			@additional_params: register_activate
				REALNAME: The display name for the member receiving the email.
				USERNAME: The user name for the member receiving the email.
				OPENID: The openID identity for the member.
				ACTIVATIONLINK:  The url link to reactivate the member's account.
				ACTIVATIONLINK:  The url link to reactivate the member's account.
				ACTIVATIONCODE:  The code needed to reactivate the member's account.
			@description:
		*/
		'subject' => '{FORUMNAME}: Hoşgeldiniz!',
		'body' => 'Artık sizde bir {FORUMNAME} üyesisiniz! Kullanıcı adınız {USERNAME} olarak belirlemiştir ve aşağıdaki OpenID ile doğrulama yapmayı seçmiş bulunuyorsunuz:
{OPENID}

Giriş yapabilmeden önce hesabınızı aktifleştirmeniz gerekmektedir. Üyeliğinizi tamamlamak için lütfen bu adrese tıklayınız:

{ACTIVATIONLINK}

Eğer yukarıdaki adres ile ilgili sorunlar yaşarsanız, {ACTIVATIONLINKWITHOUTCODE} adresini ziyaret edebilir ve "{ACTIVATIONCODE}" kodunu kullanarak üyeliğinizi aktifleştirebilirsiniz.

{REGARDS}',
	),
	'register_coppa' => array(
		/*
			@additional_params: register_coppa
				REALNAME: The display name for the member receiving the email.
				USERNAME: The user name for the member receiving the email.
				PASSWORD: The password for the member.
				COPPALINK:  The url link to the coppa form.
			@description:
		*/
		'subject' => '{FORUMNAME}: Hoşgeldiniz!',
		'body' => 'Artık sizde bir {FORUMNAME} üyesisiniz! Kullanıcı adınız {USERNAME} ve şifreniz {PASSWORD} olarak belirlenmiştir.

Giriş yapabilmeden önce veli onayı gerekmektedir:

{COPPALINK}

{REGARDS}',
	),
	'register_openid_coppa' => array(
		/*
			@additional_params: register_coppa
				REALNAME: The display name for the member receiving the email.
				USERNAME: The user name for the member receiving the email.
				OPENID: The openID identity for the member.
				COPPALINK:  The url link to the coppa form.
			@description:
		*/
		'subject' => '{FORUMNAME}: Hoşgeldiniz!',
		'body' => 'Artık sizde bir {FORUMNAME} üyesisiniz! Kullanıcı adınız {USERNAME} olarak belirleniştir ve aşağıdaki OpenID ile doğrulama yapmayı seçmiş bulunuyorsunuz:
{OPENID}

Giriş yapmadan önce veli onayı gerekmektedir:

{COPPALINK}

{REGARDS}',
	),
	'register_immediate' => array(
		/*
			@additional_params: register_immediate
				REALNAME: The display name for the member receiving the email.
				USERNAME: The user name for the member receiving the email.
				PASSWORD: The password for the member.
				FORGOTPASSWORDLINK: The url to the "forgot password" page.
			@description:
		*/
		'subject' => '{FORUMNAME}: Hoşgeldiniz!',
		'body' => 'Artık sizde bir {FORUMNAME} üyesisiniz! Kullanıcı adınız: {USERNAME} olarak belirlenmiştir. Eğer şifrenizi unuttuysanız, {FORGOTPASSWORDLINK} adresinden değiştirebilirsiniz.
{REGARDS}',
	),
	'register_openid_immediate' => array(
		/*
			@additional_params: register_immediate
				REALNAME: The display name for the member receiving the email.
				USERNAME: The user name for the member receiving the email.
				OPENID: The openID identity for the member.
			@description:
		*/
		'subject' => '{FORUMNAME}: Hoşgeldiniz!',
		'body' => 'Artık sizde bir {FORUMNAME} üyesisiniz! Kullanıcı adınız: {USERNAME} olarak belirlenmiştir. Eğer şifrenizi unuttuysanız, {FORGOTPASSWORDLINK} adresinden değiştirebilirsiniz.

Aşağıdaki OpenID ile doğrulama yapmayı seçmiş bulunuyorsunuz
{OPENID}

Şifrenizi giriş yaptıktan sonra profil sayfanıza giderek değiştirebilirsiniz:

{SCRIPTURL}?action=profile

{REGARDS}'
	),
	'register_pending' => array(
		/*
			@additional_params: register_pending
				REALNAME: The display name for the member receiving the email.
				USERNAME: The user name for the member receiving the email.
				FORGOTPASSWORDLINK: The url to the "forgot password" page.
				PASSWORD: The password for the member.
			@description:
		*/
		'subject' => '{FORUMNAME}: Hoşgeldiniz!',
		'body' => 'Sayın {REALNAME}, {FORUMNAME} üyeliği için yapmış olduğunuz başvuru elimize ulaşmıştır.

Kayıt olmak için kullandığınız isim {USERNAME} ve şifreniz {PASSWORD} olarak belirlenmiştir.

Forum\'a giriş yapabilmeniz ve diğer özelliklerinden faydalanabilmeniz için, başvurunuzun gözden geçirilip onaylanması gerekmektedir.

{REGARDS}',
	),
	'register_openid_pending' => array(
		/*
			@additional_params: register_pending
				REALNAME: The display name for the member receiving the email.
				USERNAME: The user name for the member receiving the email.
				OPENID: The openID identity for the member.
			@description:
		*/
		'subject' => '{FORUMNAME}: Hoşgeldiniz!',
		'body' => 'Sayın {REALNAME}, {FORUMNAME} üyeliği için yapmış olduğunuz başvuru elimize ulaşmıştır.

Kayıt olmak için kullandığınız isim: {USERNAME} olarak belirlenmiştir.

Aşağıdaki OpenID ile doğrulama yapmayı seçmiş bulunuyorsunuz
{OPENID}

Forum\'a giriş yapabilmeniz ve diğer özelliklerinden faydalanabilmeniz için, başvurunuzun gözden geçirilip onaylanması gerekmektedir.

{REGARDS}',
	),
	'notification_reply' => array(
		/*
			@additional_params: notification_reply
				TOPICSUBJECT:
				POSTERNAME:
				TOPICLINK:
				UNSUBSCRIBELINK:
			@description:
		*/
		'subject' => 'Yanıt: {TOPICSUBJECT}',
		'body' => 'Haberdar edilmeyi seçtiğiniz {TOPICSUBJECT} başlıklı konuya, {POSTERNAME} tarafından yanıt verilmiştir.

Yanıtı görüntüleyin: {TOPICLINK}

Bu bağlantıyı kullanarak aboneliğinizi iptal edin: {UNSUBSCRIBELINK}

{REGARDS}',
	),
	'notification_reply_body' => array(
		/*
			@additional_params: notification_reply_body
				TOPICSUBJECT:
				POSTERNAME:
				TOPICLINK:
				UNSUBSCRIBELINK:
				MESSAGE: 
			@description:
		*/
		'subject' => 'Yanıt: {TOPICSUBJECT}',
		'body' => 'Haberdar edilmeyi seçtiğiniz {TOPICSUBJECT} başlıklı konuya, {POSTERNAME} tarafından yanıt verilmiştir.

Yanıtı görüntüleyin: {TOPICLINK}

Bu bağlantıyı kullanarak aboneliğinizi iptal edin: {UNSUBSCRIBELINK}

Yanıtın metni:
{MESSAGE}

{REGARDS}',
	),
	'notification_reply_once' => array(
		/*
			@additional_params: notification_reply_once
				TOPICSUBJECT:
				POSTERNAME:
				TOPICLINK:
				UNSUBSCRIBELINK:
			@description:
		*/
		'subject' => 'Yanıt: {TOPICSUBJECT}',
		'body' => 'Haberdar edilmeyi seçtiğiniz {TOPICSUBJECT} başlıklı konuya, {POSTERNAME} tarafından yanıt verilmiştir.

Yanıtı görüntüleyin: {TOPICLINK}

Bu bağlantıyı kullanarak aboneliğinizi iptal edin: {UNSUBSCRIBELINK}

Bu konuya daha fazla yanıt verilse bile, konuyu görüntülemezseniz, konuyla ilgili yeni bir duyuru gelmeyecektir.

{REGARDS}',
	),
	'notification_reply_body_once' => array(
		/*
			@additional_params: notification_reply_body_once
				TOPICSUBJECT:
				POSTERNAME:
				TOPICLINK:
				UNSUBSCRIBELINK:
				MESSAGE: 
			@description:
		*/
		'subject' => 'Yanıt: {TOPICSUBJECT}',
		'body' => 'Haberdar edilmeyi seçtiğiniz {TOPICSUBJECT} başlıklı konuya, {POSTERNAME} tarafından yanıt verilmiştir.

Yanıtı görüntüleyin: {TOPICLINK}

Bu bağlantıyı kullanarak aboneliğinizi iptal edin: {UNSUBSCRIBELINK}

Yanıtın metni:
{MESSAGE}

Bu konuya daha fazla yanıt verilse bile, konuyu görüntülemezseniz, konuyla ilgili yeni bir duyuru gelmeyecektir.

{REGARDS}',
	),
	'notification_sticky' => array(
		/*
			@additional_params: notification_sticky
			@description:
		*/
		'subject' => 'Konu Sabitlenmiştir: {TOPICSUBJECT}',
		'body' => 'Haberdar edilmeyi seçtiğiniz {TOPICSUBJECT} başlıklı konu, {POSTERNAME} tarafından sabitlenmiştir.

Konuyu görüntüleyin: {TOPICLINK}

Bu bağlantıyı kullanarak aboneliğinizi iptal edin: {UNSUBSCRIBELINK}

{REGARDS}',
	),
	'notification_lock' => array(
		/*
			@additional_params: notification_lock
			@description:
		*/
		'subject' => 'Konu Kilitlenmiştir: {TOPICSUBJECT}',
		'body' => 'Haberdar edilmeyi seçtiğiniz {TOPICSUBJECT} başlıklı konu, {POSTERNAME} tarafından kilitlenmiştir.

Konuyu görüntüleyin: {TOPICLINK}

Bu bağlantıyı kullanarak aboneliğinizi iptal edin: {UNSUBSCRIBELINK}

{REGARDS}',
	),
	'notification_unlock' => array(
		/*
			@additional_params: notification_unlock
			@description:
		*/
		'subject' => 'Konu Kilidi Kaldırılmıştır: {TOPICSUBJECT}',
		'body' => 'Haberdar edilmeyi seçtiğiniz {TOPICSUBJECT} başlıklı konuya ait kilit, {POSTERNAME} tarafından kaldırılmıştır.

Konuyu görüntüleyin: {TOPICLINK}

Bu bağlantıyı kullanarak aboneliğinizi iptal edin: {UNSUBSCRIBELINK}

{REGARDS}',
	),
	'notification_remove' => array(
		/*
			@additional_params: notification_remove
			@description:
		*/
		'subject' => 'Konu Kaldırılmıştır: {TOPICSUBJECT}',
		'body' => 'Haberdar edilmeyi seçtiğiniz {TOPICSUBJECT} başlıklı konu, {POSTERNAME} tarafından kaldırılmıştır.

{REGARDS}',
	),
	'notification_move' => array(
		/*
			@additional_params: notification_move
			@description:
		*/
		'subject' => 'Konu Taşınmıştır: {TOPICSUBJECT}',
		'body' => 'Haberdar edilmeyi seçtiğiniz {TOPICSUBJECT} başlıklı konu, {POSTERNAME} tarafından başka bir bölüme taşınmıştır.

Konuyu görüntüleyin: {TOPICLINK}

Bu bağlantıyı kullanarak aboneliğinizi iptal edin: {UNSUBSCRIBELINK}

{REGARDS}',
	),
	'notification_merge' => array(
		/*
			@additional_params: notification_merged
			@description:
		*/
		'subject' => 'Konu Birleştirildi: {TOPICSUBJECT}',
		'body' => 'Haberdar edilmeyi seçtiğiniz {TOPICSUBJECT} başlıklı konu, {POSTERNAME} tarafından başka bir konu ile birleştirilmiştir.

Birleştirilen konuyu görüntüleyin: {TOPICLINK}

Bu bağlantıyı kullanarak aboneliğinizi iptal edin: {UNSUBSCRIBELINK}

{REGARDS}',
	),
	'notification_split' => array(
		/*
			@additional_params: notification_split
			@description:
		*/
		'subject' => 'Konu Bölündü: {TOPICSUBJECT}',
		'body' => 'Haberdar edilmeyi seçtiğiniz {TOPICSUBJECT} başlıklı konu, {POSTERNAME} tarafından bölünmüştür.

Konudan kalanları görüntüleyin: {TOPICLINK}

Bu bağlantıyı kullanarak aboneliğinizi iptal edin: {UNSUBSCRIBELINK}

{REGARDS}',
	),
	'admin_notify' => array(
		/*
			@additional_params: admin_notify
				USERNAME: 
				PROFILELINK: 
			@description:
		*/
		'subject' => 'Yeni Üye Kaydı',
		'body' => '{USERNAME} adlı üye forum\'a kayıt olmuştur. Profilini görüntülemek için lütfen aşağıdaki bağlantıya tıklayınız:
{PROFILELINK}

{REGARDS}',
	),
	'admin_notify_approval' => array(
		/*
			@additional_params: admin_notify_approval
				USERNAME: 
				PROFILELINK: 
				APPROVALLINK: 
			@description:
		*/
		'subject' => 'Yeni Üye Kaydı',
		'body' => '{USERNAME} adlı üye forum\'a kayıt olmuştur. Profilini görüntülemek için lütfen aşağıdaki bağlantıya tıklayınız:
{PROFILELINK}

Bu üyenin ileti göndermeye başlamadan önce hesabının onaylanması gerekmektedir. Onay ekranına gitmek için lütfen aşağıdaki bağlantıya tıklayınız:
{APPROVALLINK}

{REGARDS}',
	),
	'admin_attachments_full' => array(
		/*
			@additional_params: admin_attachments_full
				REALNAME:
			@description:
		*/
		'subject' => 'Acil! Eklenti Klasörü Neredeyse Dolmuştur',
		'body' => '{REALNAME},

{FORUMNAME} adresindeki eklenti klasörü neredeyse dolmuştur.

Eklenti klasörü limitine yaklaştığında üyeler yeni dosya eklentileri veya kişisel avatarlar gönderemeyeceklerdir.

{REGARDS}',
	),
	'paid_subscription_refund' => array(
		/*
			@additional_params: paid_subscription_refund
				NAME: Subscription title.
				REALNAME: Recipients name
				REFUNDUSER: Username who took out the subscription.
				REFUNDNAME: User's display name who took out the subscription.
				DATE: Today's date.
				PROFILELINK: Link to members profile.
			@description:
		*/
		'subject' => 'Geri Ödenen Ücretli Abonelik',
		'body' => '{REALNAME},

Bir üye, bir ücretli abonelik için geri ödeme almıştır. İlgili detaylar aşağıdadır:

	Abonelik: {NAME}
	Kullanıcı Adı: {REFUNDNAME} ({REFUNDUSER})
	Tarih: {DATE}

Bu üyenin profilini görüntülemek için aşağıdaki bağlantıya tıklayabilirsiniz:
{PROFILELINK}

{REGARDS}',
	),
	'paid_subscription_new' => array(
		/*
			@additional_params: paid_subscription_new
				NAME: Subscription title.
				REALNAME: Recipients name
				SUBEMAIL: Email address of the user who took out the subscription
				SUBUSER: Username who took out the subscription.
				SUBNAME: User's display name who took out the subscription.
				DATE: Today's date.
				PROFILELINK: Link to members profile.
			@description:
		*/
		'subject' => 'Yeni Ücretli Abonelik',
		'body' => '{REALNAME},

Yeni bir ücretli abonelik satın alınmıştır, detayları aşağıdadır:

	Abonelik: {NAME}
	Kullanıcı Adı: {SUBNAME} ({SUBUSER})
	E-Posta Adresi: {SUBEMAIL}
	Ücret: {PRICE}
	Tarih: {DATE}

Bu üyenin profilini görüntülemek için aşağıdaki bağlantıya tıklayabilirsiniz:
{PROFILELINK}

{REGARDS}',
	),
	'paid_subscription_error' => array(
		/*
			@additional_params: paid_subscription_error
				ERROR: Error message.
				REALNAME: Recipients name
			@description:
		*/
		'subject' => 'Ücretli Abonelik Hatası',
		'body' => '{REALNAME},

Ücretli abonelik işlemi sırasında aşağıdaki hata oluştu:
---------------------------------------------------------------
{ERROR}

{REGARDS}',
	),
);

/*
	@additional_params: happy_birthday
		REALNAME: The real (display) name of the person receiving the birthday message.
	@description: A message sent to members on their birthday.
*/
$birthdayEmails = array(
	'happy_birthday' => array(
		'subject' => '{FORUMNAME} Doğum Gününüzü Kutlar',
		'body' => 'Değerli {REALNAME},

{FORUMNAME} doğum gününüzü kutlamaktan büyük bir mutluluk duyar!  Önümüzdeki yılın sizin ve sevenleriniz için çok güzel geçmesi dileğiyle.

{REGARDS}',
		'author' => '<a href="http://www.simplemachines.org/community/?action=profile;u=2676">Thantos</a>',
	),
	'karlbenson1' => array(
		'subject' => 'Doğum Gününde...',
		'body' => 'Sana bir doğum günü kartı veya çiçek gönderebilirdik.

Ama yapmadık

Sana ismine otomatik olarak oluşturulmuş bir kutlama gönderebilirdik.

Ama yapmadık

Bu doğum günü kutlamasını sadece senin için yazdık.

Ve senin çok özel bir doğum günü geçirmeni diledik.

{REGARDS}

//:: Bu İleti Otomatik Olarak Oluşturulmuştur :://',
		'author' => '<a href="http://www.simplemachines.org/community/?action=profile;u=63186">karlbenson</a>',
	),
	'nite0859' => array(
		'subject' => 'Doğum Günün Kutlu Olsun!',
		'body' => '{FORUMNAME} sitesindeki arkadaşların senin doğum gününü kutlamak istiyorlar, {REALNAME}. Eğer son zamanlarda ziyaret etmediyseniz, arkadaşlarınızın doğum gününüzü kutlayabilmeleri için sitemizi ziyaret edebilirsiniz.

Bugün senin doğum günün olmasına rağmen, {REALNAME}, senin sitemize olan üyeliğin bizim için en büyük hediye olmuştur.

En İyi Dileklerle,
{FORUMNAME} Ekibi',
		'author' => '<a href="http://www.simplemachines.org/community/?action=profile;u=46625">nite0859</a>',
	),
	'zwaldowski' => array(
		'subject' => 'İyiki Doğdun {REALNAME}',
		'body' => 'Değerli {REALNAME},

Hayatında bir yıl daha geride kaldı.  {FORUMNAME} olarak umuyoruz ki güzel bir sene geçirmişsindir ve bu sene daha birçok güzel yıla vesile olacaktır.

{REGARDS}',
		'author' => '<a href="http://www.simplemachines.org/community/?action=profile;u=72038">zwaldowski</a>',
	),
	'geezmo' => array(
		'subject' => 'Doğum Günün Kutlu Olsun, {REALNAME}!',
		'body' => 'Bugün kimin doğum günü biliyor musun, {REALNAME}?

Biz biliyoruz... SEN!

Doğum günün kutlu olsun!

Şu anda bir yıl daha yaşlısın ama diliyoruz ki geçen yıldan çok daha mutlusundur.

Günün tadını çıkar, {REALNAME}!

- {FORUMNAME} Ailesinden',
		'author' => '<a href="http://www.simplemachines.org/community/?action=profile;u=48671">geezmo</a>',
	),
	'karlbenson2' => array(
		'subject' => 'Doğumgünü Kutlaman',
		'body' => 'Umarız doğumgünün çok güzel geçmiştir.
Bol bol kek ye, eğlen ve bize forum\'da neler olduğundan bahsetmeyi unutma

Umarız bu ileti sana mutluluk getirmiştir, tekrar aynı yer ve aynı zamanda buluşmak üzere :)

{REGARDS}',
		'author' => '<a href="http://www.simplemachines.org/community/?action=profile;u=63186">karlbenson</a>',
	),
);

?>