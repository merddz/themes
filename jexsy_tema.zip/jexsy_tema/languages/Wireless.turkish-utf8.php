<?php
// Version: 2.0; Wireless

// Important! Before editing these language files please read the text at the top of index.english.php.
$txt['wireless_error_home'] = 'Forum dizini';

$txt['wireless_options'] = 'Ek seçenekler';
$txt['wireless_options_login'] = 'Giriş';
$txt['wireless_options_logout'] = 'Çıkış';

$txt['wireless_navigation'] = 'Navigasyon';
$txt['wireless_navigation_up'] = 'Üst Seviye';
$txt['wireless_navigation_next'] = 'Sonraki Sayfa';
$txt['wireless_navigation_prev'] = 'Önceki Sayfa';
$txt['wireless_navigation_index'] = 'Mesajlar';
$txt['wireless_navigation_topic'] = 'Konuya Geri Dön';

$txt['wireless_pm_inbox'] = 'ÖM gelen';
$txt['wireless_pm_inbox_new'] = 'Gelen Kutusu (<span style="color: red;">%1$d yeni</span>)';
$txt['wireless_pm_by'] = 'gönderen';
$txt['wireless_pm_add_buddy'] = 'Arkadaş ekle';
$txt['wireless_pm_select_buddy'] = 'Arkadaş seç';
$txt['wireless_pm_search_member'] = 'Üye ara';
$txt['wireless_pm_search_name'] = 'İsim';
$txt['wireless_pm_no_recipients'] = 'Alıcı yok (şu an)';
$txt['wireless_pm_reply'] = 'Yanıtla';
$txt['wireless_pm_reply_all'] = 'Tümünü Cevapla';
$txt['wireless_pm_reply_to'] = 'Yanıtla';

$txt['wireless_recent_unread_posts'] = 'Yeni iletiler';
$txt['wireless_recent_unread_replies'] = 'Yeni yanıtlar';

$txt['wireless_display_edit'] = 'Düzenle';
$txt['wireless_display_moderate'] = 'Moderasyon';
$txt['wireless_display_sticky'] = 'Sabitle';
$txt['wireless_display_unsticky'] = 'Sabitleme';
$txt['wireless_display_lock'] = 'Kilitle';
$txt['wireless_display_unlock'] = 'Kilitleme';

$txt['wireless_end_code'] = 'Kod sonu';
$txt['wireless_end_quote'] = 'Alıntı sonu';

$txt['wireless_profile_pm'] = 'Kişisel İleti Gönder';
$txt['wireless_ban_ip'] = 'IP\'yi Yasakla';
$txt['wireless_ban_hostname'] = 'Hostname\'i Yasakla';
$txt['wireless_ban_email'] = 'E-Posta\'yı Yasakla';
$txt['wireless_additional_info'] = 'Ek Bilgi';
$txt['wireless_go_to_full_version'] = 'Tam sürüme git';

?>