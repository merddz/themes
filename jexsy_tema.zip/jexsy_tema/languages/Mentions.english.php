<?php
/**
 * Language file for mentions
 *
 * @author Shitiz Garg <mail@dragooon.net>
 * @copyright 2014 Shitiz Garg
 * @license Simplified BSD (2-Clause) License
 */

global $txt, $context, $scripturl;

$txt['mentions_subject'] = 'MENTIONNAME, ' . $context['forum_name'] . ' forumunda konu içerisinde etiketlendiniz.';
$txt['mentions_body'] = 'Merhaba MENTIONNAME,

MEMBERNAME sizi "POSTNAME" konusunda etiketledi, POSTLINK

İyi forumlar,
' . $context['forum_name'];
$txt['mentions'] = 'Etiketlenmeler';
$txt['mentions_profile_title'] = '%s etiketlenmeleri';
$txt['mentions_post_subject'] = 'Konu';
$txt['mentions_member'] = 'Etiketleyen';
$txt['mentions_post_time'] = 'Etiketlenme Zamanı';
$txt['permissionname_mention_member'] = 'Üyeleri etiketleyebilir';
$txt['permissionhelp_mention_member'] = 'Üyeler @isim şeklinde diğer üyeleri etiketleyebilir.';
$txt['email_mentions'] = 'E-posta bildirimleri';
$txt['mentions_remove_days'] = 'Eski etiketleri şu günden sonra kaldır<div class="smalltext">Bu seçenek gün miktarından önceki etiketleri kaldıracaktır, <a href="' . $scripturl . '?action=admin;area=scheduledtasks">zamanlanmış görevleri</a> aktif ettiğinizden emin olun.</div>';
$txt['mentions_email_default'] = 'Varsayılan olarak e-posta bildirimlerini etkinleştir<div class="smalltext">Bu seçenek sadece yeni kayıtların e-posta bildirimi almasını sağlar.</div>';
$txt['mentions_permissions_notice'] = 'Üyelerin etiket kullanabilmeleri için izinleri ayarlamayı unutmayın.';
$txt['mentions_email_default_now'] = 'Şuanki üyeler için e-posta bildirimlerini etkinleştir<div class="smalltext">Bu seçenek sadece mevcut üyeler için geçerlidir.</div>';

?>