<?php

// Version: 2.0; ManageSettings



global $scripturl;



// Important! Before editing these language files please read the text at the top of index.english.php.

$txt['modSettings_desc'] = 'Bu sayfa forum\'unuzun sahip olduğu özelliklere ve paketlere ait seçenekleri değiştirmenizi sağlar. Bu sayfaları kullanarak forum\'unuzun temel ayarlarınıda değiştirebilirsiniz.  Daha fazla seçenek için lütfen <a href="' . $scripturl . '?action=theme;sa=settings;th=%s;sesc=%s">tema ayarları</a> nı ziyaret ediniz.  Ayarlar hakkında daha fazla bilgi için, soru işareti şeklindeki ikonlara tıklayabilirsiniz.';

$txt['security_settings_desc'] = 'Bu sayfa forumun\'unuzun güvenlik, moderasyon ve spam koruması ile ilgili seçeneklerini değiştirmenizi sağlamaktadır.';

$txt['modification_settings_desc'] = 'Bu sayfa mod\'lar tarafından size sunulmuş seçenekleri değiştirebilmenize olanak tanımaktadır.';



$txt['modification_no_misc_settings'] = 'Bu bölüme seçenek eklemiş herhangi bir mod bulunmamaktadır.';



$txt['pollMode'] = 'Anketler';

$txt['disable_polls'] = 'Kapalı';

$txt['enable_polls'] = 'Aktif';

$txt['polls_as_topics'] = 'Eski anketleri konu olarak göster';

$txt['allow_guestAccess'] = 'Ziyaretçilerin forumda gezinebilmelerine izin ver';

$txt['userLanguage'] = 'Kullanıcıların kullandıkları dili seçebilmelerine izin ver';

$txt['allow_editDisplayName'] = 'Üyelerin görünen isimlerini değiştirmelerine izin ver';

$txt['allow_hideOnline'] = 'Yönetici olmayanların çevrimiçi durumlarını gizlemelerine izin ver';

$txt['guest_hideContacts'] = 'Üyelerin profil bilgilerini ziyaretçilerden gizle';

$txt['titlesEnable'] = 'Kişisel başlıklara izin ver';

$txt['enable_buddylist'] = 'Arkadaş/Engelleme listelerine izin ver';

$txt['default_personal_text'] = 'Varsayılan kişisel metin';

$txt['number_format'] = 'Varsayılan rakam formatı';

$txt['time_format'] = 'Varsayılan tarih formatı';

$txt['setting_time_offset'] = 'Saat farkı';

$txt['setting_default_timezone'] = 'Sunucu zaman dilimi';

$txt['failed_login_threshold'] = 'Başarısız oturum eşiği';

$txt['lastActive'] = 'Çevrimiçi olma eşiği';

$txt['trackStats'] = 'Günlük istatistik tut';

$txt['hitStats'] = 'Sayfa gösterim istatistiği tut';

$txt['enableCompressedOutput'] = 'Sıkıştırılmış çıktıyı aktif kıl';

$txt['disableTemplateEval'] = 'Templatelerin değerlendirilmesini kapat';

$txt['databaseSession_enable'] = 'Oturumlar için veritabanını kullan';

$txt['databaseSession_loose'] = 'Tarayıcının geri tuşunu aktif kıl';

$txt['databaseSession_lifetime'] = 'Pasif oturumların zaman aşımı süresi (sn.)';

$txt['enableErrorLogging'] = 'Hata günlüğüne izin ver';

$txt['enableErrorQueryLogging'] = 'Günlük kaydında veritabanı sorgusunuda bulundur';

$txt['pruningOptions'] = 'Günlük kayıtlarının temizlenmesine izin ver';

$txt['pruneErrorLog'] = 'Şu süreden eski hata kaydını temizle<div class="smalltext">(0 - kapatır)</div>';

$txt['pruneModLog'] = 'Şu süreden eski moderasyon kaydını temizle<div class="smalltext">(0 - kapatır)</div>';

$txt['pruneBanLog'] = 'Şu süreden eski yasaklı giriş denemesi kaydını temizle<div class="smalltext">(0 - kapatır)</div>';

$txt['pruneReportLog'] = 'Şu süreden eski moderatör rapor kayıtlarını temizle<div class="smalltext">(0 - kapatır)</div>';

$txt['pruneScheduledTaskLog'] = 'Şu süreden eski zamanlanmış görevlere ait kayıtları temizle<div class="smalltext">(0 - kapatır)</div>';

$txt['pruneSpiderHitLog'] = 'Şu süreden eski arama motoru kayıtlarını temizle<div class="smalltext">(0 - kapatır)</div>';

$txt['cookieTime'] = 'Varsayılan oturum çerezi süresi (dk.)';

$txt['localCookies'] = 'Yerel çerezlerin depolanmasına izin ver<div class="smalltext">(SSI çalışmayacaktır)</div>';

$txt['globalCookies'] = 'Alt alan adından bağımsız çerez kullan<div class="smalltext">(Üstteki seçeneği devre dışı bırakınız!)</div>';

$txt['secureCookies'] = 'Çerezlerin güvenliğini güçlendir<div class="smalltext">(HTTPS kullanılıyorsa uygulanabilir , aksi taktirde kullanmayınız!)</div>';

$txt['securityDisable'] = 'Yönetim güvenliğini devre dışı bırak';

$txt['send_validation_onChange'] = 'E-Posta değişikliğinde aktivasyonu zorunlu kıl';

$txt['approveAccountDeletion'] = 'Üyenin hesabını silebilmesi için yönetici onayı iste';

$txt['autoOptMaxOnline'] = 'Veritabanı iyileştirmesi için maks. çevrimiçi üye<div class="smalltext">(0 - maks. yok)</div>';

$txt['autoFixDatabase'] = 'Bozuk tabloları otomatik olarak düzelt';

$txt['allow_disableAnnounce'] = 'Üyelerin duyuruları devre dışı bırakmasına izin ver';

$txt['disallow_sendBody'] = 'Duyurularda ileti metni gösterilmesin';

$txt['queryless_urls'] = 'Arama Motoru Dostu URL\'ler<div class="smalltext"><b>Sadece Apache/Lighttpd\'de çalışır!</b></div>';

$txt['max_image_width'] = 'Gönderilen resimlerin maks. genişliği (0 = sınırsız)';

$txt['max_image_height'] = 'Gönderilen resimlerin maks. yüksekliği (0 = sınırsız)';

$txt['enableReportPM'] = 'Kişisel iletilerin rapor edilmesine izin ver';

$txt['max_pm_recipients'] = 'Kişisel iletide izin verilen en fazla alıcı sayısı<div class="smalltext">(0 - limitsiz, adminler dahil değil)</div>';

$txt['pm_posts_verification'] = 'Kişisel iletilerde, görsel doğrulama uygulanmaması için sahip olunması gereken en az ileti sayısı<div class="smalltext">(0 - limitsiz, adminler dahil değil)</div>';

$txt['pm_posts_per_hour'] = 'Bir saat içerisinde gönderilebilecek en fazla kişisel ileti sayısı<div class="smalltext">(0 - limitsiz, moderatörler dahil değil)</div>';

$txt['compactTopicPagesEnable'] = 'Gösterilecek sayfa sayısını sınırla';

$txt['contiguous_page_display'] = 'Bitişik gösterilecek sayfa sayısı';

$txt['to_display'] = 'girerseniz';

$txt['todayMod'] = '&quot;Bugün&quot; özelliğini etkinleştir';

$txt['today_disabled'] = 'Kapalı';

$txt['today_only'] = 'Sadece Bugün';

$txt['yesterday_today'] = 'Bugün &amp; Dün';

$txt['topbottomEnable'] = 'Yukarı/Aşağı tuşlarını etkinleştir';

$txt['onlineEnable'] = 'Normal ve kişisel iletilerde çevrimiçi/çevrimdışı gösterimini etkinleştir';

$txt['enableVBStyleLogin'] = 'Her sayfada hızlı girişi göster';

$txt['defaultMaxMembers'] = 'Üye listesinde sayfa başına üye sayısı';

$txt['timeLoadPageEnable'] = 'Sayfaların oluşturulması için gereken süreyi göster';

$txt['disableHostnameLookup'] = 'Alanadı kontrollerini devre dışı bırak';

$txt['who_enabled'] = 'Kimler çevrimiçi listesini etkinleştir';

$txt['make_email_viewable'] = 'Görüntülenebilir e-posta adreslerine izin ver';

$txt['meta_keywords'] = 'Forum ile ilişkilendirilmiş Meta anahtar kelimeleri<div class="smalltext">Varsayılanları kullanmak için boş bırakınız.</div>  ';

$txt['image_proxy_enabled'] = 'Enable Image Proxy';

$txt['image_proxy_enabled_desc'] = 'This will proxy images posted within <b>[img]</b> tags.';

$txt['image_proxy_secret'] = 'Image Proxy Secret';

$txt['image_proxy_secret_desc'] = 'Bu sitenize özgü olmalıdır. Gizli tuttuğunuzdan emin olun.';

$txt['image_proxy_maxsize'] = 'Önbelleğe alınacak resimlerin azami boyutu';

$txt['image_proxy_maxsize_postinput'] = 'KB';

$txt['image_proxy_maxsize_desc'] = 'Bu eşiğin üzerindeki resimler yine de gösterilir.';



$txt['karmaMode'] = 'Karmanın işleyişi';

$txt['karma_options'] = 'Devre dışı bırak|Toplam karma|Pozitif/negatif karma';

$txt['karmaMinPosts'] = 'Karmayı değiştirebilmek için sahip olunması gereken en az ileti sayısı';

$txt['karmaWaitTime'] = 'Karmayı tekrar değiştirebilmek için gereken süre';

$txt['karmaTimeRestrictAdmins'] = 'Süre sınırlamasını yöneticiler içinde aktif et';

$txt['karmaLabel'] = 'Karma etiketi';

$txt['karmaApplaudLabel'] = 'Karma artırma etkiketi';

$txt['karmaSmiteLabel'] = 'Karma azaltma etkiketi';



$txt['caching_information'] = '<div class="aligncenter underline"><strong>Önemli! Bu özellikleri kullanmadan önce mutlaka burayı okuyunuz.</strong></div><br />



	SMF hızlandırıcılar yolu ile önbelleklemeyi desteklemektedir. Kullanabileceğiniz hızlandırıcılar şunlardır:<br />



	<ul class="normallist">



		<li>APC</li>



		<li>eAccelerator</li>



		<li>Turck MMCache</li>



		<li>Memcached</li>



		<li>Zend Platform/Performance Suite (Zend Optimizer Değil!)</li>



	</ul>



	Önbellekleme sadece sisteminizde yukarıdaki hızlandırıcılar yüklü ise çalışacaktır.<br />



	SMF birçok önbellekleme aşaması desteklemektedir, aşama arttıkça, işlemcinize binen yükte aynı oranda artacaktır.



	Eğer 	sisteminizde önbellekleme kullanılabilir ise size şiddetle seviye 1 önbelleklemeyi kullanmanızı öneririz.



	<br /><br />



	Unutmayın eğer memcahce kullanacaksanız sunucunuz ile ilgili detayları aşağıda belirtmeniz gerekecektir.



	Bu detaylar şu şekilde girilmelidir: &quot;server1,server2,server3:port,server4&quot;



	Eğer bir port belirtilmezse, SMF varsayılan olarak port 11211 i kullancaktır.







	<br /><br />



	%1$s';



$txt['detected_no_caching'] = '<strong class="alert">SMF sunucunuzda her hangi bir hızlandırıcı tespit edemedi.</strong>  ';

$txt['detected_APC'] = '<strong style="color: green">SMF sisteminizde APC\'nin yüklü olduğunu tespit etti.</strong>';

$txt['detected_eAccelerator'] = '<strong style="color: green">SMF sisteminizde eAccelerator\'ın yüklü olduğunu tespit etti.</strong>';

$txt['detected_MMCache'] = '<strong style="color: green">SMF sisteminizde MMCache\'in yüklü olduğunu tespit etti.</strong>';

$txt['detected_Zend'] = '<strong style="color: green">SMF sisteminizde Zend\'in yüklü olduğunu tespit etti.</strong>  ';

$txt['detected_Memcached'] = '<strong style="color: green">SMF sisteminizde Memcached\'nin yüklü olduğunu tespit etti.</strong>  ';

$txt['detected_XCache'] = '<strong style="color: green">SMF sunucunuzda XCache\'in yüklü olduğunu tespit etti.</strong>  ';



$txt['cache_enable'] = 'Önbellekleme Seviyesi';

$txt['cache_off'] = 'Kapalı';

$txt['cache_level1'] = 'Seviye 1';

$txt['cache_level2'] = 'Seviye 2 (Önerilmez)';

$txt['cache_level3'] = 'Seviye 3 (Önerilmez)';

$txt['cache_memcached'] = 'Memcache ayarları';



$txt['loadavg_warning'] = '<span class="error">Lütfen unutmayın: aşağıdaki ayarları düzenlerken dikkatli olun. Bazılarını çok düşük kullanmanız halinde forumunuz <strong>kullanılmaz</strong> hale gelebilir. Şu anki yükleme ortalaması <strong>%01.2f</strong></span>';

$txt['loadavg_enable'] = 'Yoğunluğa göre yük dengeleme';

$txt['loadavg_auto_opt'] = 'Otomatik veritabanı optimizasyonunu kapatma eşiği';

$txt['loadavg_search'] = 'Aramayı kullanıma kapatma eşiği';

$txt['loadavg_allunread'] = '<strong>Okunmamış konuları göster</strong> özelliğini kapatma eşiği';

$txt['loadavg_unreadreplies'] = '<strong>İletilerime yazılan yeni yanıtlar</strong> özelliğini kapatma eşiği';

$txt['loadavg_show_posts'] = 'Üyelerin ileti sayılarını gösterime kapatma eşiği';

$txt['loadavg_forum'] = 'Tüm forumu <strong>tamamen</strong> kullanıma kapatma eşiği';

$txt['loadavg_disabled_windows'] = '<span class="error">Yükleme dengeleme desteği Windowsda mevcut değildir.</span>';

$txt['loadavg_disabled_conf'] = '<span class="error">Yükleme dengeleme desteği sunucunuzun ayarları tarafından iptal edilmiştir.</span>';



$txt['setting_password_strength'] = 'Kullanıcı şifrelerinin güvenilirliği';

$txt['setting_password_strength_low'] = 'Düşük - en az 4 karakter';

$txt['setting_password_strength_medium'] = 'Orta - kullanıcı adını içeremez';

$txt['setting_password_strength_high'] = 'Yüksek - değişik karakterlerin karışımı olmalıdır';



$txt['antispam_Settings'] = 'Spam Koruması Doğrulaması';

$txt['antispam_Settings_desc'] = 'Bu bölümü kullanarak kullanıcının bir bot değil insan olduğunu doğrulamanıza olanak tanıyan doğrulama özelliği ile ilgili değişiklikler yapabilirsiniz.';

$txt['setting_reg_verification'] = 'Kayıt esnasında doğrulamayı zorunlu kıl';

$txt['posts_require_captcha'] = 'İleti gönderiminde doğrulamayı zorunlu kıl';

$txt['posts_require_captcha_desc'] = '(0 - limit yok, moderatörler hariç)';

$txt['search_enable_captcha'] = 'Ziyaretçiler tarafından yapılan aramalarda doğrulamayı zorunlu kıl';

$txt['setting_guests_require_captcha'] = 'Ziyaretçilerin ileti gönderiminde doğrulamayı zorunlu kıl';

$txt['setting_guests_require_captcha_desc'] = '(Aşağıda minimum bir ileti sayısı belirlediyseniz, otomatik devreye girer)';

$txt['guests_report_require_captcha'] = 'Ziyaretçiler bir ileti rapor ederken doğrulamayı geçmek zorundadır';



$txt['configure_verification_means'] = 'Doğrulama Metotlarını Yapılandır';

$txt['setting_qa_verification_number'] = 'Kullanıcının yanıtlaması gerekli doğrulama soruları';

$txt['setting_qa_verification_number_desc'] = '(0 -  kapatır, sorular aşağıdadır)';

$txt['configure_verification_means_desc'] = '<span class="smalltext">Bir kullanıcı için doğrulama tanımlandığı takdirde uygulanacak doğrulama metotlarını aşağıda belirleyebilirsiniz. Unutmayın, kullanıcı aşağıdaki metotların <em>hepsinden</em> geçmelidir.</span>';

$txt['setting_visual_verification_type'] = 'Görüntülenecek doğrulama resmi';

$txt['setting_visual_verification_type_desc'] = 'Resim zorlaştıkça, botlar tarafından kırılma ihtimali azalır';

$txt['setting_image_verification_off'] = 'Kapalı';

$txt['setting_image_verification_vsimple'] = 'Çok Basit - Resim üzerine normal metin';

$txt['setting_image_verification_simple'] = 'Basit - Çaprazlama renkli harfler, gürültü yok';

$txt['setting_image_verification_medium'] = 'Orta - Çaprazlama renkli harfler, karmaşık';

$txt['setting_image_verification_high'] = 'Yüksek - Kıvrımlı harfler, yüksek karmaşıklık';

$txt['setting_image_verification_extreme'] = 'Aşırı - Açılı harfler, ses, çizgiler ve bloklar ';

$txt['setting_image_verification_sample'] = 'Örnek';

$txt['setting_image_verification_nogd'] = '<strong>Not:</strong> Bu sunucuda GD kütüphanesi yüklü olmadığı için buradaki ayarların çoğu bir etkide bulunmayacaktır.';

$txt['setup_verification_questions'] = 'Doğrulama Soruları';

$txt['setup_verification_questions_desc'] = '<span class="smalltext">Eğer kullanıcıların doğrulama amaçlı belli soruları yanıtlamalarını istiyorsanız, aşağıda bu soruları ve yanıtlarını yapılandırmanız gerekmektedir. Basit sorulara seçmeye dikkat edin. Sorularda BBC kullanabilir, soruları kaldırmak için içeriğini silip kaydete basabilirsiniz.</span>';

$txt['setup_verification_question'] = 'Soru';

$txt['setup_verification_answer'] = 'Yanıt';

$txt['setup_verification_add_more'] = 'Yeni soru ekle';



$txt['moderation_settings'] = 'Moderasyon Ayarları';

$txt['setting_warning_enable'] = 'Kullanıcı Uyarı Sistemini Aktifleştir';

$txt['setting_warning_watch'] = 'Kullanıcının izlemeye alınacağı uyarı seviyesi<div class="smalltext">Üye izlemesinin aktifleştireceği uyarı seviyesi - 0 devre dışı bırakır.</div>';

$txt['setting_warning_moderate'] = 'İleti moderasyonun yapılacağı uyarı seviyesi<div class="smalltext">Üyenin tüm iletilerinin moderasyona tabi tutulacağı uyarı seviyesi - 0 devre dışı bırakır.</div>';

$txt['setting_warning_mute'] = 'Kullanıcının susturulacağı uyarı seviyesi<div class="smalltext">Kullanıcının ileti gönderemeyeceği uyarı seviyes - 0 devre dışı bırakır.</div>';

$txt['setting_user_limit'] = 'Günlük verilebilecek en fazla uyarı<div class="smalltext">Bu değer, bir moderatörün 24 saat içinde bir kullanıcıya verebileceği en yüksek uyarı sayısıdır - 0 sınırsız.</div>';

$txt['setting_warning_decrement'] = 'Her 24 saatte eksiltilecek uyarı sayısı<div class="smalltext">Son 24 saat içerisinde uyarı almamış kullanıcılardan yapılacak uyarı indirimi - 0 devre dışı bırakır.</div>';

$txt['setting_warning_show'] = 'Uyarı durumunu tüm kullanıcılara göster<div class="smalltext">Eğer bu seçenek kapatılırsa üyenin uyarı durumunu sadece moderatörler görüntüleyebilecektir.</div>';

$txt['setting_warning_show_mods'] = 'Sadece Moderatörler';

$txt['setting_warning_show_user'] = 'Moderatörler ve Uyarılmış Üyeler';

$txt['setting_warning_show_all'] = 'Tüm Kullanıcılar';



$txt['signature_settings'] = 'İmza Ayarları';

$txt['signature_settings_desc'] = 'Bu sayfayı, üyelerin imzalarının nasıl görüntüleneceğini değiştirmek için kullanabilirsiniz.';

$txt['signature_settings_warning'] = 'Bu seçenekler eski imzalara uygulanmazlar. Bu kuralları eski imzalara uygulamak için lütfen<a href="' . $scripturl . '?action=admin;area=featuresettings;sa=sig;apply;%2$s=%1$s">buraya</a> tıklayın.';

$txt['signature_enable'] = 'İmzalara izin ver';

$txt['signature_max_length'] = 'İzin verilen en fazla karakter<div class="smalltext">(0 - sınırsız)</div>';

$txt['signature_max_lines'] = 'İzin verilen en fazla satır<div class="smalltext">(0 - sınırsız)</div>';

$txt['signature_max_images'] = 'İzin verilen resim sayısı<div class="smalltext">(0 - sınırsız)</div>';

$txt['signature_allow_smileys'] = 'İmzalarda gülücüklere izin ver';

$txt['signature_max_smileys'] = 'İzin verilen gülümseme sayısı<div class="smalltext">(0 - sınırsız)</div>';

$txt['signature_max_image_width'] = 'İmzalardaki resimlerin maks. genişliği (pixel)<div class="smalltext">(0 - sınırsız)</div>';

$txt['signature_max_image_height'] = 'İmzalardaki resimlerin maks. yüksekliği (pixel)<div class="smalltext">(0 - sınırsız)</div>';

$txt['signature_max_font_size'] = 'İmzalardaki metinlerin maks. font büyüklüğü<div class="smalltext">(0 - sınırsız)</div>';

$txt['signature_bbc'] = 'İzin Verilen BBC Etkiketleri';



$txt['custom_profile_title'] = 'Özel Profil Alanları';

$txt['custom_profile_desc'] = 'Bu sayfadan forumunuzun gereksinimlerine göre özel profil alanları belirleyebilirsiniz.';

$txt['custom_profile_active'] = 'Aktif';

$txt['custom_profile_fieldname'] = 'Alanın İsmi';

$txt['custom_profile_fieldtype'] = 'Alanın Türü';

$txt['custom_profile_make_new'] = 'Yeni Alan';

$txt['custom_profile_none'] = 'Henüz herhangi bir profil alanı oluşturmadınız!';

$txt['custom_profile_icon'] = 'İkon';



$txt['custom_profile_type_text'] = 'Metin';

$txt['custom_profile_type_textarea'] = 'Uzun Metin';

$txt['custom_profile_type_select'] = 'Seçenek Kutusu';

$txt['custom_profile_type_radio'] = 'Radio';

$txt['custom_profile_type_check'] = 'İşaret Kutusu';



$txt['custom_add_title'] = 'Profil Alanını Ekle';

$txt['custom_edit_title'] = 'Profil Alanını Düzenle';

$txt['custom_edit_general'] = 'Görünüm Ayarları';

$txt['custom_edit_input'] = 'Giriş Ayarları';

$txt['custom_edit_advanced'] = 'Gelişmiş Ayarlar';

$txt['custom_edit_name'] = 'İsim';

$txt['custom_edit_desc'] = 'Tanım';

$txt['custom_edit_profile'] = 'Profil Bölümü';

$txt['custom_edit_profile_desc'] = 'Düzenlemesinin yapılacağı Profil bölümü.';

$txt['custom_edit_profile_none'] = 'Hiçbiri';

$txt['custom_edit_registration'] = 'Kayıt Esnasında Göster';

$txt['custom_edit_registration_disable'] = 'Hayır';

$txt['custom_edit_registration_allow'] = 'Evet';

$txt['custom_edit_registration_require'] = 'Evet, ve girdi gerektir';

$txt['custom_edit_display'] = 'Konu Görünümünde Göster';

$txt['custom_edit_picktype'] = 'Alan Türü';



$txt['custom_edit_max_length'] = 'Maksimum Genişlik';

$txt['custom_edit_max_length_desc'] = '(0 - sınırsız)';

$txt['custom_edit_dimension'] = 'Boyut';

$txt['custom_edit_dimension_row'] = 'Satır';

$txt['custom_edit_dimension_col'] = 'Kolon';

$txt['custom_edit_bbc'] = 'BBC\'ye izin ver';

$txt['custom_edit_options'] = 'Seçenekler';

$txt['custom_edit_options_desc'] = 'Kaldırmak için seçenek kutusunu boş bırakın. Radio tuşu varsayılan seçeneği kendi seçer.';

$txt['custom_edit_options_more'] = 'Daha Fazla';

$txt['custom_edit_default'] = 'Varsayılan Durum';

$txt['custom_edit_active'] = 'Aktif';

$txt['custom_edit_active_desc'] = 'Eğer seçili değilse bu alan kimseye gösterilmeyecek.';

$txt['custom_edit_privacy'] = 'Gizlilik';

$txt['custom_edit_privacy_desc'] = 'Bu alanı düzenleyebilecek ve görebilecek kişiler.';

$txt['custom_edit_privacy_all'] = 'Üyeler görebilir; sahibi düzenleyebilir';

$txt['custom_edit_privacy_see'] = 'Üyeler görebilir; sadece yöneticiler düzenleyebilir';

$txt['custom_edit_privacy_owner'] = 'Üyeler bu alanı görüntüleyemezler; sadece sahibi ve yöneticiler düzenleme yapabilirler.';

$txt['custom_edit_privacy_none'] = 'Bu alan sadece yöneticiler tarafından görülebilir';

$txt['custom_edit_can_search'] = 'Aranabilir';

$txt['custom_edit_can_search_desc'] = 'Bu alana göre üye listesinden arama yapılabilsin.';

$txt['custom_edit_mask'] = 'Değer Kontrolü';

$txt['custom_edit_mask_desc'] = 'Girilecek değeri doğrulamak için kullanılır.';

$txt['custom_edit_mask_email'] = 'Geçerli E-Posta';

$txt['custom_edit_mask_number'] = 'Rakamsal';

$txt['custom_edit_mask_nohtml'] = 'HTML Yok';

$txt['custom_edit_mask_regex'] = 'Regex (Gelişmiş)';

$txt['custom_edit_enclose'] = 'Metin İçerisinde Göster (isteğe bağlı)';

$txt['custom_edit_enclose_desc'] = 'Bu seçeneği kullandığınızda <strong>kesinlikle</strong> <em>Değer Kontrolü</em>nü de kullanamanız önerilir.';



$txt['custom_edit_placement'] = 'Yer seçin';

$txt['custom_edit_placement_standard'] = 'Standart (başlık ile)';

$txt['custom_edit_placement_withicons'] = 'Simgeler ile Birlikte';

$txt['custom_edit_placement_abovesignature'] = 'İmzanın Üzerinde';

$txt['custom_profile_placement'] = 'Yer';

$txt['custom_profile_placement_standard'] = 'Standart';

$txt['custom_profile_placement_withicons'] = 'Simgeler ile Birlikte';

$txt['custom_profile_placement_abovesignature'] = 'İmzanın Üzerinde';



// Use numeric entities in the string below!

$txt['custom_edit_delete_sure'] = 'Bu alanı kaldırmak istediğinize emin misiniz - kullanıcıların sahip olduğu tüm veri kaybolacaktır!';



$txt['standard_profile_title'] = 'Varsayılan Profil Alanları';

$txt['standard_profile_field'] = 'Alan';



$txt['core_settings_welcome_msg'] = 'Yeni Forum\'unuza Hoş Geldiniz';

$txt['core_settings_welcome_msg_desc'] = 'Başlangıç olarak SMF\'in hangi çekirdek özelliklerini aktifleştirmek istediğinizi seçmenizi öneririz. Sadece ihtiyacınız olan özellikleri aktifleştirmeniz önerilir!';

$txt['core_settings_item_cd'] = 'Takvim';

$txt['core_settings_item_cd_desc'] = 'Bu seçeneği aktifleştirseniz, kullanıcılar forum takvimini görüntüleyebilecek, etkinlikler ekleyebilecek, diğer üyelerin doğum günleri hakkında bilgi sahibi olacak ve takvim ile alakalı birçok şey daha yapabileceklerdir.';

$txt['core_settings_item_cp'] = 'Gelişmiş Profil Alanları';

$txt['core_settings_item_cp_desc'] = 'Bu özellik varsayılan profil alanlarını devre dışı bırakmanıza, kayıtta istenecek yeni profil alanları eklemenize ve profil ile ileti görünümünde görüntülenebilecek yeni profil alanları oluşturmanıza olanak sağlar.';

$txt['core_settings_item_k'] = 'Karma';

$txt['core_settings_item_k_desc'] = 'Karma üyelerin popülerliğini gösteren  bir özelliktir (Reputation ve Rep olarakta bilinmektedir). Üyeler, izin verildiği takdirde, diğer üyelerin karmasını \'artırabilir\' veya \'azaltabilmektedirler\'.';

$txt['core_settings_item_ml'] = 'Moderasyon Günlüğü';

$txt['core_settings_item_ml_desc'] = 'Moderatörlerinizin uyguladığı tüm işlemlerin kaydını tutmak istiyorsanız bu özelliği aktifleştirebilirsiniz.';

$txt['core_settings_item_pm'] = 'İleti Moderasyonu';

$txt['core_settings_item_pm_desc'] = 'İleti moderasyonu, konuların veya iletilerin herkes tarafından görüntülenebilmesinden önce, üye grupları veya bölümlere göre, moderatörler tarafından onaylanmalarını zorunlu kılmanızı sağlar. Bu seçeneği aktifleştirdikten sonra izinleri ayarlamayı unutmayın.';

$txt['core_settings_item_ps'] = 'Ücretli Abonelikler';

$txt['core_settings_item_ps_desc'] = 'Ücretli abonelikler, üyelerin abonelikler satın alarak farklı üye grupları edinmelerini sağlar. Bu doğrultuda yetkilerin artmasıda sağlanabilir.';

$txt['core_settings_item_rg'] = 'Rapor Üretimi';

$txt['core_settings_item_rg_desc'] = 'Bu yönetim seçeneği, özellikle büyük forum\'lar için forum hakkındaki bilgileri belirttiğiniz kritlerde düzenli bir şekilde görüntüleyebilmenizi sağlar.';

$txt['core_settings_item_sp'] = 'Arama Motoru Kaydı';

$txt['core_settings_item_sp_desc'] = 'Bu özellik yöneticilerin, arama motoları sitelerini indekslerken onları takip etmelerine olanak tanımaktadır.';

$txt['core_settings_item_w'] = 'Uyarı Sistemi';

$txt['core_settings_item_w_desc'] = 'Bu özellik yönetici ve moderatörlerin kullanıcıları uyarabilmesini sağlar; ayrıca bu özellik, her uyarı seviyesinde, kullanıcının bazı haklarının kısıtlanmasına olanak tanır. Bu özellikten maks. verim alınabilmesi için &quot;İleti Moderasyonu&quot; açık olmalıdır.';

$txt['core_settings_switch_on'] = 'Aktifleştir';

$txt['core_settings_switch_off'] = 'Devre Dışı Bırak';

$txt['core_settings_enabled'] = 'Aktif';

$txt['core_settings_disabled'] = 'Devre Dışı';



$txt['languages_lang_name'] = 'Dil Dosyasının Adı';

$txt['languages_locale'] = 'Yerel';

$txt['languages_default'] = 'Varsayılan';

$txt['languages_character_set'] = 'Karakter Seti';

$txt['languages_users'] = 'Kullanıcılar';

$txt['language_settings_writable'] = 'Uyarı: Settings.php yazılabilir olmadığı için varsayılan dil değiştirilemeyecektir.';

$txt['edit_languages'] = 'Dilleri Düzenle';

$txt['lang_file_not_writable'] = '<strong>Uyarı:</strong> Ana dil dosyası (%1$s) yazılabilir değildir. Herhangi bir değişiklik yapmadan önce bu dosyayı yazılabilir hale getirmelisiniz.';

$txt['lang_entries_not_writable'] = '<strong>Uyarı:</strong> Dil dosyası (%1$s) yazılabilir değildir. Herhangi bir değişiklik yapmadan önce bu dosyayı yazılabilir hale getirmelisiniz.';

$txt['languages_ltr'] = 'Sağdan Sola';



$txt['add_language'] = 'Dil Ekle';

$txt['add_language_smf'] = 'Simple Machines\'den İndir';

$txt['add_language_smf_browse'] = 'Arama yapmak istediğiniz dilin adını girin, hepsini görüntülemek için boş bırakın.';

$txt['add_language_smf_install'] = 'Yükle';

$txt['add_language_smf_found'] = 'Aşağıdaki diller bulunmuştur. Yüklemek istediğiniz dilin yanındaki yükle bağlantısına tıkladığınızda otomatik olarak paket yöneticisine yönlendirilirsiniz.';

$txt['add_language_error_no_response'] = 'Simple Machines sitesine bağlanılamıyor, daha sonra tekrar deneyiniz.';

$txt['add_language_error_no_files'] = 'Hiçbir dosya bulunamadı.';

$txt['add_language_smf_desc'] = 'Tanım';

$txt['add_language_smf_utf8'] = 'UTF-8';

$txt['add_language_smf_version'] = 'Sürüm';



$txt['edit_language_entries_primary'] = 'Aşağıda bu dil paketi için tanımlanmış birincil ayarlar bulunmaktadır.';

$txt['edit_language_entries'] = 'Dil Girdilerini Düzenle';

$txt['edit_language_entries_file'] = 'Düzenlenecek girdileri seçin';

$txt['languages_dictionary'] = 'Sözlük';

$txt['languages_spelling'] = 'Yazım Denetimi';

$txt['languages_for_pspell'] = '<a href="http://www.php.net/function.pspell-new" target="_blank" class="new_win">pSpell</a> yüklü ise çalışır';

$txt['languages_rtl'] = '&quot;Sağdan Sola&quot; Yazım Yönünü Etkinleştir';



$txt['lang_file_desc_index'] = 'General Değişkenler';

$txt['lang_file_desc_EmailTemplates'] = 'E-posta Tasarımları';



$txt['languages_download'] = 'Dil Paketi İndir';

$txt['languages_download_note'] = 'Bu sayfa dil paketinde bulunan tüm dosyaları ve bu dosyalar hakkında bilgi içerir. Yanındaki kutusu seçili tüm dosyalar kopyalanacaktır.';

$txt['languages_download_info'] = '<strong>Not:</strong> <ul class="normallist"><li>&quot;Yazılamaz&quot; iletisi SMF\'in ilgili dosyayı kopyalamayacağı anlamına gelmektedir ve bu sorunun üstesinden gelebilmek için izinleri FTP yazılımınızı kullanarak veya istenen bilgileri aşağıdaki forma girerek düzenlemeniz gerekmektedir.</li><li>Sürüm bilgisi ilgili dosyanın en son hangi SMF sürümü için güncellendiğini belirtmektedir. Eğer metin yeşil ise bu paket sizin kurulumunuzda bulunan dosyadan daha yeni bir dosya içeriyor anlamına gelmektedir. Eğer metin kehribar renginde ise sürümler aynı, kırmızı ise sizin sürümünüz daha yeni anlamına gelmektedir.</li><li>Eğer dosya forum\'da zaten var ise &quot;Zaten Yüklü&quot; şu iki değerden birini içerecektir: &quot;Eş&quot; ilgili dosyanın var olan dosyanın bir eşi olduğu anlamına gelir. &quot;Farklı&quot;iki dosyanın içeriğinin farklı olduğu anlamına gelir.</li></ul>';



$txt['languages_download_main_files'] = 'Ana Dosyalar';

$txt['languages_download_theme_files'] = 'Tema-ilgili Dosyalar';

$txt['languages_download_filename'] = 'Dosya Adı';

$txt['languages_download_dest'] = 'Hedef Konum';

$txt['languages_download_writable'] = 'Yazılabilir';

$txt['languages_download_version'] = 'Sürüm';

$txt['languages_download_older'] = 'Bu dosyanın daha yeni bir sürümü zaten sizde mevcuttur, üzerine yazmanız önerilmez.';

$txt['languages_download_exists'] = 'Zaten Var';

$txt['languages_download_exists_same'] = 'Eş';

$txt['languages_download_exists_different'] = 'Farklı';

$txt['languages_download_copy'] = 'Kopyala';

$txt['languages_download_not_chmod'] = 'Kopyalanacak tüm dosyalar yazılabilir olmadan önce işleme devam edemezsiniz.';

$txt['languages_download_illegal_paths'] = 'Paket geçersiz konum bilgisi içermektedir - lütfen Simple Machines ile iletişime geçiniz.';

$txt['languages_download_complete'] = 'Yükleme Tamamlandı';

$txt['languages_download_complete_desc'] = 'Dil paketi başarı ile yüklenmiştir. <a href="%1$s">Dil Paketleri</a> sayfasına geri dönebilirsiniz.';

$txt['languages_delete_confirm'] = 'Bu dili silmek istediginize eminmisiniz?';

$txt['youtube'] = 'Youtube';
$txt['yt_search'] = 'YouTube Arama';
$txt['yt_user'] = 'YouTube Kullanıcı';
$txt['youtube_link_invalid'] = '[ Geçersiz youtube linki ]';
$txt['youtube_no_embed'] = 'Youtube videolarını link olarak göster.';
$txt['youtube_sig_embed'] = 'İmzalarda youtube videolarına izin ver?';
$txt['youtube_disable_autoembed'] = 'Otomatik youtube linklerini algılama devre dışı bırakılsın mı?';
?>