<?php
// Version: 2.0; Admin

global $settings, $scripturl;

$txt['admin_boards'] = 'Kategoriler';
$txt['admin_users'] = 'Üyeler';
$txt['admin_newsletters'] = 'Bültenler';
$txt['admin_edit_news'] = 'Haberler';
$txt['admin_groups'] = 'Üye Grupları';
$txt['admin_members'] = 'Üyeleri Yönet';
$txt['admin_members_list'] = 'Aşağıda foruma kayıtlı tüm üyelerin listesi bulunmaktadır.';
$txt['admin_next'] = 'Sonraki';
$txt['admin_censored_words'] = 'Sansürlü Kelimeler';
$txt['admin_censored_where'] = 'Sansürlenecek kelimeyi sol kutuya, yerine kullanılacak olanı ise sağ kutuya yazınız.';
$txt['admin_censored_desc'] = 'Forumların yapısı gereği belli kelimelerin forumda kullanılmasını engellemek isteyebilirsiniz. Bu amaçla sansürlenmesini istediğiniz kelimeleri aşağıya girebilirsiniz.<br />Silmek için kutulardaki kelimeleri temizlemeniz yeterlidir.';
$txt['admin_reserved_names'] = 'Ayrılmış İsimler';
$txt['admin_template_edit'] = 'Forum Temasını Düzenle';
$txt['admin_modifications'] = 'Modifikasyon Ayarları';
$txt['admin_security_moderation'] = 'Güvenlik ve Moderasyon';
$txt['admin_server_settings'] = 'Sunucu Ayarları';
$txt['admin_reserved_set'] = 'Ayrılmış İsimleri Belirt';
$txt['admin_reserved_line'] = 'Bir satırda sadece bir isim bulunabilir.';
$txt['admin_basic_settings'] = 'Bu sayfa forumunuzun temel ayarlarını değiştirmenizi sağlar. Bu ayarları yaparken dikkatli olun çünkü yapacağınız yanlış bir ayar forum\'un çalışmamasına neden olabilir.';
$txt['admin_maintain'] = 'Bakım Modunu Etkinleştir';
$txt['admin_title'] = 'Forum Başlığı';
$txt['admin_url'] = 'Forum Adresi';
$txt['cookie_name'] = 'Çerez Adı';
$txt['admin_webmaster_email'] = 'Site Yöneticisinin Adresi';
$txt['boarddir'] = 'SMF Dizini';
$txt['sourcesdir'] = 'Kaynak Dizini';
$txt['cachedir'] = 'Önbellek Dizini';
$txt['admin_news'] = 'Haberleri Etkinleştir';
$txt['admin_guest_post'] = 'Ziyaretçilerin İleti Göndermelerini Etkinleştir';
$txt['admin_manage_members'] = 'Üyeler';
$txt['admin_main'] = 'Temel';
$txt['admin_config'] = 'Yapılandırma';
$txt['admin_version_check'] = 'Detaylı Sürüm Kontrolü';
$txt['admin_smffile'] = 'SMF Dosyası';
$txt['admin_smfpackage'] = 'SMF Paketi';
$txt['admin_maintenance'] = 'Bakım';
$txt['admin_image_text'] = 'Butonlar için metin yerine resim kullan';
$txt['admin_credits'] = 'Hazırlayanlar';
$txt['admin_agreement'] = 'Kayıt sırasında üyelik sözleşmesinin onaylanmasını zorunlu kıl';
$txt['admin_agreement_default'] = 'Varsayılan';
$txt['admin_agreement_select_language'] = 'Düzenlenecek dil';
$txt['admin_agreement_select_language_change'] = 'Değiştir';
$txt['admin_delete_members'] = 'Seçili Üyeleri Sil';
$txt['admin_repair'] = 'Tüm Bölüm ve Konuları Onar';
$txt['admin_main_welcome'] = 'Burası sizin "%1$s". Burada, ayarları düzenliyebilir, foruma bakım uygulayabilir, geçmişi görüntüleyebilir, paketler yükleyebilir, temaları yönetebilir, ve bir çok diğer şeyi yapabilirsiniz.<div style="margin-top: 1ex;">Eğer bir sorununuz varsa, lütfen "Yardım & Credits" sayfasına bakınız. Eğer oradaki bilgi size yardımcı olamıyorsa, sorun ile <a href="http://www.simplemachines.org/community/index.php" target="_blank" class="new_win">yardım için bize gelmekten</a> çekinmeyin.</div>Ayrıca problemlerinize veya sorunlarınıza çözüm bulmak için <img src="' . $settings['images_url'] . '/helptopics.gif" alt="%2$s" title="%3$s" /> sembolüne tıklayarakda ilgili fonksiyon hakkında daha detaylı bilgi alabilirsiniz.';
$txt['admin_news_desc'] = 'Lütfen her kutuya birer haber giriniz. Haberlerde <span title="Kalın">[b]</span>, <span title="İtalik">[i]</span> ve <span title="Altı Çizilmiş">[u]</span> gibi BBC etiketlerinin yanı sıra gülümsemeler ve HTML kodları kullanılabilirsiniz. Kaldırmak istediğiniz haberin içeriğini temizlemeniz yeterli olacaktır.';
$txt['administrators'] = 'Forum Yöneticileri';
$txt['admin_reserved_desc'] = 'Ayrılmış isimler kullanıcıların belli isimler ile kayıt olmasını veya belirlenmiş kelimelerin üye isimlerinde kullanılmasını engelleyecektir.';
$txt['admin_activation_email'] = 'Yeni kayıt olan kullanıcılara aktivasyon gönder';
$txt['admin_match_whole'] = 'Tam ismin eşleşmesini zorunlu kıl.';
$txt['admin_match_case'] = 'Büyük-küçük harfe duyarlı olsun.';
$txt['admin_check_user'] = 'Kullanıcı adını denetle.';
$txt['admin_check_display'] = 'Görünen ismi denetle.';
$txt['admin_newsletter_send'] = 'Bu bölümde istediğiniz kullanıcı gruplarındaki üyelere e-posta gönderebilirsiniz. Seçilen kullanıcı gruplarındaki kullanıcıların e-posta adresleri aşağıda listelendi. Ek adres belirtmek istiyorsanız, e-posta adreslerini \'alper@eposta.com; eren@eposta.com\' biçiminde girebilirsiniz.';
$txt['admin_fader_delay'] = 'Haber kutusundaki iletilerin kaybolma hızını milisaniye olarak girin';
$txt['admin_bbc'] = 'İleti ve Kişisel İleti Gönderirken BBC Butonlarını Göster';

$txt['admin_backup_fail'] = 'Settings.php dosyasının yedeği alınamıyor - forum ana dizininizde Settings_bak.php adlı dosyanın yazılabilir ve var olduğundan emin olun';
$txt['modSettings_info'] = 'Bu forum\'un işleyişiyle ilgili seçenekleri değiştir.';
$txt['database_server'] = 'Veritabanı Sunucu Adresi';
$txt['database_user'] = 'Veritabanı Kullanıcı Adı';
$txt['database_password'] = 'Veritabanı Parolası';
$txt['database_name'] = 'Veritabanı Adı';
$txt['registration_agreement'] = 'Üyelik Sözleşmesi';
$txt['registration_agreement_desc'] = 'Bu sözleşme kullanıcılara kayıt sırasında gösterilecek ve kaydın tamamlanabilmesi için kabul edilmesi zorunlu olacaktır.';
$txt['database_prefix'] = 'Veritabanı tablolarının öneki';
$txt['errors_list'] = 'Forum Hatalarının Listesi';
$txt['errors_found'] = 'Forum\'unuzda aşağıdaki hatalar bulunmuştur';
$txt['errors_fix'] = 'Hataları düzeltmek istiyor musunuz?';
$txt['errors_do_recount'] = 'Tüm hatalar çözüldü - bir kurtarma alanı oluşturuldu! Bazı anahtar istatistikleri tekrar saymak için lütfen aşağıdaki butona tıklayın.';
$txt['errors_recount_now'] = 'İstatistikleri Yeniden Say';
$txt['errors_fixing'] = 'Forum hataları düzeltiliyor';
$txt['errors_fixed'] = 'Tüm hatalar düzeltildi! Lütfen kategorilerinizi, bölümlerinizi veya konularınızı kontrol edin.';
$txt['attachments_avatars'] = 'Eklentiler ve Avatarlar';
$txt['attachments_desc'] = 'Forum\'daki eklentileri bu alanda yönetebilirsiniz. Eklentileri tarih veya boyutlarına göre silebilirsiniz. Ayrıca eklentiler ile ilgili istatistiklerde aşağıda gösterilmektedir.';
$txt['attachment_stats'] = 'Eklenti İstatistikleri';
$txt['attachment_integrity_check'] = 'Ek Bütünlük Kontrolü';
$txt['attachment_integrity_check_desc'] = 'Bu fonksiyon veritabanında listelenmiş eklerin ve dosya isimlerinin boyutunu ve bütünlüğünü kontrol edecektir ve eğer gerekirse, karşılaşılan hataları çözecektir.';
$txt['attachment_check_now'] = 'Kontrolü şimdi çalıştır';
$txt['attachment_pruning'] = 'Ek Temizliği';
$txt['attachment_pruning_message'] = 'İletiye eklenicek mesaj';
$txt['attachment_pruning_warning'] = 'Bu ekleri silmek istediğinize eminmisiniz?\\nGeri alınamaz.';
$txt['attachment_total'] = 'Toplam Eklenti';
$txt['attachmentdir_size'] = 'Eklenti Klasörünün Toplam Boyutu';
$txt['attachmentdir_size_current'] = 'Şu Andaki Eklenti Klasörünün Toplam Boyutu';
$txt['attachment_space'] = 'Kullanılabilir Boş Alan';
$txt['attachment_space_current'] = 'Şu Andaki Eklenti Klasörünün Kullanılabilir Boş Alanı';
$txt['attachment_options'] = 'Dosya Ekleme Seçenekleri';
$txt['attachment_log'] = 'Eklenti Kayıtları';
$txt['attachment_remove_old'] = 'Eklentiler belirtilmiş günden eski ise:';
$txt['attachment_remove_size'] = 'Eklentiler belirtilmiş boyuttan çok ise:';
$txt['attachment_name'] = 'Dosya Adı';
$txt['attachment_file_size'] = 'Dosya Boyutu';
$txt['attachmentdir_size_not_set'] = 'Eklenti dizini için maksimum boyut belirlenmemiş.';
$txt['attachment_delete_admin'] = '[eklenti yönetici tarafından silindi]';
$txt['live'] = 'Simple Machines\'den Duyurular';
$txt['remove_all'] = 'Tümünü Kaldır';
$txt['approve_new_members'] = 'Yönetici tüm yeni üyeleri onaylamalı';
$txt['agreement_not_writable'] = 'Uyarı - agreement.txt dosyası yazılabilir değil, yapılan değişiklikler kaydedilemeyecek.';

$txt['version_check_desc'] = 'Bu bölümde kullandığınız dosyalar ile simplemachines.org\'daki güncel dosyaların sürümlerinin kıyaslamasını görmektesiniz. Eğer kullandığınız dosyaların eski olduğunu düşünüyorsanız, yeni sürümleri indirmek için <a href="http://www.simplemachines.org/" target="_blank">www.simplemachines.org</a> adresini ziyaret ediniz.';
$txt['version_check_more'] = '(daha fazla detay)';

$txt['lfyi'] = 'Simplemachines.org\'da bulunan "Son Haberler" dosyasına bağlanılamadı.';

$txt['manage_calendar'] = 'Takvim';
$txt['manage_search'] = 'Arama';

$txt['smileys_manage'] = 'Gülümsemeler ve İleti İkonları';
$txt['smileys_manage_info'] = 'Yeni gülümseme setleri yükleyebilir, var olanları düzenleyebilir veya yeni ileti ikonları ekleyebilirsiniz.';
$txt['package_info'] = 'Forum\'unuza yeni özellikler yükleyebilir veya var olanları düzenleyebilirsiniz.';
$txt['theme_admin'] = 'Temalar ve Görünüm';
$txt['theme_admin_info'] = 'Yeni tema yükleyebilir veya varolan temalarınızı düzenleyebilirsiniz.';
$txt['registration_center'] = 'Üye Olma';
$txt['member_center_info'] = 'Üye listesini görüntüleyebilir, üyeler arasında arama yapabilir ve üyelikleri onaylanmamış veya aktifleştirilmemiş üyelerin durumuna bakabilirsiniz.';

$txt['viewmembers_name'] = 'Kullanıcı Adı';
$txt['viewmembers_online'] = 'Son Aktif Olma';
$txt['viewmembers_today'] = 'Bugün';
$txt['viewmembers_day_ago'] = 'gün önce';
$txt['viewmembers_days_ago'] = 'gün önce';

$txt['display_name'] = 'Görünen ismi';
$txt['email_address'] = 'E-Posta Adresi';
$txt['ip_address'] = 'IP Adresi';
$txt['member_id'] = 'ID';

$txt['unknown'] = 'bilinmeyen';
$txt['security_wrong'] = 'Yönetici giriş girişimi!' . "\n" . 'Yönlendiren: %1$s' . "\n" . 'Tarayıcı: %2$s' . "\n" . 'IP: %3$s';

$txt['email_as_html'] = 'HTML formatında gönder. <em class="smalltext">(bu seçenek sayesinde iletilerde normal HTML kodları kullanabilirsiniz)</em>';
$txt['email_parsed_html'] = '&lt;br /&gt; ve &amp;nbsp; etiketlerini bu iletiye ekle';
$txt['email_variables'] = 'Bu ileti içerisinde bazı &quot;değişkenler&quot; kullanılabilmektedir. Daha fazla bilgi için <a href="' . $scripturl . '?action=helpadmin;help=emailmembers" onclick="return reqWin(this.href);" class="help">tıklayın</a>.';
$txt['email_force'] = 'Üye duyuruları kabul etmemeyi tercih etmişse bile gönder.';
$txt['email_as_pms'] = 'E-Posta yerine kişisel ileti olarak gönder.';
$txt['email_continue'] = 'İleri';
$txt['email_done'] = 'bitti.';

$txt['ban_title'] = 'Yasaklı Listesi';
$txt['ban_ip'] = 'IP yasaklama: (Örn. 114.008.87.08 veya 128.0.*.*) - Her satıra bir tane';
$txt['ban_email'] = 'E-Posta yasaklama: (Örn. eren@alper.com) - Her satıra bir tane';
$txt['ban_username'] = 'Kullanıcı adı yasaklama: (Örn. dreadLord) - Her satıra bir tane';

$txt['ban_description'] = 'Buradan kişilerin forum\'a girişini IP, host adı, kullanıcı adı, veya e-posta\'ya dayalı olarak engelleyebilirsiniz.';
$txt['ban_add_new'] = 'Yeni yasaklama ekle';
$txt['ban_banned_entity'] = 'Yasaklama türü';
$txt['ban_on_ip'] = 'IP Yasaklama (Örn. 192.168.10-20.*)';
$txt['ban_on_hostname'] = 'Hostadı Yasaklama (Örn. *.edu)';
$txt['ban_on_email'] = 'E-Posta Yasaklama (Örn. *@simplemachines.org)';
$txt['ban_on_username'] = 'Kullanıcı Adı Yasaklama';
$txt['ban_notes'] = 'Notlar';
$txt['ban_restriction'] = 'Uygulanılacak İşlem';
$txt['ban_full_ban'] = 'Tam Yasaklama';
$txt['ban_partial_ban'] = 'Kısmi Yasaklama';
$txt['ban_cannot_post'] = 'İleti gönderemesin';
$txt['ban_cannot_register'] = 'Üye olamasın';
$txt['ban_cannot_login'] = 'Giriş yapamasın';
$txt['ban_add'] = 'Ekle';
$txt['ban_edit_list'] = 'Yasaklama Listesi';
$txt['ban_type'] = 'Yasaklama Türü';
$txt['ban_days'] = 'gün';
$txt['ban_will_expire_within'] = 'Belirtilen zamandan sonra iptal edilsin:';
$txt['ban_added'] = 'Eklendi';
$txt['ban_expires'] = 'Zaman Aşımı';
$txt['ban_hits'] = 'Hitler';
$txt['ban_actions'] = 'İşlemler';
$txt['ban_expiration'] = 'Zaman Aşımı';
$txt['ban_reason_desc'] = 'Yasaklamanın nedenini belirtin, yasaklanan üyeye gösterilecektir';
$txt['ban_notes_desc'] = 'Diğer ekip üyelerini bilgilendirmek amacıyla notlar girebilirsiniz';
$txt['ban_remove_selected'] = 'Seçilenleri Sil';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_confirm'] = 'Seçilen yasaklamaları kaldırmak istediğinizden emin misiniz?';
$txt['ban_modify'] = 'Düzenle';
$txt['ban_name'] = 'Yasaklama ismi';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_edit'] = 'Yasaklamayı düzenle';
$txt['ban_add_notes'] = '<b>Not</b>: yukarıdaki yasaklamayı oluşturduktan sonra, yasaklamaya başka tetikleyiciler de ekleyebilirsiniz, IP adresleri, host adları ve e-mail adresleri gibi.';
$txt['ban_expired'] = 'Süresi dolmuş / kapatılmış';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_restriction_empty'] = 'Herhangi bir kısıtlama seçilmemiş.';

$txt['ban_triggers'] = 'Tetikleyiciler';
$txt['ban_add_trigger'] = 'Yasaklama tetikleyicisi ekle';
$txt['ban_add_trigger_submit'] = 'Ekle';
$txt['ban_edit_trigger'] = 'Düzenle';
$txt['ban_edit_trigger_title'] = 'Yasaklama tetikleyicisini düzenle';
$txt['ban_edit_trigger_submit'] = 'Düzenle';
$txt['ban_remove_selected_triggers'] = 'Seçili tetikleyicileri sil';
$txt['ban_no_entries'] = 'Yürürlükte yasak yok.';

// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['ban_remove_selected_triggers_confirm'] = 'Seçili tetikleyicileri silmek istediğinizden emin misiniz?';
$txt['ban_trigger_browse'] = 'Tetikleyicilere gözat';
$txt['ban_trigger_browse_description'] = 'Bu ekran tüm yasaklanmış girdileri gösterir (IP adresi, host adı, email adresi ve kullanıcı adı.';

$txt['ban_log'] = 'Yasaklama Kayıtları';
$txt['ban_log_description'] = 'Yasaklanan kullanıcı, IP yada e-posta adresinden yapılan işlemleri burada izleyebilirsiniz.';
$txt['ban_log_no_entries'] = 'Herhangi bir ban kaydı yok.';
$txt['ban_log_ip'] = 'IP';
$txt['ban_log_email'] = 'E-Posta Adresi';
$txt['ban_log_member'] = 'Üye';
$txt['ban_log_date'] = 'Tarih';
$txt['ban_log_remove_all'] = 'Tümünü Sil';
$txt['ban_log_remove_all_confirm'] = 'Tüm yasaklama kayıtlarının silinmesini istiyor musunuz?';
$txt['ban_log_remove_selected'] = 'Seçileni Sil';
$txt['ban_log_remove_selected_confirm'] = 'Seçilen tüm yasaklama kayıtlarının silinmesini istiyor musunuz?';
$txt['ban_no_triggers'] = 'Yasaklama tetikleyicisi yok.';

$txt['settings_not_writable'] = 'Bu ayarlar Settings.php dosyası yazılabilir olmadığı için kaydedilemedi.';

$txt['maintain_title'] = 'Forum Bakımı';
$txt['maintain_info'] = 'Bu bölüm aracılığıyla veritabanı tablolarını iyileştirebilir, forum yedekleri alabilir, oluşmuş olabilecek hataları kontrol edebilir, ve bölümleri temizleyebilirsiniz.';
$txt['maintain_sub_database'] = 'Veritabanı';
$txt['maintain_sub_routine'] = 'Rutin';
$txt['maintain_sub_members'] = 'Üyeler';
$txt['maintain_sub_topics'] = 'Konular';
$txt['maintain_done'] = '\'%1$s\' bakım görevi  başarılı bir şekilde gerçekleştirilmiştir';
$txt['maintain_no_errors'] = 'Tebrikler, hiç hataya rastlanmadı!  Kontrol için teşekkürler.';

$txt['maintain_tasks'] = 'Zamanlanmış Görevler';
$txt['maintain_tasks_desc'] = 'Bu bölümü kullanarak SMF tarafından zamanlanmış işlemleri yönetebilirsiniz.';

$txt['scheduled_log'] = 'Görev Günlüğü';
$txt['scheduled_log_desc'] = 'Şimdiye kadar tamamlanmış görevlerin günlüklerini listeler.';
$txt['admin_log'] = 'Yönetim Kaydı';
$txt['admin_log_desc'] = 'Yöneticileriniz tarafından yapılmış yönetimsel eylemlerin bir kaydını tutar.';
$txt['moderation_log'] = 'Moderasyon kaydı';
$txt['moderation_log_desc'] = 'Moderatörleriniz tarafından yapılmış moderasyon eylemlerinin bir kaydını tutar.';
$txt['spider_log_desc'] = 'Forumunuzdaki arama motoru örümcek aktivitesi girdilerini gözden geçirin.';
$txt['pruning_log_desc'] = 'Çeşitli kayıtlardaki girdileri temizlemek için bu araçları kullanın.';

$txt['mailqueue_title'] = 'E-Posta';

$txt['db_error_send'] = 'MySQL bağlantı hatalarını e-posta ile gönder';
$txt['db_persist'] = 'Sürekli bir bağlantı oluştur';
$txt['ssi_db_user'] = 'Veritabanı Kullanıcı Adı (SSI):';
$txt['ssi_db_passwd'] = 'Veritabanı Parolası (SSI):';

$txt['default_language'] = 'Forum\'un Varsayılan Dili:';

$txt['maintenance_subject'] = 'Görüntülenecek Başlık';
$txt['maintenance_message'] = 'Görüntülenecek İleti';

$txt['errlog_desc'] = 'Forumunuzun veritabanında sakladığı hata iletilerinin listesi aşağıdadır. Veritabanından silmek istediğiniz hata iletilerini işaretleyin ve en alttaki %s tuşuna basın.';
$txt['errlog_no_entries'] = 'Şu anda hata kaydı bulunmamaktadır.';

$txt['theme_settings'] = 'Tema Ayarları';
$txt['theme_current_settings'] = 'Kullanılan Tema';

$txt['dvc_your'] = 'Kullandığınız Sürüm';
$txt['dvc_current'] = 'Güncel Sürüm';
$txt['dvc_sources'] = 'Kaynak Dosyaları';
$txt['dvc_default'] = 'Varsayılan Tema';
$txt['dvc_templates'] = 'Güncel Temalar';
$txt['dvc_languages'] = 'Dil Dosyaları';

$txt['smileys_default_set_for_theme'] = 'Bu tema için varsayılan gülümseme setini seçin';
$txt['smileys_no_default'] = '(varsayılan seti kullan)';

$txt['censor_test'] = 'Sansürlenen Kelimeleri Deneyin';
$txt['censor_test_save'] = 'Dene';
$txt['censor_case'] = 'Büyük/küçük harf farkını yoksay';
$txt['censor_whole_words'] = 'Sadece tüm kelimeleri kontrol et';

$txt['admin_confirm_password'] = '(onayla)';
$txt['admin_incorrect_password'] = 'Geçersiz Şifre';

$txt['date_format'] = '(YYYY-AA-GG)';
$txt['undefined_gender'] = 'Tanımlanmamış';
$txt['age'] = 'Yaşı';
$txt['activation_status'] = 'Aktivasyon Durumu';
$txt['activated'] = 'Aktifleştirilmiş';
$txt['not_activated'] = 'Aktifleştirilmemiş';
$txt['primary'] = 'Birincil';
$txt['additional'] = 'İkincil';
$txt['messenger_address'] = 'Messenger Adresi';
$txt['wild_cards_allowed'] = 'Joker olarak * ve ? kullanabilirsiniz';
$txt['search_for'] = 'Aranılacak';
$txt['member_part_of_these_membergroups'] = 'Aranılacak kullanıcının kayıtlı olduğu üye grupları';
$txt['membergroups'] = 'Üye Grubu';
$txt['confirm_delete_members'] = 'Seçili üyeleri silmek istediğinizden emin misiniz?';

$txt['support_credits_title'] = 'Destek ve Hazırlayanlar';
$txt['support_credits_info'] = 'Sıkça rastlanan konular hakkında destek alabilir, istendiğinde verilmek üzere forum sürümünüzü öğrenebilirsiniz.';
$txt['support_title'] = 'Destek Bilgileri';
$txt['support_versions_current'] = 'Güncel SMF Sürümü';
$txt['support_versions_forum'] = 'Forum Sürümü';
$txt['support_versions_php'] = 'PHP Sürümü';
$txt['support_versions_db'] = '%s sürümü';
$txt['support_versions_server'] = 'Sunucu Sürümü';
$txt['support_versions_gd'] = 'GD sürümü';
$txt['support_versions'] = 'Sürüm Bilgileri';
$txt['support_resources'] = 'Yardım Kaynakları';
$txt['support_resources_p1'] = '<a href="%1$s">Çevrimiçi El Kitabı</a>\\\'mız, SMF hakkındaki ana dökümantasyonu sağlamaktadır. Çevrimiçi El Kitabı, yardım sorularınıza cevap bulabilmenize yardım edebilecek birçok döküman bulunduruyor ve <a href="%2$s">Özellikleri</a>, <a href="%3$s">Ayarları</a>, <a href="%4$s">Temaları</a>, <a href="%5$s">Paketleri</a> vs. açıklıyor. Çevrimiçi El Kitabı dökümanları sorularınıza hızlıca cevap verir.';
$txt['support_resources_p2'] = 'Eğer cevaplarınızı Çevrimiçi El Kitabı\\\'nda bulamıyorsanız, <a href="%1$s">Yardım Topluluğu</a>\\\'muzda bir arama yapabilirsiniz veya <a href="%2$s">İngilizce</a> olarak veya <a href="%3$s">uluslararası yardım bölümleri</a>\\\'nden birinden yardım isteyebilirsiniz. SMF Yardım Topluluğu, <a href="%4$s">yardım</a>, <a href="%5$s">kişiselleştirme</a>, SMF hakkında tartışma gibi birçok şey, hosting sağlayıcı bulma ve yöneticilik sorunlarını diğer forum yöneticileriyle tartışma için kullanılabilir.';

$txt['support_latest'] = 'Sıkça Rastlanan Sorunlar';
$txt['support_latest_fetch'] = 'Destek bilgileri alınıyor...';

$txt['edit_permissions_info'] = 'Kısıtlama ve özellikleri genel veya özel olarak bölümlere uygulayabilirsiniz.';
$txt['membergroups_members'] = 'Normal Üyeler';
$txt['membergroups_guests'] = 'Ziyaretçiler';
$txt['membergroups_guests_na'] = 'Yok';
$txt['membergroups_add_group'] = 'Grup ekle';
$txt['membergroups_permissions'] = 'İzinler';

$txt['permitgroups_restrict'] = 'Kısıtlı';
$txt['permitgroups_standard'] = 'Standart';
$txt['permitgroups_moderator'] = 'Moderatör';
$txt['permitgroups_maintenance'] = 'Bakım';
$txt['permitgroups_inherit'] = 'Devir Alınmış';

$txt['confirm_delete_attachments_all'] = 'Tüm eklentileri silmek istediğinizden emin misiniz?';
$txt['confirm_delete_attachments'] = 'Seçilen eklentileri silmek istediğinizden emin misiniz?';
$txt['attachment_manager_browse_files'] = 'Dosyaları Araştır';
$txt['attachment_manager_repair'] = 'Bakım Yap';
$txt['attachment_manager_avatars'] = 'Avatarlar';
$txt['attachment_manager_attachments'] = 'Eklentiler';
$txt['attachment_manager_thumbs'] = 'Küçük Resimler';
$txt['attachment_manager_last_active'] = 'Son Aktif Olma';
$txt['attachment_manager_member'] = 'Üye';
$txt['attachment_manager_avatars_older'] = 'Üyelerin avatarları belirtilen günden eski ise';
$txt['attachment_manager_total_avatars'] = 'Toplam Avatar';

$txt['attachment_manager_avatars_no_entries'] = 'Şu anda avatar yok.';
$txt['attachment_manager_attachments_no_entries'] = 'Şu anda eklenti yok.';
$txt['attachment_manager_thumbs_no_entries'] = 'Şu anda önizleme yok.';

$txt['attachment_manager_settings'] = 'Eklenti Ayarları';
$txt['attachment_manager_avatar_settings'] = 'Avatar Ayarları';
$txt['attachment_manager_browse'] = 'Dosyalara Gözat';
$txt['attachment_manager_maintenance'] = 'Dosya Bakımı';
$txt['attachment_manager_save'] = 'Kaydet';

$txt['attachmentEnable'] = 'Eklenti Ayarları';
$txt['attachmentEnable_deactivate'] = 'Eklentileri devre dışı bırak';
$txt['attachmentEnable_enable_all'] = 'Tüm eklentileri aktifleştir';
$txt['attachmentEnable_disable_new'] = 'Yeni eklentileri devre dışı bırak';
$txt['attachmentCheckExtensions'] = 'Eklentilerin uzantısını kontrol et';
$txt['attachmentExtensions'] = 'İzin verilen eklenti uzantıları';
$txt['attachmentRecodeLineEndings'] = 'Metin eklentilerinde satır sonlarını tekrar kodla';
$txt['attachmentShowImages'] = 'İletinin altında resim eklentilerinin önizlemesini göster';
$txt['attachmentEncryptFilenames'] = 'Kaydedilen dosya isimlerini şifrele';
$txt['attachmentUploadDir'] = 'Eklenti dizini<div class="smalltext"><a href="' . $scripturl . '?action=admin;area=manageattachments;sa=attachpaths">Birden fazla eklenti dizini yapılandır</a></div>';
$txt['attachmentUploadDir_multiple'] = 'Eklenti dizini';
$txt['attachmentUploadDir_multiple_configure'] = '<a href="' . $scripturl . '?action=admin;area=manageattachments;sa=attachpaths">[Birden fazla eklenti dizini yapılandır]</a>';
$txt['attachmentDirSizeLimit'] = 'Eklenti klasörünün maks. boyutu';
$txt['attachmentPostLimit'] = 'Her bir iletideki eklentinin maks. boyutu';
$txt['attachmentSizeLimit'] = 'Her bir eklentinin maks. boyutu';
$txt['attachmentNumPerPostLimit'] = 'Her bir iletideki maks. eklenti sayısı';
$txt['attachment_gd_warning'] = 'GD modülü şu anda yüklü değildir. Resim şifrelemesi mümkün değildir.';
$txt['attachment_image_reencode'] = 'Ekteki resimlerin tekrar-şifrelenmesi potansiyel tehlikedir';
$txt['attachment_image_reencode_note'] = '(GD modülü gereklidir)';
$txt['attachment_image_paranoid_warning'] = 'Kapsamlı güvenlik kontrolü, büyük sayıda rededilmiş eklerin ortaya çıkmasına yol açar.';
$txt['attachment_image_paranoid'] = 'Yüklenmiş resim ekleri üzerinde kapsamlı güvenlik kontrolü gerçekleştir';
$txt['attachmentThumbnails'] = 'İletinin altında gösterilen resimleri yeniden boyutlandır';
$txt['attachment_thumb_png'] = 'Küçükresimleri PNG olarak kaydet';
$txt['attachmentThumbWidth'] = 'Küçük Resmin maks. genişliği';
$txt['attachmentThumbHeight'] = 'Küçük Resmin maks. yüksekliği';

$txt['attach_dir_does_not_exist'] = 'Bulunamadı';
$txt['attach_dir_not_writable'] = 'Yazılabilir-Değil';
$txt['attach_dir_files_missing'] = 'Kayıp Dosyalar Var (<a href="' . $scripturl . '?action=admin;area=manageattachments;sa=repair;sesc=%1$s">Tamir Et</a>)';
$txt['attach_dir_unused'] = 'Kullanılmıyor';
$txt['attach_dir_ok'] = 'TAMAM';

$txt['attach_path_manage'] = 'Eklenti Adreslerini Yönet';
$txt['attach_paths'] = 'Eklenti Adresleri';
$txt['attach_current_dir'] = 'Şimdiki Klasör';
$txt['attach_path'] = 'Adres';
$txt['attach_current_size'] = 'Boyut (KB)';
$txt['attach_num_files'] = 'Dosyalar';
$txt['attach_dir_status'] = 'Durum';
$txt['attach_add_path'] = 'Adres Ekle';
$txt['attach_path_current_bad'] = 'Geçersiz eklenti adresi.';

$txt['mods_cat_avatars'] = 'Avatarlar';
$txt['avatar_directory'] = 'Avatar Dizini';
$txt['avatar_url'] = 'Avatar URL\'si';
$txt['avatar_dimension_note'] = '(0 = limit yok)';
$txt['avatar_max_width_external'] = 'Dışardan seçilen avatarın maks. genişliği';
$txt['avatar_max_height_external'] = 'Dışardan seçilen avatarın maks. yüksekliği';
$txt['avatar_action_too_large'] = 'Eğer avatar çok büyükse...';
$txt['option_refuse'] = 'Kabul etme';
$txt['option_html_resize'] = 'HTML ile yeniden boyutlandır';
$txt['option_js_resize'] = 'JavaScript ile yeniden boyutlandır';
$txt['option_download_and_resize'] = 'Yükle ve yeniden boyutlandır (GD modülü gerektirir)';
$txt['avatar_max_width_upload'] = 'Yüklenen avatarın maks. genişliği';
$txt['avatar_max_height_upload'] = 'Yüklenen avatarın maks. yüksekliği';
$txt['avatar_resize_upload'] = 'Büyük avatarları yeniden boyutlandır';
$txt['avatar_resize_upload_note'] = '(GD modülü gerekiyor)';
$txt['avatar_download_png'] = 'Yeniden boyutlandırılan avatarlar için PNG kullan';
$txt['avatar_gd_warning'] = 'GD modülü yüklü değil. Bazı avatar özellikleri devre dışı bırakılacak.';
$txt['avatar_external'] = 'Harici Avatarlar';
$txt['avatar_upload'] = 'Yüklenebilir Avatarlar';
$txt['avatar_server_stored'] = 'Sunucuda Kayıtlı Avatarlar';
$txt['avatar_server_stored_groups'] = 'Sunucuda bulunan avatar\'ları kullanmaya yetkili üye grupları';
$txt['avatar_upload_groups'] = 'Kendi avatar\'larını sunucuya yüklemeye yetkili üye grupları';
$txt['avatar_external_url_groups'] = 'Başka bir sunucuda bulunan avatar\'ları kullanmaya yetkili üye grupları';
$txt['avatar_select_permission'] = 'Yetkili Grupları Belirlemek İçin Tıklayınız';
$txt['avatar_download_external'] = 'Verilmiş adresteki avatar\'ı sunucuya yükle';
$txt['custom_avatar_enabled'] = 'Avatarı yükle...';
$txt['option_attachment_dir'] = 'Dosya eki dizini';
$txt['option_specified_dir'] = 'Belirli dizine...';
$txt['custom_avatar_dir'] = 'Yükleme Dizini';
$txt['custom_avatar_dir_desc'] = 'Bu klasör sunucuların avatarları bulunduruduğu klasör ile aynı olmamalı.';
$txt['custom_avatar_url'] = 'Yükleme Adresi';
$txt['custom_avatar_check_empty'] = 'Belirttiğiniz özel avatar dizini boş veya geçersiz. Lütfen ayarların doğru olup olmadıklarını kontrol ediniz.';
$txt['avatar_reencode'] = 'Avatarların tekrar-şifrelenmesi potansiyel tehlikedir';
$txt['avatar_reencode_note'] = '(GD modülü gereklidir)';
$txt['avatar_paranoid_warning'] = 'Kapsamlı güvenlik kontrolü, büyük sayıda rededilmiş avatarların ortaya çıkmasına yol açar.';
$txt['avatar_paranoid'] = 'Yüklenmiş avatarlar üstünde kapsamlı güvenlik kontrolü uygula';

$txt['repair_attachments'] = 'Eklentilere Bakım Yap';
$txt['repair_attachments_complete'] = 'Bakım Tamamlandı';
$txt['repair_attachments_complete_desc'] = 'Seçilmiş tüm hatalar düzeltildi.';
$txt['repair_attachments_no_errors'] = 'Hiç hataya rastlanmadı!';
$txt['repair_attachments_error_desc'] = 'Bakım sırasında aşağıdaki hatalar bulundu. Düzeltmek istediğiniz hataları, yanındaki kutucuğa tıklayarak seçin.';
$txt['repair_attachments_continue'] = 'Devam Et';
$txt['repair_attachments_cancel'] = 'İptal';
$txt['attach_repair_missing_thumbnail_parent'] = '%d adındaki küçük resimlerin ana eklentileri eksik';
$txt['attach_repair_parent_missing_thumbnail'] = '%d küçük resme sahip olarak gösterilmiş, ama küçük resim bulunmamakta';
$txt['attach_repair_file_missing_on_disk'] = '%d eklenti/avatar var olarak gözükmekte ama aslında diskte görünmemekte';
$txt['attach_repair_file_wrong_size'] = '%d eklenti/avatarın boyutu yanlış kaydedilmiş';
$txt['attach_repair_file_size_of_zero'] = '%d eklenti/avatarın boyutu 0 olarak gözükmekte. (Silinecek)';
$txt['attach_repair_attachment_no_msg'] = '%1$d eklentinin kendileri ile bağlantılı iletileri bulunmamakta';
$txt['attach_repair_avatar_no_member'] = '%1$d eklentinin kendileri ile bağlantılı kullanıcıları bulunmamakta';
$txt['attach_repair_wrong_folder'] = '%1$d eklenti yanlış klasörde bulunmakta';

$txt['news_title'] = 'Haberler ve Bültenler';
$txt['news_settings_desc'] = 'Burada haberler ve haber bültenlerine ait ayarlarda ve izinlerde değişiklikler yapabilirsiniz.';
$txt['news_settings_submit'] = 'Kaydet';
$txt['news_mailing_desc'] = 'Burayı kullanarak kayıtlı tüm üyelere e-posta gönderebilirsiniz. Önemli duyuruları ve haberleri göndermek için ideal bir yöntemdir.';
$txt['groups_edit_news'] = 'Haberleri düzenlemeye izinli gruplar';
$txt['groups_send_mail'] = 'Haberleri göndermeye izinli gruplar';
$txt['xmlnews_enable'] = 'XML/RSS haberlerini aktif et';
$txt['xmlnews_maxlen'] = 'Max mesaj uzunluğu: <div class="smalltext">(0 devre dışı - kötü fikir.)</div>';
$txt['editnews_clickadd'] = 'Yeni Haber Ekle';
$txt['editnews_remove_selected'] = 'Seçilenleri Sil';
$txt['editnews_remove_confirm'] = 'Seçilen öğeleri silmek istediğinizden emin misiniz?';
$txt['censor_clickadd'] = 'Yeni Bir Kelime Ekle';

$txt['layout_controls'] = 'Forum';
$txt['logs'] = 'Kayıtlar';
$txt['generate_reports'] = 'Raporlar';

$txt['update_available'] = 'Yeni Bir Güncelleme Mevcut!';
$txt['update_message'] = 'Hatalar ve sorunlar içeren eski bir SMF sürümü kullanmaktasınız.
	Kısa zamanda forumunuzu en son sürümüne <a href="" id="update-link">güncellemenizi</a> önerilir.';

$txt['manageposts'] = 'İletiler ve Konular';
$txt['manageposts_title'] = 'İletileri ve Konuları Yönet';
$txt['manageposts_description'] = 'Burada iletiler ve konularla ilgili tüm ayarları değiştirebilirsiniz.';

$txt['manageposts_seconds'] = 'saniye';
$txt['manageposts_minutes'] = 'dakika';
$txt['manageposts_characters'] = 'karakter';
$txt['manageposts_days'] = 'gün';
$txt['manageposts_posts'] = 'ileti';
$txt['manageposts_topics'] = 'konu';

$txt['manageposts_settings'] = 'İleti Ayarları';
$txt['manageposts_settings_description'] = 'Burada iletiler ve ileti gönderme ile ilgili birçok seçeneği değiştirebilirsiniz.';
$txt['manageposts_settings_submit'] = 'Kaydet';

$txt['manageposts_bbc_settings'] = 'BBC';
$txt['manageposts_bbc_settings_description'] = 'Bulletin board code (BBC) forumdaki yazılara bazı efektler uygulamak için kullanılabilir. Örneğin, \'ev\' kelimesini kalın göstermek için [b]ev[/b] şeklinde yazabilirsiniz. Tüm Bulletin board code (BBC) etiketleri kare parantezler (\'[\' and \']\') ile çevrilidirler.';
$txt['manageposts_bbc_settings_title'] = 'Bulletin Board Code Ayarları';
$txt['manageposts_bbc_settings_submit'] = 'Kaydet';

$txt['manageposts_topic_settings'] = 'Konu Ayarları';
$txt['manageposts_topic_settings_description'] = 'Burada konularla ilgili birçok seçeneği değiştirebilirsiniz.';
$txt['manageposts_topic_settings_submit'] = 'Kaydet';

$txt['removeNestedQuotes'] = 'Alıntı yaparken içiçe olan alıntıları kaldır';
$txt['enableEmbeddedFlash'] = 'İletilerin içinde Flash\'e izin ver';
$txt['enableEmbeddedFlash_warning'] = 'Güvenlik riski oluşturabilir!';
$txt['enableSpellChecking'] = 'Yazım denetimi aktif';
$txt['enableSpellChecking_warning'] = 'Tüm sunucularda çalışmayabilir!';
$txt['disable_wysiwyg'] = 'WYSIWYG editörü devre dışı bırak';
$txt['max_messageLength'] = 'İletilerde izin verilen en fazla karakter';
$txt['max_messageLength_zero'] = '(0 - sınırsız.)';
$txt['fixLongWords'] = 'Bir kelimenin bölünmeden önce sahip olacağı en fazla karakter';
$txt['fixLongWords_zero'] = '(0 - sınırsız)';
$txt['fixLongWords_warning'] = 'tüm sunucularda çalışmayabilir!';
$txt['topicSummaryPosts'] = 'Konu özetinde gösterilecek en fazla ileti';
$txt['spamWaitTime'] = 'Aynı IP adresinden gönderilecek iki ileti arasındaki zaman limiti';
$txt['edit_wait_time'] = 'Düzenleme yapılabilmesi için beklenecek süre';
$txt['edit_disable_time'] = 'İleti gönderildikten sonra düzenleme yapılabilecek maksimum süre';
$txt['edit_disable_time_zero'] = '(0 - sınırsız)';

$txt['enableBBC'] = 'BBC kullanılmasına izin ver';
$txt['enablePostHTML'] = 'İletilerde <i>basit</i> HTML kodlarına izin ver';
$txt['autoLinkUrls'] = 'URL\'leri bağlantılara çevir';
$txt['disabledBBC'] = 'Devre Dışı BBC Etiketleri';
$txt['bbcTagsToUse'] = 'Aktif BBC Etiketleri';
$txt['bbcTagsToUse_select'] = 'Kullanılmasına izin verilecek etiketleri seç';
$txt['bbcTagsToUse_select_all'] = 'Tüm etiketleri seç';

$txt['enableStickyTopics'] = 'Sabit konulara izin ver';
$txt['enableParticipation'] = 'Katılım ikonlarına izin ver';
$txt['oldTopicDays'] = 'Bir konuya yanıt verilebilecek maksimum süre';
$txt['oldTopicDays_zero'] = '0 - sınırsız';
$txt['defaultMaxTopics'] = 'Bir sayfada gösterilecek en fazla konu';
$txt['defaultMaxMessages'] = 'Bir konuda gösterilecek en fazla ileti';
$txt['hotTopicPosts'] = 'Beğenilen konu değeri';
$txt['hotTopicVeryPosts'] = 'Çok beğenilen konu değeri';
$txt['enableAllMessages'] = 'Gösterilecek en çok yanıt sayısı:';
$txt['enableAllMessages_zero'] = '0 yaparsanız "Tümü" gözükmeyecektir';
$txt['disableCustomPerPage'] = 'Sayfa başına özel konu/ileti seçeneğini devre dışı bırak';
$txt['enablePreviousNext'] = 'Önceki/Sonraki konu bağlantıları aktif';

$txt['not_done_title'] = 'İşlem henüz tamamlanamadı!';
$txt['not_done_reason'] = 'Sunucunuza aşırı yüklenmemek için, işlem geçici olarak durduruldu. Birkaç saniye içinde kaldığı yerden devam edecektir.  Eğer etmez ise, lütfen aşağıdaki Devam Et tuşuna basınız.';
$txt['not_done_continue'] = 'Devam Et';

$txt['general_settings'] = 'Genel';
$txt['database_paths_settings'] = 'Veritabanı ve dosya yolları';
$txt['cookies_sessions_settings'] = 'Çerezler ve Oturumlar';
$txt['caching_settings'] = 'Önbellek Ayarları';
$txt['load_balancing_settings'] = 'Yükleme Dengeleyici';

$txt['language_configuration'] = 'Diller';
$txt['language_description'] = 'Bu bölüm forumunuzda kurulu olan dilleri düzenlemenizi sağlar. Simple Machines sitesinden farklı diller de indirebilirsiniz.
Ayrıca bu bölümden dille ilgili ayarları da yapabilirsiniz';
$txt['language_edit'] = 'Dilleri Düzenle';
$txt['language_add'] = 'Dil Ekle';
$txt['language_settings'] = 'Ayarlar';

$txt['advanced'] = 'Gelişmiş Seçenekler';
$txt['simple'] = 'Basit Seçenekler';

$txt['admin_news_select_recipients'] = 'Bu bölümü kullanarak bültenin yollanacağı kişileri belirtebilirsiniz:';
$txt['admin_news_select_group'] = 'Üye Grupları';
$txt['admin_news_select_group_desc'] = 'Bültenin yollanacağı grupları seçiniz.';
$txt['admin_news_select_members'] = 'Üyeler';
$txt['admin_news_select_members_desc'] = 'Bültenin ek olarak yollanacağı üyeleri seçiniz.';
$txt['admin_news_select_excluded_members'] = 'Hariç Tutulacak Üyeler';
$txt['admin_news_select_excluded_members_desc'] = 'Bültenin yollanmayacağı üyeler.';
$txt['admin_news_select_excluded_groups'] = 'Hariç Tutulacak Gruplar';
$txt['admin_news_select_excluded_groups_desc'] = 'Bültenin yollanmayacağı üye grupları.';
$txt['admin_news_select_email'] = 'E-Posta Adresleri';
$txt['admin_news_select_email_desc'] = 'Bülten üyeler dışında başka kişilere yollanacaksa, kişilerin e-posta adresleri noktalı virgülle ayrılarak buraya girilmelidir. (örn. eren@doom9.org; forsakenlad@simplemachines.org)';
$txt['admin_news_select_override_notify'] = 'Bilgilendirme Seçeneklerini Yoksay';
// Use entities in below.
$txt['admin_news_cannot_pm_emails_js'] = 'E-posta adresine kişisel ileti gönderemezsiniz. Eğer devam edersiniz girilmiş tüm e-posta adresleri yoksayılacaktır.\\n\\nDevam etmek istediğinize emin misiniz?';

$txt['mailqueue_browse'] = 'Sırayı Görüntüle';
$txt['mailqueue_settings'] = 'Ayarlar';

$txt['admin_search'] = 'Hızlı Arama';
$txt['admin_search_type_internal'] = 'Görev/Ayar';
$txt['admin_search_type_member'] = 'Üye';
$txt['admin_search_type_online'] = 'Çevrimiçi Kılavuz';
$txt['admin_search_go'] = 'Git';
$txt['admin_search_results'] = 'Arama Sonuçları';
$txt['admin_search_results_desc'] = 'Araması yapılan sözcük: &quot;%1$s&quot;';
$txt['admin_search_results_again'] = 'Tekrar ara';
$txt['admin_search_results_none'] = 'Sonuç bulunamadı!';

$txt['admin_search_section_sections'] = 'Bölüm';
$txt['admin_search_section_settings'] = 'Ayar';

$txt['core_settings_title'] = 'Çekirdek Ayarlar';
$txt['mods_cat_features'] = 'Genel';
$txt['mods_cat_security_general'] = 'Güvenlik';
$txt['antispam_title'] = 'Spam Koruması';
$txt['mods_cat_modifications_misc'] = 'Çeşitli';
$txt['mods_cat_layout'] = 'Görünüm';
$txt['karma'] = 'Karma';
$txt['moderation_settings_short'] = 'Moderasyon';
$txt['signature_settings_short'] = 'İmzalar';
$txt['custom_profile_shorttitle'] = 'Profil Alanları';
$txt['pruning_title'] = 'Kayıt Temizleme';

$txt['boardsEdit'] = 'Bölümleri Düzenle';
$txt['mboards_new_cat'] = 'Yeni kategori oluştur';
$txt['manage_holidays'] = 'Tatilleri Yönet';
$txt['calendar_settings'] = 'Takvim Ayarları';
$txt['search_weights'] = 'Ağırlıklar';
$txt['search_method'] = 'Arama metodu';

$txt['smiley_sets'] = 'Gülümseme Setleri';
$txt['smileys_add'] = 'Gülümseme Ekle';
$txt['smileys_edit'] = 'Gülümsemeleri Düzenle';
$txt['smileys_set_order'] = 'Gülümseme sıralamasını belirle';
$txt['icons_edit_message_icons'] = 'İleti İkonlarını Düzenle';

$txt['membergroups_new_group'] = 'Kullanıcı Grubu Ekle';
$txt['membergroups_edit_groups'] = 'Kullanıcı Gruplarını Düzenle';
$txt['permissions_groups'] = 'Üye Grubuna Göre İzinler';
$txt['permissions_boards'] = 'Bölüme Göre İzinler';
$txt['permissions_profiles'] = 'Profilleri Düzenle';
$txt['permissions_post_moderation'] = 'İleti Moderasyonu';

$txt['browse_packages'] = 'Paketleri Görüntüle';
$txt['download_packages'] = 'Paket İndir';
$txt['installed_packages'] = 'Yüklü Paketler';
$txt['package_file_perms'] = 'Dosya İzinleri';
$txt['package_settings'] = 'Seçenekler';
$txt['themeadmin_admin_title'] = 'Yönet ve Yükle';
$txt['themeadmin_list_title'] = 'Tema Ayarları';
$txt['themeadmin_reset_title'] = 'Üye Seçenekleri';
$txt['themeadmin_edit_title'] = 'Temaları Düzenle';
$txt['admin_browse_register_new'] = 'Yeni üye kaydet';

$txt['search_engines'] = 'Arama Motorları';
$txt['spiders'] = 'Örümcekler';
$txt['spider_logs'] = 'Kayıtlar';
$txt['spider_stats'] = 'İstatistikler';

$txt['paid_subscriptions'] = 'Ücretli Abonelikler';
$txt['paid_subs_view'] = 'Abonelikleri Görüntüle';

?>