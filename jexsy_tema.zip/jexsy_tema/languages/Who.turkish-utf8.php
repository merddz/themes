<?php

// Version: 2.0; Who



global $scripturl, $context;



$txt['who_hidden'] = '<em>Hiçbir şey veya görüntülemeye yetkiniz yok..</em>';

$txt['who_unknown'] = '<em>Bilinmeyen Eylem</em>';

$txt['who_user'] = 'Kullanıcı';

$txt['who_time'] = 'Zaman';

$txt['who_action'] = 'Eylem';

$txt['who_show1'] = 'Göster';

$txt['who_show_members_only'] = 'Sadece Üyeler';

$txt['who_show_guests_only'] = 'Sadece Ziyaretçiler';

$txt['who_show_spiders_only'] = 'Sadece Örümcekler';

$txt['who_show_all'] = 'Herkes';

$txt['who_no_online_spiders'] = 'Şu anda herhangi bir örümcek çevrimiçi değildir.';

$txt['who_no_online_guests'] = 'Şu anda herhangi bir ziyaretçi çevrimiçi değildir.';

$txt['who_no_online_members'] = 'Şu anda herhangi bir üye çevrimiçi değildir.';



$txt['whospider_login'] = 'Giriş sayfasını görüntülüyor.';

$txt['whospider_register'] = 'Kayıt sayfasını görüntülüyor.';

$txt['whospider_reminder'] = 'Hatırlatma sayfasını görüntülüyor.';



$txt['whoall_activate'] = 'Hesabını etkinleştiriyor.';

$txt['whoall_buddy'] = 'Arkadaş listesini düzenliyor.';

$txt['whoall_coppa'] = 'Veli izni formunu dolduruyor.';

$txt['whoall_credits'] = 'Hazırlayanlar sayfasını görüntülüyor.';

$txt['whoall_emailuser'] = 'Başka bir üyeye e-posta gönderiyor.';

$txt['whoall_groups'] = 'Üye grupları sayfasını görüntülüyor.';

$txt['whoall_help'] = '<a href="' . $scripturl . '?action=help">Yardım</a> sayfasına bakıyor.';

$txt['whoall_helpadmin'] = 'Yardım iletisine bakıyor.';

$txt['whoall_pm'] = 'İletilerine bakıyor.';

$txt['whoall_login'] = 'Giriş yapıyor.';

$txt['whoall_login2'] = 'Giriş yapıyor.';

$txt['whoall_logout'] = 'Çıkış yapıyor.';

$txt['whoall_markasread'] = 'Konuları okunmuş sayıyor.';

$txt['whoall_modifykarma_applaud'] = 'Bir üyenin karmasını arttırıyor.';

$txt['whoall_modifykarma_smite'] = 'Bir üyenin karmasını azaltıyor.';

$txt['whoall_news'] = 'Haberlere bakıyor.';

$txt['whoall_notify'] = 'Haberdar edilme ayarlarını değiştiriyor.';

$txt['whoall_notifyboard'] = 'Haberdar edilme ayarlarını değiştiriyor.';

$txt['whoall_openidreturn'] = 'OpenID kullanarak giriş yapıyor.';

$txt['whoall_quickmod'] = 'Bir bölümü yönetiyor.';

$txt['whoall_recent'] = '<a href="' . $scripturl . '?action=recent">son iletilerin</a> listesine bakıyor.';

$txt['whoall_register'] = 'Foruma üye oluyor.';

$txt['whoall_register2'] = 'Foruma üye oluyor.';

$txt['whoall_reminder'] = 'Şifre hatırlatmayı kullanıyor.';

$txt['whoall_reporttm'] = 'Bölüm yöneticisine bir konuyu rapor ediyor.';

$txt['whoall_spellcheck'] = 'Yazım denetleyicisini kullanıyor';

$txt['whoall_unread'] = 'Son gelişinden bu yana gönderilmiş yeni iletilere bakıyor.';

$txt['whoall_unreadreplies'] = 'En son yanıtladığı konulara gelen iletilere bakıyor.';

$txt['whoall_who'] = '<a href="' . $scripturl . '?action=who">Kim nerede</a>\'ye bakıyor.';



$txt['whoall_collapse_collapse'] = 'Bölüm kapatıyor.';

$txt['whoall_collapse_expand'] = 'Bölüm açıyor.';

$txt['whoall_pm_removeall'] = 'Tüm kişisel iletilerini siliyor.';

$txt['whoall_pm_send'] = 'Kişisel ileti gönderiyor.';

$txt['whoall_pm_send2'] = 'Kişisel ileti gönderiyor.';

$txt['whoall_yonetim'] = '<a href="' . $scripturl . '?action=yonetim">Yönetici listesine</a> bakıyor.';


$txt['whotopic_announce'] = '"<a href="' . $scripturl . '?topic=%1$d.0">%2$s</a>" konusunu duyuruyor.';

$txt['whotopic_attachapprove'] = 'Bir eklentiyi onaylıyor.';

$txt['whotopic_dlattach'] = 'Eklentiye bakıyor.';

$txt['whotopic_deletemsg'] = 'Bir iletiyi siliyor.';

$txt['whotopic_editpoll'] = 'Anketi düzenliyor: "<a href="' . $scripturl . '?topic=%1$d.0">%2$s</a>".';

$txt['whotopic_editpoll2'] = '"<a href="' . $scripturl . '?topic=%1$d.0">%2$s</a>" konusundaki anketi düzenliyor.';

$txt['whotopic_jsmodify'] = '"<a href="' . $scripturl . '?topic=%1$d.0">%2$s</a>" konusunda bir iletiyi düzenliyor.';

$txt['whotopic_lock'] = '"<a href="' . $scripturl . '?topic=%1$d.0">%2$s</a>" konusunu kilitliyor.';

$txt['whotopic_lockvoting'] = '"<a href="' . $scripturl . '?topic=%1$d.0">%2$s</a>" konusundaki anketi kilitliyor.';

$txt['whotopic_mergetopics'] = '"<a href="' . $scripturl . '?topic=%1$d.0">%2$s</a>" konusunu başka bir konu ile birleştiriyor.';

$txt['whotopic_movetopic'] = '"<a href="' . $scripturl . '?topic=%1$d.0">%2$s</a>" konusunu başka bir bölüme taşıyor.';

$txt['whotopic_movetopic2'] = '"<a href="' . $scripturl . '?topic=%1$d.0">%2$s</a>" konusunu başka bir bölüme taşıyor.';

$txt['whotopic_post'] = '<a href="' . $scripturl . '?topic=%1$d.0">%2$s</a> konusuna yorum gönderiyor.';

$txt['whotopic_post2'] = '<a href="' . $scripturl . '?topic=%1$d.0">%2$s</a> konusuna yanıt veriyor.';

$txt['whotopic_printpage'] = '&quot;<a href="' . $scripturl . '?topic=%1$d.0">%2$s</a>&quot; konusunu yazdırıyor.';

$txt['whotopic_quickmod2'] = '"<a href="' . $scripturl . '?topic=%1$d.0">%2$s</a>" konusunu yönetiyor.';

$txt['whotopic_removepoll'] = '"<a href="' . $scripturl . '?topic=%1$d.0">%2$s</a>" konusundaki anketi kaldırıyor.';

$txt['whotopic_removetopic2'] = '"<a href="' . $scripturl . '?topic=%1$d.0">%2$s</a>" konusunu kaldırıyor.';

$txt['whotopic_sendtopic'] = '&quot;<a href="' . $scripturl . '?topic=%1$d.0">%2$s</a>&quot; konusunu arkadaşına gönderiyor.';

$txt['whotopic_splittopics'] = '&quot;<a href="' . $scripturl . '?topic=%1$d.0">%2$s</a>&quot; başlıklı konuyu bölüyor.';

$txt['whotopic_sticky'] = '"<a href="' . $scripturl . '?topic=%1$d.0">%2$s</a>" konusunu sabitleştiriyor.';

$txt['whotopic_vote'] = '<a href="' . $scripturl . '?topic=%1$d.0">%2$s</a> anketine oy veriyor.';



$txt['whopost_quotefast'] = '&quot;<a href="' . $scripturl . '?topic=%1$d.0">%2$s</a>&quot; konusundan alıntı yapıyor.';



$txt['whoadmin_editagreement'] = 'Üyelik sözleşmesini düzenliyor.';

$txt['whoadmin_featuresettings'] = 'Forum özellik ve seçeneklerini düzenliyor.';

$txt['whoadmin_modlog'] = 'Moderasyon günlüğünü görüntülüyor.';

$txt['whoadmin_serversettings'] = 'Sunucuyu ayarlarını düzenliyor.';

$txt['whoadmin_packageget'] = 'Paket indiriyor.';

$txt['whoadmin_packages'] = 'Paket yöneticisini görüntülüyor.';

$txt['whoadmin_permissions'] = 'İzinleri düzenliyor.';

$txt['whoadmin_pgdownload'] = 'Paket indiriyor.';

$txt['whoadmin_theme'] = 'Tema ayarlarını düzenliyor.';

$txt['whoadmin_trackip'] = 'IP adresi takip ediyor.';



$txt['whoallow_manageboards'] = 'Bölüm ayarlarını düzenliyor.';

$txt['whoallow_admin'] = '<a href="' . $scripturl . '?action=admin">Yönetici sayfası</a>na bakıyor.';

$txt['whoallow_ban'] = 'Yasaklılar listesini düzenliyor.';

$txt['whoallow_boardrecount'] = 'Forum toplamlarını tekrar hesaplıyor.';

$txt['whoallow_calendar'] = '<a href="' . $scripturl . '?action=calendar">Takvim</a>e bakıyor.';

$txt['whoallow_editnews'] = 'Haberleri düzenliyor.';

$txt['whoallow_mailing'] = 'Forumdan E-Posta gönderiyor.';

$txt['whoallow_maintain'] = 'Bakım yapıyor.';

$txt['whoallow_manageattachments'] = 'Eklentileri düzenliyor.';

$txt['whoallow_moderate'] = '<a href="' . $scripturl . '?action=moderate">Moderasyon Bölümü</a>\'nü görüntülüyor.';

$txt['whoallow_mlist'] = '<a href="' . $scripturl . '?action=mlist">Üye listesi</a>ne bakıyor.';

$txt['whoallow_optimizetables'] = 'Veritabanı tablolarını en iyi hale getiriyor.';

$txt['whoallow_repairboards'] = 'Veritabanı tablolarını onarıyor.';

$txt['whoallow_search'] = '<a href="' . $scripturl . '?action=search">Arama</a> yapıyor.';

$txt['whoallow_search2'] = 'Arama sonuçlarına bakıyor.';

$txt['whoallow_setcensor'] = 'Sansürlü kelimeleri düzenliyor.';

$txt['whoallow_setreserve'] = 'Ayrılmış isimleri düzenliyor.';

$txt['whoallow_stats'] = '<a href="' . $scripturl . '?action=stats">Forum İstatistikleri</a>ne bakıyor.';

$txt['whoallow_viewErrorLog'] = 'Hata iletilerine bakıyor.';

$txt['whoallow_viewmembers'] = 'Üye listesine bakıyor.';



$txt['who_topic'] = '<a href="' . $scripturl . '?topic=%1$d.0">%2$s</a> adlı konuya bakıyor.';

$txt['who_board'] = '<a href="' . $scripturl . '?board=%1$d.0">%2$s</a> adlı bölüme bakıyor.';

$txt['who_index'] = '<a href="' . $scripturl . '">' . $context['forum_name'] . '</a> ana sayfasına bakıyor.';

$txt['who_viewprofile'] = '<a href="' . $scripturl . '?action=profile;u=%1$d">%2$s</a> kullanıcısının profiline bakıyor.';

$txt['who_profile'] = '<a href="' . $scripturl . '?action=profile;u=%1$d">%2$s</a> kullanıcısının profilini düzenliyor.';

$txt['who_post'] = '<a href="' . $scripturl . '?board=%1$d.0">%2$s</a> bölümüne yeni konu açıyor.';

$txt['who_poll'] = '<a href="' . $scripturl . '?board=%1$d.0">%2$s</a> bölümüne yeni anket açıyor.';



// Credits text

$txt['credits'] = 'Hazırlayanlar - Ekip';

$txt['credits_intro'] = 'Simple Machines, SMF 2.0\' bugünkü haline getirmekte emeği olan herkese teşekkür etmek ister. Siz olmadan bunların hiçbiri mümkün olamazdı. Üyelerimize ve özellikle Charter üyelerimize buradan yazılımımızı yükledikleri, test ettikleri, geri bildirimde bulundukları ve önerileri için teşekkür ederiz.';

$txt['credits_team'] = 'Ekip';

$txt['credits_special'] = 'Özel Olarak Teşekkürler';

$txt['credits_and'] = 've';

$txt['credits_anyone'] = 'Ve atlamış olabileceğimiz herhangi biri, teşekkürler!';

$txt['credits_copyright'] = 'Telif Hakkı';

$txt['credits_forum'] = 'Forum';

$txt['credits_modifications'] = 'Modifikasyonlar';

$txt['credits_groups_ps'] = 'Proje Desteği';

$txt['credits_groups_dev'] = 'Geliştiriciler';

$txt['credits_groups_support'] = 'Destek Uzmanları';

$txt['credits_groups_customize'] = 'Kişiselleştiriciler';

$txt['credits_groups_docs'] = 'Doküman Yazarları';

$txt['credits_groups_marketing'] = 'Pazarlama';

$txt['credits_groups_internationalizers'] = 'Yerelleştirme';

$txt['credits_groups_servers'] = 'Sunucu Yöneticileri';

$txt['credits_groups_site'] = 'Site Yöneticileri';

// Replace "English" with the name of this language pack in the string below.

$txt['credits_groups_translation'] = 'Türkçe Çeviri';

$txt['credits_groups_translators'] = 'Çevirmenler';

$txt['credits_translators_message'] = 'SMF\'i dünyadaki herkes için kullanılabilir kıldığınız için teşekkürler.';

$txt['credits_groups_consultants'] = 'Yardımcı Geliştiriciler';

$txt['credits_groups_beta'] = 'Beta Tester\'lar';

$txt['credits_beta_message'] = 'Yorulmadan yazılım kusurlarını bulup geri bildirimde bulunan ve geliştiricileri deliye çeviren çok değerli beta grubu';

$txt['credits_groups_founder'] = 'SMF\'in Kurucusu';

$txt['credits_groups_orignal_pm'] = 'Orjinal Proje Yöneticileri';



// List of people who have made more than a token contribution to this translation. (blank for English)

$txt['translation_credits'] = array('ahmetem', 'Alperuzi', 'Alpay Tayfun', 'Antes', 'cnrdzn', 'Daydreamer', 'Eren Yaşarkurt', 'eslao', 'husmen73', '*Immortal*', 'Minare', 'Yağız', 'Elmacik');



?>