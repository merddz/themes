<?php
// Version: 2.0; Help

global $helptxt;

$txt['close_window'] = 'Pencereyi kapat';

$helptxt['manage_boards'] = '
	<b>Bölümeri düzenle</b><br />
	Bu menüde oda ve kategori ekleme/düzenleme/kaldırma işlemlerini 
	yapabilirsiniz. Örneğin, &quot;Spor&quot;,&quot;Araba&quot; ve &quot;Müzik&quot; ile ilgili
        oldukça geniş yelpazeli bir siteniz var ise bunlar sizin ekleyeceğiniz en üst Kategoriler olur.
	Tüm bu kategorilerin içinde isteğiniz yönünde hiyerarşik &quot;alt-kategoriler&quot;,
	veya &quot;Odalar&quot; oluşturabilirsiniz. Hiyerarşik düzen şu şekildedir: <br />

	<ul>
		<li>
			<b>Spor</b>
			&nbsp;- Bir &quot;kategori&quot;
		</li>
		<ul>
			<li>
				<b>Futbol</b>
				&nbsp;- Bu &quot;Spor&quot; kategorisininin altında bir kategoridir.
			</li>
			<ul>
				<li>
					<b>İstatistikler</b>
					&nbsp;- Bu ise &quot;Futbol&quot; alt bölümüne ait bir alt bölümdür
				</li>
			</ul>
			<li><b>Yüzme</b>
			&nbsp;- Bu &quot;Spor&quot; kategorisinin altında bir kategoridir</li>
		</ul>
	</ul>
	Kategoriler size forumu çeşitli başlıklar altında ayırmanızı sağlar (&quot;Araba,
	Spor&quot;), ve bu kategorilerin içindeki &quot;Odalar&quot; kısmında üyelerin ileti
	gönderebileceği konular bulunur. Galatasaray hakkındaki konuları görmek isteyen üye
	&quot;Spor->Futbol->GALATASARAY&quot; dizinindeki konulara kolaylıkla ulaşabilir. 
	Kategoriler üyelere istedikleri konuyu kolaylıkla bulmalarını sağlar. Sadece &quot;Alışveriş&quot; yerine
	&quot;Bilgisayar&quot; ve &quot;Giyim&quot; bölümlerinde ilginize göre kolaylıkla ulaşabilirsiniz.
	Bu sayede girmek istemediğiniz yerlere girmeye mecbur kalmazsınız; çünkü Bilgisayar Malzemesi ararken
	bu &quot;kategori&quot yerine Giyim Mağazası kısmına girmek zorunda değilsiniz.<br />
	Yukarıda belirtildiği gibi bu odalar geniş kapsamlı kategorilerin altındaki birer konu gibidirler.
	Eğer &quot;Galatasaray&quot; hakkında konuşmak istiyorsanız, &quot;Spor->Futbol&quot; kategorilerinin
	içinde yer alan &quot;Galatasaray&quot; odasına girip düşünceleriniz paylaşabilirsiniz.<br />
	Bu menüdeki yönetici işlemleri her kategori altında yeni bir oda oluşturma, onların 
	sıralamalarını değiştirme (&quot;Galatasaray&quot\'ı; &quot;Sakaryaspor&quot;\'un üstüne yerleştirme)
	veya tamamen bu konuları silme.';

$helptxt['edit_news'] = '	<ul class="normallist">
		<li>
			<strong>Haberler</strong><br />
			Bu bölüm Ana Sayfanızda görüntülenecek metinleri ayarlamanızı sağlar.
			İstediğiniz her maddeyi ekleyebilirsiniz. (örn: &quot;Bu Salı günündeki konferansı kaçırmayın&quot;) Tüm haber maddeleri rastgele olarak gösterilir ve ayrı kutulara yerleştirilmelidir.
		</li>
		<li>
			<strong>Haber Bültenleri</strong><br />
			Bu bölüm forum üyelerinize özel ileti veya e-posta olarak haber bültenleri göndermenizi sağlar. İlk olarak haber bültenlerini almasını istediğiniz grupları ve haber bültenlerini almasını istemediğiniz üye gruplarını seçin. Dilerseniz, haber bültenlerini alacak üyeleri ve email adreslerini de ekleyebilirsiniz. Son olarak, göndermek istediğiniz iletiyi girin ve özel ileti olarak mı yoksa e-posta olarak mı göndermek istediğinizi seçin.
		</li>
		<li>
			<strong>Ayarlar</strong><br />
			Bu bölüm, hangi grupların forum haberlerini düzenleyebileceği veya haber bülteni gönderebileceği de dahil, haberler ve haber bültenleri hakkında birkaç ayar içerir. Ayrıca forumdan haber bülteni almak isteyip istemediğinizi ve alacağınız her haber bülteni gönderisinde kaç karakterlik yazı gösterilmesini istediğinizi yine buradan belirleyebilirsiniz.
		</li>
	</ul>';

$helptxt['view_members'] = '<ul class="normallist">
		<li>
			<strong>Tüm Üyeleri Göster</strong><br />
			Bu özellik forum\'da bulunan tüm üyeleri isimleri profil\'lerine köprülenmiş bir şekilde
			görüntülemenize ve eğer yönetici iseniz bu üyelerin seçeneklerinizi değiştirmenize olanak
                        tanır (website, yaş, vb.). Yönetici haklarına sahip biri, üyeler üzerinde komple kontrole 
                        sahiptir, üye hesabını silmek gibi seçeneklerde Yöneticinin yetkileri arasında bulunur.<br /><br />
		</li>
		<li>
			<strong>Onay Bekleyen Üyeler</strong><br />
			Bu bölüm sadece Yönetici onaylı üyelik sistemi seçili ise görüntülenebilir. Bu seçenek seçili ise bir kişi ancak yönetici 
                        onun üyelik isteğini kabul ettiyse tam bir üye haline gelebilir. Bu bölümde hala yönetici onayı beklemekte olan üyeler,
                        e-posta ve IP adresleri ile birlikte gösterilirler. Burada kişilerin üyelik isteklerini ister kabul edebilir istersenizde
			kabul etmeyebilirsiniz. Üyelerin isimlerinin yanındaki kutulara tıklayabilir ve aşağıdaki çoktan seçmeli menüden yapılacak işlemi
                        seçebilirsiniz. Bir üyenin başvurusunu kabul etmeyecekseniz, bu üyenin bu kararınızdan haberdar edilip edilmeyeceğini belirleyebilirsiniz.<br /><br />
		</li>
		<li>
			<strong>Aktivasyon Bekleyen Üyeler</strong><br />
			Bu bölüm sadece forum seçeneklerinde aktivasyon onaylı üyeliği seçtiyseniz görüntülenebilir olacaktır. Bu bölümde henüz
                        hesaplarını aktifleştirmemiş üyelerin tümünü görebilirsiniz. Bu bölümde isterseniz üyenin hesabını aktifleştirebilir,
			silebilir veya br hatırlatma maili yollayabilirsiniz. Ayrıca isterseniz kararınızdan bu üyeyi haberdar edebilirsiniz.<br /><br />
		</li>
	</ul>';

$helptxt['ban_members'] = '<b>Üyeleri yasaklama</b><br />
	SMF forumlardaki güvenilirliği arttırmak ve belli bir yaptırım uygulayabilmek adına üyeleri &quot;banlama&quot; 
	hakkını vermektedir. Administrator olarak gördüğünüz tüm iletilerde kullanıcıların hangi IP den ileti gönderdiğini
	görebilirsiniz. Ban Listesinde üyeleri IP adresleri ile banlayarak o alandan ileti gönderilmesini engellersiniz. <br />
	Kullanıcıları mail adreslerine görede banlayabilirsiniz.';

$helptxt['featuresettings'] = '<strong>Özellikler ve Seçenekler</strong><br />
Burada tercihlerinize göre değiştirebileceğiniz çeşitli özellikler bulunmaktadır.';

$helptxt['securitysettings'] = '<b>Güvenlik ve Moderasyon</b><br />
	Bu bölüm forum güvenliği ve moderasyonu hakkında bir çok seçenek içerir.';

$helptxt['modsettings'] = '<strong>Mod Seçenekleri</strong><br />
	Bo bölümde forum\'unuzda yüklü olan modlara ait seçenekler bulunmaktadır';

$helptxt['number_format'] = '<strong>Sayı formatı</strong><br />
	Forum içinde kullanılmasını istediğiniz sayı formatını belirleyebilirsiniz. Sayı formatı: <br />
	<div style="margin-left: 2ex;">1,234.00</div><br />
	Virgül \',\' işareti binleri ayırmaya yararken, nokta \'.\' işareti ondalık sayıların ayrılmasında kullanılmıştır.';

$helptxt['time_format'] = '<strong>Zaman biçimi</strong><br />
	Forumun zaman biçiminide istediğiniz gibi ayarlayabilirsiniz.
	Ufak PHP kodlarının anlamları aşağıda belirtilmiştir. (daha fazla detay için <a href="http://www.php.net/manual/function.strftime.php" target="_new">php.net</a>).<br />
	<br />
	Bu karakterler zaman biçimlendirilmesinde kullanılmaktadır: <br />
	<span class="smalltext">
	&nbsp;&nbsp;%a - Belirlenmiş hafta ismi<br />
	&nbsp;&nbsp;%A - Tüm hafta ismi<br />
	&nbsp;&nbsp;%b - Belirlenmiş ay ismi<br />
	&nbsp;&nbsp;%B - Tüm ay ismi<br />
	&nbsp;&nbsp;%d - ay\'ın günleri (01\'den 31\'e kadar) <br />
	&nbsp;&nbsp;%D<strong>*</strong> - ile %m/%d/%y aynıdır<br />
	&nbsp;&nbsp;%e<strong>*</strong> - ay\'ın günü (1 den 31 e kadar) <br />
	&nbsp;&nbsp;%H - 24 saat sistemi (00 ile 23 arası) <br />
	&nbsp;&nbsp;%I - 12 saat sistemi (01 ile 12 arası) <br />
	&nbsp;&nbsp;%m - sayı olarak ay (01 den 12 ye kadar) <br />
	&nbsp;&nbsp;%M - sayı olarak dakika <br />
	&nbsp;&nbsp;%p - &quot;am&quot; veya &quot;pm&quot; olması<br />
	&nbsp;&nbsp;%R<strong>*</strong> - 24 saatlik sistemde düzen <br />
	&nbsp;&nbsp;%S - saniyeler <br />
	&nbsp;&nbsp;%T<strong>*</strong> - Şu an, %H:%M:%S <br />
	&nbsp;&nbsp;%y - 2 rakamlı yıl (00 dan 99 a) <br />
	&nbsp;&nbsp;%Y - 4 rakamlı yıl<br />
	&nbsp;&nbsp;%Z - yerel zaman bölgesi <br />
	&nbsp;&nbsp;%% - \'%\' karakteri <br />
	<br />
	<em>* Windows altyapılı serverlarda çalışmamaktadır.</em></span>';

$helptxt['live_news'] = '<strong>Birebir Duyurular</strong><br />
	Bu kutucuk <a href="http://www.simplemachines.org/" target="_blank" class="new_win">www.simplemachines.org</a> tarafından yapılan duyuruları dakika dakika gösterir.
	Burayı yenilemeler, yeni sürümler ve önemli bilgiler için mümkün olduğunca çok ziyaret etmeniz gerekmektedir.';

$helptxt['registrations'] = '<strong>Kayıt yönetimi</strong><br />
	Bu bölüm forumunuza kayıt yaptırmak isteyenler için olan seçekleri düzenleyebileceğiniz yerdir.
	Burada 4 seçenek bulunmaktadır. Bunlar:<br /><br />
	<ul class="normallist">
		<li>
			<strong>Yeni Üye Kaydetme</strong><br />
			Bu ekrandan yeni üye kayıdı yapılmaktadır. Bu ekran genelde sınırlandırılmış kullanıcı hizmeti veren forumlarda adminler 
			tarafından kullanıcı açılması için yapılmıştır veya test kullanıcıları oluşturmak için kullanılmaktadır. Kullanıcıları aktivasyonla
			üye yapacak olursanız mail adresine gelen linkin tıklanması gerekir, isteyen adminler şifreleri maillere otomatik yollayabilirler.<br /><br />
		</li>
		<li>
			<strong>Üyelik Sözleşmesini Düzenle</strong><br />
			Bu bölümde kayıt sırasında gösterilecek üyelik sözleşmesini düzenleyebilirsiniz. SMF ile birlikte gelen
			varsayılan anlaşmayı komple değiştirebilir veya üzerinde oynamalar yapabilirsiniz.<br /><br />
		</li>
		<li>
			<strong>Ayrılmış İsimleri Düzenle</strong><br />
                        Bu arayüzü kullanarak üyeler tarafından seçilmesine izin olmayacak kullanıcı adlarını belirleyebilirsiniz.<br /><br />
		</li>
		<li>
			<strong>Seçenekler</strong><br />
			Bu bölüm sadece forum\' yönetmeye izniniz varsa görüntülenebilir olacaktır. Bu bölümden forum\'unuzda kullanılacak
			üye kayıt şeklini, ve diğer kayıtla alakalı seçenekleri değiştirebilirsiniz.
		</li>
	</ul>';

$helptxt['modlog'] = '<strong>Moderasyon Kaydı</strong><br />
	Bu bölüm moderatörlerin tüm moderasyon kayıtlarını ve işlemlerini takip etmelerini sağlar. Burada bulunan kayıtlar 24 saat geçmeden silinemezler.';
$helptxt['adminlog'] = '<b>Yönetim Kaydı</b><br />

Bu bölümde yöneticilerin yaptığı bazı etkinlikleri,değişiklikleri takip etmenizi ve kaydını tutmanızı sağlar. Yaptıkları olayları hemen kaldırmadıklarından emin olmak için girdiler olay gerçekleştikten 24 saat sonrasında ancak silinebilir.';
$helptxt['warning_enable'] = '<strong>Üye Uyarı Sistemi</strong><br /> Bu özellik üyelerin uyarı düzeylerinin admin veya moderasyon ekibi tarafından düzenlenmesini sağlar - ve uyarı düzeyleri sayesinde üyenin forum üstünde neler yapabileceği belirler. Bu özelliğin aktif edilmesi sonucunda izinler bölümünde hangi grupların üyeleri uyarabileceğine yönelik izinler çıkar. Uyarı düzeyleri üyenin profilinden ayarlanabilir. Takip eden şu özellikler mevcuttur: <ul class="normallist"> <li> <strong>Üye İzlenmesi için Uyarı Seviyesi</strong><br /> Bu özellik üyenin uyarı düzeyinin belirtilmiş düzeye ulaştığında otomatik olarak &quot;İzle&quot; bölümüne alınmasını sağlar. &quot;İzleniyor&quot; konumundaki üyelerin isimleri direkt olarak moderasyon alanında gözükür. </li> <li> <strong>İleti Moderasyonu için Uyarı Seviyesi</strong><br /> Eğer bir üye bu uyarıyı taşıyorsa forumda göndereceği tüm iletiler öncelikle bir moderatörün kontrolünden geçer. Bu, bulunan lokal bölüm ileti moderasyon özelliklerinin üstüne yazılacaktır. </li> <li> <strong>Üye Susturulması için Uyarı Seviyesi</strong><br /> Eğer bu uyarı düzeyi üye tarafından geçilmiş ise kendilerini yasaklılar arasında bulur. Üye tüm ileti gönderme haklarını kaybeder. </li> <li><strong>Gün için Maksimum Üye Uyarı Puanı</strong><br /> Bu özellik yirmi dör saatlik zaman diliminde moderatörlerin üyelere ekleyip veya çıkarabilecekleri puanları limitler. Bu sistem ayrıca kısa zaman aralığında moderatörlerin yapabileceklerinide kısıtlar. Bu özellik değerin sıfır girilmesi ile iptal edilebilir. Admin izinlerine sahip üyeler bu değişimlerden etkilenmez. </li> </ul>';
$helptxt['error_log'] = '<strong>Hata Kaydı</strong><br />
	Hata kaydı forum içerisinde herhangi bir kullanıcının karşılaştığı önemli hataları saniye saniye kayıt eder. Tarih başlığındaki ok işaretini tıklayarak kayıtları zamana göre sıralayabilirsiniz. Ek olarak kayıtlara belirli filtrelere göre sıralayabilirsiniz, örneğin üyeye göre. Filtre aktif edildiğinde sadece o filtreye uyan kayıtlar gösterilir.';
$helptxt['theme_settings'] = '<strong>Tema Ayarları</strong><br />
	Ayarlar ekranı varsayılan tema ile alakalı olarak görünüyor. Tema dizinleri ve URL adresleri gibi ayarları içermektedir. Çoğu tema kullanıcıların 
	isteklerine göre değiştirebileceği ayarlarla donatılmıştır';
$helptxt['smileys'] = '<b>Gülümseme Merkezi</b><br />
	Bu bölümde forumunuzda kullanmak istediğiniz gülümseme resimlerinin dizinlerini belirleyebilir ve isteğinize göre değiştirebilirsiniz.<br /><br />
	Buradan ileti ikonlarını düzenleyebilirsiniz,eğer ayarlar sayfasından aktifleştirirseniz .';
$helptxt['calendar'] = '<strong>Takvim Yönetimi</strong><br />
	Buradan takvim ayarlarını düzenleyebilirsiniz, tatilleri ve özel günleri ekleyebilir ve kaldırabilirsiniz.';

$helptxt['serversettings'] = '<strong>Sunucu Ayaları</strong><br />
	Burada forum\'unuzun çekirdek ayarlarını yapabilirsiniz. Bu bölüm veritabanı ayarlarının yanı sıra
	önbellek ve mail ayarları gibi daha birçok ayarı içermektedir. Burada düzenleme yaparken dikkatli olun
	çünkü yapacağınız değişiklikler forum\'unuzun erişilememez olmasına neden olabilir.';
$helptxt['manage_files'] = '	<ul class="normallist">
		<li>
			<b>Dosyalara Gözat</b><br />
			Tüm dosyalara göz atabilmenize olanak tanır.
		</li><li>
			<b>Eklenti Ayarları</b><br />
			Eklentilerin bulundukları yerleri belirler.<br /><br />
		</li><li>
			<b>Avatar Ayarları</b><br />
			Avatarların bulundukları yerleri belirler.<br /><br />
		</li><li>
			<b>Dosya Bakımı</b><br />
			Bozukluklar düzeltilebilir ve eklentiler ile ilgili ek değişiklikler yapılabilir.<br /><br />
		</li>
	</ul>';

$helptxt['topicSummaryPosts'] = 'Yanıtlama ekranında yer alacak önceki iletilerin sayısını belirlemenizi sağlar.';
$helptxt['enableAllMessages'] = 'Bunu hepsini göster tuşu görüntülenmeden önce gösterilecek <em>maksimum</em> ileti sayısını ayarlayabilirsiniz.';
$helptxt['enableStickyTopics'] = 'Yapışkan Konu özelliği odalarda bulunan konu listesinin en üstüne konu sabitlemek için kullanılır
		Bu özelliği moderatörlere ve adminlere özel kılabilirsiniz.';
$helptxt['allow_guestAccess'] = 'Bu kutuyu işaretlememek, ziyaretçilerin basit işlemler dışında neredeyse hiçbir şey yapamamalarına neden olacaktır. Bu ziyaretçilerin bölümlere erişememesi ile aynı şey değildir.';
$helptxt['userLanguage'] = 'Bu seçeneği kullanıma açtığınız takdirde her üye forumu desteklenen her dilde görüntüleyebilecektir. Bu
		forumun varsayılan dilini değiştirmez.';
$helptxt['trackStats'] = 'İstatistikler:<br />Bu üyelerin forumdaki en son iletileri ve en popüler konuları görmelerini sağlar.
		En fazla online olan üye,en yeni üye vs.. gibi değişik alanda istatistiklerde bulunmaktadır.<hr />
		Hit:<br />Sayfaların görüntülenme sayısını belirler';
$helptxt['titlesEnable'] = 'Bu özellik sayesinde kullanıcılar kendileri için özel başlık seçebilecekler açabileceklerdir. Bu kullanıcı adının altında gözükecektir.
		<br /><em>Örneğin:</em><br />Ali<br />Karizma';
$helptxt['topbottomEnable'] = 'Bu özellik kullanıcıların sayfa içinde mouse ihtiyaç duymadan aşağı yukarı gitmesini sağlayan butonların gösterimini sağlar.';
$helptxt['onlineEnable'] = 'Kullanıcının online olup olmadığı hakkında bir resim gösterilir.';
$helptxt['todayMod'] = 'Sadece tarihler yerine &quot;Bugün&quot; veya &quot;Dün&quot; yazılarının eklenebilmesini sağlar.<br /><br /><strong>Örneğin:</strong><br /><br />  <dt>  <dt>Kapalıyken</dt>  <dd>Ekim 3, 2009  12:59:18 </dd>  <dt>Sadece Bugün</dt>  <dd>Bugün 12:59:18 </dd>  <dt>Bugün ve Dün</dt>  <dd>Dün 09:36:55</dd>  </dt>  ';
$helptxt['disableCustomPerPage'] = 'Üyelerin ileti listesi ve ileti görünümündeki sayfa başına gösterilecek öğe sayısını özelleştirmelerini engeller.';
$helptxt['enablePreviousNext'] = 'Bir önceki ve sonraki konuya link verir.';
$helptxt['pollMode'] = 'Anketlerin etkin kılınmasını sağlar. Eğer bu seçenek kapatılırsa varolan konulardaki anketler gizlenecektir. 
		Bunu engellemek için &quot;Varolan Anketleri Konu olarak göster&quot; seçeneğini etkin kılabilirsiniz.<br /><br />
		Kimlerin anket açabileceğini veya görebileceğini izinler kısmından ayarlayabilirsiniz.';
$helptxt['enableVBStyleLogin'] = 'Her sayfada ziyaretçiler için giriş panelinin gösterilmesini sağlar.';
$helptxt['enableCompressedOutput'] = 'Düşük bandwithler için sıkıştırma özelliğini sağlar anca yüklenebilmesi için zlib gerekmektedir.';
$helptxt['disableTemplateEval'] = 'Varsayılan olarak, templateler direk dahil edilmek yerine değerlendirilir. Bu, bir template hatası halinde daha yararlı onarma bilgileri gösterilmesini sağlar.<br /><br /> Ancak, bu özelleştirilmiş dahil edilme büyük forumlarda önemli derecede yavaşlıklar yaratabilir. Bu nedenle, gelişmiş üyeler bu özelliği kapatmak isteyebilirler.';
$helptxt['databaseSession_enable'] = 'Bu seçenek oturum bilgilerini depolamak için veritabanının kullanılmasını sağlar - yük dengesi yapılmış sunucular için en iyisidir, ancak tüm zaman aşımı hatalarını giderir ve forumun hızlanmasını sağlar.';
$helptxt['databaseSession_loose'] = 'Bu seçeneğin etkin kılınması forumun kullandığı bandwith i düşürür ve sayfalar arası geri dönüş mümkün olmaz - ve yeni ikonlar yüklenmez. (seçip gösterilmelerini istemediğiniz sürece)';
$helptxt['databaseSession_lifetime'] = 'Bir oturumun zaman aşımına uğraması için gerekli süre.  Bir oturum uzun süredir işlem yapmadıysa &quot;Zaman Aşımı&quot; hatası ile forumdan çıkışı sağlanır. 2400\'den yüksek seçenekler tavsiye edilir.';
$helptxt['enableErrorLogging'] = 'Hertürlü hatanın kayıt edilmesini sağlar. Yanlış şifre vs..';
$helptxt['enableErrorQueryLogging'] = 'Bu seçenek tüm veritabanı hatalarında sorguyuda günlüğe ekler. Hata raporlamanın açık olmasını gerektirir.<br /><br /><strong>Not: Hata iletisine göre hata filtreleme özelliğini etkileyecektir.</strong> ';
$helptxt['allow_disableAnnounce'] = 'Bu kullancıların duyuruları alıp almayacaklarını seçebilmelerini sağlar.';
$helptxt['disallow_sendBody'] = 'Bu seçenek kullanıcıların duyuru alırken metinin içerilip içerilmeyeceğini seçmelerine olanak tanıyan özelliği ortadan kaldırır.<br /><br />Çoğu zaman kullanıcılar yanlışlıkla duyuru mail\'ine cevap yazabilirler ve buda yöneticinin ilgili metini almasına neden olur.';
$helptxt['compactTopicPagesEnable'] = 'Seçili sayfa numarasını gösterir.<br /><em>Örneğin:</em>
		&quot;3&quot; şu şekilde görünecek : 1 ... 4 [5] 6 ... 9
		<br />  &quot;5&quot; şu şekilde görünecek : 1 ... 3 4 [5] 6 7 ... 9';
$helptxt['timeLoadPageEnable'] = 'Sayfaların altında SMF nin o sayfanın gösterme hızını belirten saniye..';
$helptxt['removeNestedQuotes'] = 'Alıntı bağlantısını takip ederek ileti gönderilmeye çalışıldığında ortaya çıkan iç içe yerleşmiş alıntıların iletiden silinmesini sağlar.';
$helptxt['simpleSearch'] = 'Basit arama modülünü gösterir ve gelişmiş arama modülü için link barıdırır.';
$helptxt['max_image_width'] = 'Gönderilecek resimlerin maksimum byte ını belirlemenizi sağlar..';
$helptxt['mail_type'] = 'Bu seçenek PHP\'nin varsayılan mail seçeneğini kullanmanıza, veya SMTP kullanmanıza olanak tanır.  Unutmayın SMTP kullanmak PHP\'nin varsayılan seçeneğini kullanmaktan daha uzun sürebilir, ayrıca SMTP sunucusu her zaman bir kullanıcı adı ve şifre gerektirmeyebilir.<br /><br />Eğer PHP\'nin varsayılan mail sistemini kullanacaksanız kullanıcı adı ve şifre girmenize zaten gerek yoktur.';
$helptxt['attachment_manager_settings'] = 'Ekler üyelerin iletilerine yükleme yolu ile ekleyebildikleri dosyalardır.<br /><br /> <strong>Ek uzantılarını kontrol et</strong>: <br /> Dosya uzantılarını kontrol etmek istermisiniz?<br /> <strong>İzin verilen ek uzantıları</strong>:<br /> Ek dosyalar için izin verilen uzantıları ayarlayabilirsiniz.<br /> <strong>Ek Dizini</strong>:<br /> Eklerin olucağı klasör<br /> (örneğin: /home/sites/yoursite/www/forum/attachments)<br /> <strong>Maksimum ek klasörününün alanı</strong> (KB olarak):<br /> Bir klasörün maksimum olacağı boyut, içindeki eklerle birlikte.<br /> <strong>Her ileti için maksimum ek boyutu</strong> (KB olarak):<br /> Her ileti için gönderilebilecek eklerin maksimum boyutu . Eğer bu her-ek limitinden az ise, bu özellik limit olucaktır.<br /> <strong>Her ek için maksimum boyut</strong> (in KB):<br /> Ekleri ayırıcak maksimum dosya boyutunu seçin.<br /> <strong>Her ileti için maksimum ek sayısı</strong>:<br /> Her ileti başına üyenin gönderebileceği ek sayısını seçin.<br /> <strong>İletilerde ekleri resim olarak göster</strong>:<br /> Eğer yüklenen dosya resim ise, bu iletinin altında gösterilecektir.<br /> <strong>İleti altındaki resimleri boyutla</strong>:<br /> Eğer yukardaki özellik seçilmiş ise, bu, ek için ayrı (küçük) bir thumbnail kaydederek kotayı düşürür.<br /> <strong>Thumbnaillar için maksimum yükseklik ve genişlik</strong>:<br /> Sadece &quot;İleti altındaki resimleri boyutla&quot; özelliği ile kullanılabilir, eklenti boyutlanarak maksimum yükseklik ve genişliğe ayarlanır. Orantılı olarak boyutlanır.';
$helptxt['attachment_image_paranoid'] = 'Yüklenen resimlerde sıkı güvenlik denetlemelerini aktifleştirir. Dikkat! Bu kapsamlı denetlemeler geçerli resimlerde bile hata verebilir. Bu seçeneği sadece resim şifrelemesi seçeneğiyle kullanmanız önerilir. SMF\'in güvenlik denetlemesinde hata veren resimleri küçültmeyi denemesi için: eğer başarılı olursa, gözden geçirilir ve yüklenirler. Aksi takdirde, eğer resim şifrelemesi aktif değilse, denetlemede hata veren tüm eklentiler reddedilecektir.';
$helptxt['attachment_image_reencode'] = 'Yüklenen resmi tekrar şifreler. Resmi tekrar şifrelemek daha iyi güvenlik sağlar. Ancak bu seçenek, tüm hareketli resimleri duraklatır. <br /> Sadece GD modülü yüklü olan sunucularda çalışır.';
$helptxt['avatar_paranoid'] = 'Yüklenen avatarlarda sıkı güvenlik denetlemelerini aktifleştirir. Dikkat! Bu kapsamlı denetlemeler geçerli resimlerde bile hata verebilir. Bu seçeneği sadece avatar şifrelemesi seçeneğiyle kullanmanız önerilir. 
SMF\'in güvenlik denetlemesinde hata veren resimleri küçültmeyi denemesi için: eğer başarılı olursa, gözden geçirilir ve yüklenirler. Aksi takdirde, eğer avatar şifrelemesi aktif değilse, denetlemelerde hata veren tüm avatarlar reddedilecektir.';
$helptxt['avatar_reencode'] = 'Yüklenen avatarı tekrar şifreler. Resmi tekrar şifrelemek daha iyi güvenlik sağlar. Ancak bu seçenek, tüm hareketli resimleri duraklatır. <br /> Sadece GD modülü yüklü olan sunucularda çalışır.';
$helptxt['karmaMode'] = 'Karma bir üyenin popülerliğini göstermeye yarar. &quot;Karma&quot; vermek için gerekli olan ileti sayısını,
		karmalar arasında geçmesi gerek süreyi değiştirebilirsiniz.<br /><br />İzinlerden gerekli ayarlarda yapılabilir.';
$helptxt['cal_enabled'] = 'Takvim forumunuzda üyelerin doğum günlerinin gösterilmesinde veya önemli günlerde uyarılmanız için kullanılır.<br /><br /> <strong>Günleri, \'Etkinlik Gönder\'\\\'e bağlantılı göster</strong>: <br />Bu üyelerin o gün için etkinlik iletmesine izin verir, o güne tıkladıkları zaman <br /> <strong>Ana sayfada gösterilecek en fazla gün</strong>: <br />Eğer bu 7 olarak ayarlanmışsa, gelecek haftanın etkinlikleri gösterilecektir. <br /> <strong>Tatilleri ana sayfada göster</strong>: <br />Ana sayfadaki takvim sütununda bugünün tatillerini göster. <br /> <strong>Yaş günlerini ana sayfada göster</strong>: <br />Ana sayfadaki takvim sütununda bugünün doğumgünlerini göster. <br /> <strong>Etkinlikleri ana sayfada göster</strong>: <br />Ana sayfadaki takvim sütununda bugünün etkinliklerini göster. <br /> <strong>İleti atılacak varsayılan bölüm</strong>: <br />Etkinliklerin iletileceği varsayılan bölüm? <br /> <strong>İletilerden bağımsız etkinliklere izin ver</strong>: <br />Üyelerin forumdaki bir konuya gereksinim duymadan etkinlik iletebilmelerine izin ver. <br /> <strong>Minimum yıl</strong>:<br />Takvimde gösterilecek &quot;ilk&quot; yılı seçiniz	 <br /> <strong>Maximum yıl</strong>:<br />Takvimde gösterilecek &quot;en son&quot; yılı seçiniz <br /> <strong>Etkinliklerin çoklu günlere yayılabilmesine izin ver</strong>: <br />Etkinliklerin çoklu günlere yayılabilmesine izin vermek için işaretleyin. <br /> <strong>Etkinliklerin yayılabileceği maksimum gün sayısı</strong>:<br />Etkinliklerin yayılabileceği maksimum gün sayısını seçin. <br /><br /> Unutmayın bu takvim kullanımı (etkinlik gönderimi, etkinlik görüntüleme, vb.) izinler tarafından izinler ekranında kontrol edilmektedir.';
$helptxt['localCookies'] = 'SMF giriş bilgilerinizin saklanması için cookie yükler bilgisayarınıza.
	Cookie ler genel ayarla (pluslive.info) veya yerel (pluslive.info/path/to/forum) olarak saklanabilir.<br />
	Eğer otomatik olarak çıkış problemi yaşıyorsanız bu seçeneği kontrol ediniz.<hr />
	Genel olarak kullanılan cookieler paylaşılan webserverlar tarafından kullanıldığı zaman daha az güvenli olurlar (bkz. Tripod)<hr />
	Yerel cookieler belirtildiği dosyanın dışında çalışmaz, eğer forumunuz örneğin www.pluslive.info/forum de kuruluysa www.pluslive.info/index.php  gibi sayfalar bilgilerinize ulaşamaz.
	Özellikle SSI.php yi kullanırken, genel cookieler tercih edilir.';
$helptxt['enableBBC'] = 'Bu seçeneği aktif etmek kullanıcıların ileti gönderirken BBC kullanmasına olanak sağlayarak, iletilerini resimlerle ve değişik yazı tipleriyle renklendirmelerine olanak tanıyacaktır.';
$helptxt['time_offset'] = 'Tüm forum adminleri forumlarının aynı GMT ayarları üzerinde kullanımını isterler. Bu seçenek sayesinde + veya - saatler belirterek GMT yi belirleyebilirsiniz.';
$helptxt['default_timezone'] = 'Sunucu zaman dilimi ayarı PHP\'ye sunucunuzun bulunduğu yeri bildirir. Bunu doğru ayarlamanız gerekir. Daha fazla bilgi için <a href="http://www.php.net/manual/en/timezones.php" target="_blank">PHP Sitesi</a>.';
$helptxt['spamWaitTime'] = 'Gönderilen iletiler arasında beklenilmesi gereken süreyi belirtiniz. Bu özellik sürekli gereksiz ileti gönderen kullanıcıları bir nevi olsun durdurabilir.';

$helptxt['enablePostHTML'] = 'Bazı HTML biçimlerinin kullanılabilmesini sağlar:
		<ul style="margin-bottom: 0;">
		<li>&lt;b&gt;, &lt;u&gt;, &lt;i&gt;, &lt;s&gt;, &lt;em&gt;, &lt;ins&gt;, &lt;del&gt;</li>
		<li>&lt;a href=&quot;&quot;&gt;</li>
		<li>&lt;img src=&quot;&quot; alt=&quot;&quot; /&gt;</li>
		<li>&lt;br /&gt;, &lt;hr /&gt;</li>
		<li>&lt;pre&gt;, &lt;blockquote&gt;</li>
	</ul>';

$helptxt['themes'] = 'Varsayılan temayı ve ziyaretçilerin göreceği temayı seçebilirsiniz,
	Temaların sağ taraflarına tıklayarak gerekli değişiklikleride yapabilirsiniz.';
$helptxt['theme_install'] = 'Yeni temaların yüklenebilmesini sağlar. Zaten oluşturulmuş bir dizindende yapabilirsiniz, tema için gerekli dosyaları upload ederek, veya varsayılan temayı kopyalayarak.<br /><br />Unutmayın arşiv veya dizinler <tt>theme_info.xml</tt> açıklama dosyasını içermek zorundadır.';
$helptxt['enableEmbeddedFlash'] = 'Kullanıcıların iletilerinde flash ürünlerini kullanabilmelerini sağlar,
	resimler gibi.  Ancak güvenlik açığı ortaya çıkarabilir.
	KENDI RISK HAKKINIZI KULLANIN!';
// !!! Add more information about how to use them here.
$helptxt['xmlnews_enable'] = 'Kullanıcıların <a href="%s?action=.xml;sa=news">En son haberler</a>\'a link verebilmelerini sağlar.
	En son haberlerin sayısının kısıtlanması tavsiye edilir, çünkü Trillian gibi programlarda rss data
	gösterilmeye çalışıldığı zaman haberlerin tepeleri kesilir.';
$helptxt['hotTopicPosts'] = 'Bir konunun &quot;Beğenilen&quot; veya &quot;Çok Beğenilen&quot; kategorilerine girebilmesi için gereken ileti sayısını
	değiştirebilirsiniz.';
$helptxt['globalCookies'] = 'Subdomainlerin bağımsız cookieler kullanabilmesini sağlar.  Örneğin, eğer...<br />
	Sizin siteniz http://www.pluslive.info/ da ise,<br />
	ve forumunuzda http://forum.pluslive.info/ da kayıtlıysa,<br />
	bu değişikliği kullanarak forumunuzun cookie sini kullanabilmenizi sağlayacak.';
$helptxt['secureCookies'] = 'Bu özelliği aktive etmeniz kullanıcılar tarafından yaratılan çerezleri güvenceye alacaktır. Bu özellik sadece HTTPS kullanan siteler için geçerlidir aksi taktirde çerez yönetimini bozacaktır!';
$helptxt['securityDisable'] = 'Yönetim paneline girmek için sorulan şifre kontrolünü <em>devre dışı bırakır</em>. Tavsiye edilmemektedir!';
$helptxt['securityDisable_why'] = 'Bu sizin şuan kullandığınız şifredir.<br /><br />Bu kontrolün yapılması yapılan tüm işlemlerin <strong>sizin</strong> tarafınızdan yapıldığından emin olmak içindir.';
$helptxt['emailmembers'] = 'Bu iletilerde bazı &quot;değişkenler&quot; kullanabilirsiniz. Bunlar:<br />
	{$board_url} - Forumunuzun URL addresi.<br />
	{$current_time} - Şuanki zaman.<br />
	{$member.email} - Belirtilen kullanıcının maili.<br />
	{$member.link} - Belirtilen kullanıcının linki.<br />
	{$member.id} - Belirtilen kullanıcının ID numarası.<br />
	{$member.name} - Belirtilen kullanıcının adı.  (özelleştirmek için)<br />
	{$latest_member.link} - En son kayır olan kullanıcının linki.<br />
	{$latest_member.id} - En son kayır olan kullanıcının ID numarası.<br />
	{$latest_member.name} - En son kayır olan kullanıcının adı.';
$helptxt['attachmentEncryptFilenames'] = 'Eklenti dosyalarınızın şifrelenmesi aynı isimde 1den fazla dosyanızın olabilmesini
	mümkün kılar. Bu avantajının yanında şiddetli bir zarar sonrasında database inizin yeniden kurulumunda zorluk çıkarabilir.';

$helptxt['failed_login_threshold'] = 'Şifre Hatırlatma ekranına iletilmeden önce yapılabilecek yanlış şifre girişimlerinin sayısı.';
$helptxt['oldTopicDays'] = 'Eğer bu seçenek aktif edilirse, ayarlanmış zaman\'dan sonra bir konuya bir cevap yazılması durumunda kullanıcı bir uyarı iletisi alacaktır. Buradaki veri giriş türü gün\'dür, örneğin konu cevap süresini maksimum bir hafta yapmak için rakamı 7 olarak, seçeneği devre dışı bırakmak için değeri 0 olarak girebilirsiniz.';
$helptxt['edit_wait_time'] = 'Bir iletinin gönderildikten sonra ne kadar zamana kadar tekrar düzenlenebileceğini gösteren zaman(saniye).';
$helptxt['edit_disable_time'] = 'Bir kullanıcının iletisini düzenleyebileceği maksimum süre. Devre dışı bırakmak için 0 olarak ayarlayın. <br /><br /><i>Note: This will not effect any user who has permission to edit other peoples posts.</i>';
$helptxt['posts_require_captcha'] = 'İletiler için resim doğrulamasını aktif eder.';
$helptxt['enableSpellChecking'] = 'İmla kontrolünü aç. İmla kontrolü için pspell kütüphanesi bulundurmanız gerekmektedir.. Sunucunuz ' . (function_exists('pspell_new') == 1 ? 'DESTEKLIYOR' : 'DESTEKLEMIYOR') . ' .';
$helptxt['disable_wysiwyg'] = 'Bu özellik üyelerin WYSIWYG editörünü kapatmalarına olanak tanır.';
$helptxt['lastActive'] = 'Ana sayfada aktif olarak gösterilecek kullanıcılar için süre belirleyiniz. Varsayılan 15 dakikadır.';

$helptxt['customoptions'] = 'Bu bölüm kullanıcıların açılan bir listeden farklı seçenekler seçebilmesini sağlar.
	<ul class="normallist">
		<li><strong>Varsayılan Ayar:</strong>Hangi ayar kutusunun yanında &quot;radio butonu&quot; varsa üye profilini girdiğinde varsayılan seçenek olacaktır.</li>
		<li><strong>Ayarları Kaldırma:</strong>Bir ayarı kaldırmak için sadece metin kutusunu boşaltın - bu seçeneği seçmis üyelerin bu ayarı silinecektir.</li>
		<li><strong>Ayarları Sıralamak:</strong>Metinleri kutuların arasına taşıyarak sıralayabilirsiniz.Ancak - önemli not - ayarları sıralarken metinleri <strong>sakın değiştirmeyin</strong>. Değiştirirseniz tüm üye bilgileri kaybolacaktır.</li>
	</ul>';

$helptxt['autoOptDatabase'] = 'Veritabanını günaşırı optimize eder. Bu kontrolü her gün yapmasını istiyorsanız 1 i seçin. Maksimum online kullanıcı sayısınıda sınırlandırabilirsiniz bu sayede serverınızda aşırı yüklenmeyi önleyebilirsiniz.';
$helptxt['autoFixDatabase'] = 'Otomatik olarak hatalı tabloları düzeltir ve hiçbirşey olmamış gibi devam eder.  Yararlı olabilir çünkü forumunuza zarar vermeden önce kolaylıkla bu riskten kurtulabilirsiniz.  İşlem bittiği zaman size mail gönderilir.';

$helptxt['enableParticipation'] = 'Kullanıcının ileti gönderdiği konuların üzerinde küçük bir ikon belirir.';

$helptxt['db_persist'] = 'Performansı arttırmak için bağlantıyı aktif kılar.  Servera bağlı değilseniz host ile aranızda sorun meydana getirebilir.';
$helptxt['ssi_db_user'] = 'SSI.php ile bağlıyken farklı veritabanı erişim bilgileri kullanılabilmesine olanak tanır.';

$helptxt['queryless_urls'] = 'URL formatlarını bir ölçüde değiştirir bu sayede daha kullanışlı aramalar yapılabilir. Şu şekilde görünürler (index.php/topic,1.0.html).<br /><br />Bu özellik ' . (isset($_SERVER['SERVER_SOFTWARE']) && (strpos($_SERVER['SERVER_SOFTWARE'], 'Apache') !== false || strpos($_SERVER['SERVER_SOFTWARE'], 'lighttpd') !== false) ? 'sunucunuzda çalışak.' : 'çalışmayacak') . '';
$helptxt['countChildPosts'] = 'Bu seçeneği seçtiğiniz takdirde alt bölümlerin ileti sayısı, üst bölümün ileti sayısına dahil edilecektir.';
$helptxt['fixLongWords'] = 'Forum görünümünün bozulmaması için uzun kelimeleri belirli formatta kısaltır. Bu değer 40dan düşük seçilemez, UTF-8 kullanan forumlarda ve PHP4den daha düşük sürümlerde çalışmaz. Bu seçenek sizin sunucunuzda \' . (empty($GLOBALS[\'context\'][\'utf8\']) || version_compare(PHP_VERSION, \'4.4.0\') != -1 ? \'çalışacaktır.\' : \'çalışmayacaktır.\') . \'';
$helptxt['allow_ignore_boards'] = 'Bu özellik kullanıcıların belli bölümlerini yoksayabilmelerine olanak tanır.';

$helptxt['who_enabled'] = 'Forumda kimin ne yaptığını görmenizi sağlar.';

$helptxt['recycle_enable'] = '&quot;Çöp Kutusu&quot; silinen iletiler veya konular bu odaya gönderilir.';

$helptxt['enableReportPM'] = 'Bu özellik kullanıcıların aldıkları kişisel iletileri yöneticilere şikayet edebilmelerine olanak tanımaktadır.';
$helptxt['max_pm_recipients'] = 'Bu özellik kişisel ileti gönderilirken, sönderilecek kişi sayısını sınırlamanızı sağlar. Limiti kaldırmak için 0 yapın.';
$helptxt['pm_posts_verification'] = 'Bu seçenek kişisel ilet gönderilirken resim doğrulamasını zorunlu kılar.';
$helptxt['pm_posts_per_hour'] = 'Bir saat içinde gönderilecek kişiel ileti sayısını sınırlar.';

$helptxt['default_personal_text'] = 'Foruma ilk defa üye olanların varsayılan &quot;kişisel ileti&quot;si.';

$helptxt['modlog_enabled'] = 'Tüm moderatör hareketlerini kaydet.';

$helptxt['guest_hideContacts'] = 'Seçildiği takdirde ziyaretçiler tarafından üyelerin profillerindeki herhangi bir mail adresinin
			görülebilmesi söz konusu olmayacaktır.';

$helptxt['registration_method'] = 'Bu seçenek foruma katılmak isteyen insanların nasıl kayıt olabileceğini belirlemenizi sağlar. Seçebileceğiniz:<br /><br />  <ul class="normallist">  <li>  <strong>Üyelik Devre Dışı</strong><br />  Üyelik işlemini devre dışı bırakır, bu demektir ki forumunuza kimse üye olarak katılamaz.<br />  </li><li>  <strong>Anında Kayıt</strong><br />  Yeni üyeler kayıt olduktan hemen sonra giriş yapabilir ve ileti gönderebilir.<br />  </li><li>  <strong>Eposta Aktivasyonu</strong><br />  Bu seçenek aktifleştirildiğinde her hangi bir üyenin foruma kayıt olduktan sonra tam üye konumuna geçmesi için eposta adreslerine gönderilen aktivasyon linkine tıklamaları gerekmektedir.<br />  </li><li>  <strong>Admin Onaylı</strong><br />  Bu seçenek forumunuza kayıt olan tüm yeni üyelerin, üye olabilmeleri için yönetici tarafından onaylanmasını gerektirir. </li>  </ul>  ';
$helptxt['register_openid'] = '<strong>OpenID Doğrulaması</strong><br /> OpenID\'nin anlamı tek bir kullanıcı adını bir çok sitede kullanarak , çevrim içi deneyiminizi basite indirger. OpenID\'yi kullanabilmeniz için öncelikle OpenID hesabı yaratmanız gerekmektedir - Sağlayıcıların listesi <a href="http://openid.net/" target="_blank">OpenID Resmi Sitesinde</a> yer almaktadır<br /><br /> OpenID hesabınızı aldıktan sonra yapıcağınız işlem özel tanıtım URLnizi OpenID girdi kutusuna girip iletmektir. Daha sonrasında o siteye geri gitmek için sağlayıcınızın sitesine giderek kendinizi onaylamanız gerekmektedir.<br /><br /> İlk ziyaretinizde site sizi tanıyabilmesi için bir çok detay talep edicektir,
akabinde o siteye sadece OpenID\'nizi kullanarak giriş yapabilir ve profilinizi düzenliyebilirsiniz.<br /><br /> Daha fazla bilgi için <a href="http://openid.net/" target="_blank">OpenID Resmi Sitesini</a> ziyaret edin';

$helptxt['send_validation_onChange'] = 'Profillerindeki email adreslerini değiştiren üyelerin yeni emaillerine gelen link ile üyeliklerini tekrar aktif hale getirmeleri gerekir.';
$helptxt['send_welcomeEmail'] = 'Yeni gelen üyelere HOŞGELDİNİZ maili gönderilir.';
$helptxt['password_strength'] = 'Bu seçenek üyelerin şifreleri için gerekli olan şifre karmaşıklığını ayarlamanızı sağlar. Şifre karmaşıklaştıkça, kırmak da o kadar zorlaşır.
	Olası ayarlar:
	<ul class="normallist">
		<li><strong>Düşük:</strong> Şifre en az 4 karakterden oluşmalı.</li>
		<li><strong>Orta:</strong> Şifre en az 8 karakterden oluşmalı ve kullanıcı adını veya e-mail adresini içermemeli.</li>
		<li><strong>High:</strong> Ortadaki tüm özellikler geçerlidir ama ek olarak şifre büyük ve küçük harflerden oluşmalı ve en az bir rakam içermelidir.</li>
	</ul>';

$helptxt['coppaAge'] = 'Bu kutuda belirtilen değer, siteye üye olabilecek kişilerinin minimum yaşlarını belirtecektir.
	Yaşı belirlenmiş değerin altında olanlar ayarlarda seçilen seçeneğe bağlı olarak ya ebeveyinlerinden izin almak zorunda olacak yada forum\'a üye olamayacaklardır.
	Burada değer 0 olarak girildiği takdirde tüm yaş sınırlamaları kaldırılacaktır.';
$helptxt['coppaType'] = 'Eğer yaş sınırlaması aktif ise, akabinde belirlenen yaşın altındaki kişinin foruma üyeliği konusunda olucakları içerir. Bu alanda iki seçenek yer alır: <ul class="normallist"> <li> <strong>Kaydı reddet:</strong><br /> Yeni üyelik yapıcak olan bu kişilerin üyelikleri direkt olarak reddedilir.<br /> </li><li> <strong>Koruyucu veya Aile onayı</strong><br /> Kayıt olmak isteyen belirlenmiş yaşın altındaki üyeler bekletilir, ve ebeveynleri tarafından foruma üye olabileceğine dair bir onay formu alınır. Ayrıca kullanılan iletişim bilgileri aracılığı ile ulaşacaklardır,yani onay formu adminlere mail veya fax yolu ile gönderilebilir. </li> </ul>';
$helptxt['coppaPost'] = 'İletişim kutuları ebeveyinlerin çocuklarının siteye erişimini onaylaması için forum yöneticilerine onay göndermeleri için gereklidir.';

$helptxt['allow_hideOnline'] = 'Üyeler diğer üyelerden online olduklarını gizleyebilirler (admin ve moderatörler dışında). Bu özellik kapatılması durumunda sadece admin ve moderatörler tarafından kullanılabilecektir.';
$helptxt['make_email_viewable'] = 'Bu özellik size kullanıcıların email adreslerinin ziyaretçilere ve diğer üyelere açık hale gelmesini sağlar. Aktifleştirerek üyelerinizin spam kurbanı olmalarına sebep olabilirsiniz.Not bu düzenleme email adreslerini diğer üyelerden saklayan üyelerin ayarlarını geçersiz kılmaz. Bu özelliği aktive etmenizi <storng>önermiyoruz</strong>';
$helptxt['meta_keywords'] = 'Bu anahtar kelimeler arama motorlarına (vb) gösterilmek üzere her sayfaya gönderilecektir, bu sitenizin anahtar içeriğidir. Bu kelimeler virgül ile ayrılmalıdır, ve HTML kullanılmamalıdır.';

$helptxt['latest_support'] = 'Bu panelde server ayarlarında en çok karşılaşılan problemler ve sorular yer alır. Merak etmeyin bu bilgiler kayıt edilmez.<br /><br />Eğer &quot;Destek bilgileri alınıyor...&quot;, diye kaldıysa büyük ihtimal bilgisayarınız <a href="http://www.simplemachines.org/" target="_blank">www.simplemachines.org</a> adresine bağlanamamıştır.';
$helptxt['latest_packages'] = 'En son hizmete sunulan modüller ve paketleri görebilirsiniz.<br /><br />Eğer bu kısım gözükmüyorsa bilgisayarınız <a href="http://www.simplemachines.org/" target="_blank">www.simplemachines.org</a> adresine bağlanamamış demektir.';
$helptxt['latest_themes'] = 'Bu alan bazı en son çıkan temalar ile en çok kullanılan temalardan örnekleri sunar. <a href="http://www.simplemachines.org/" target="_blank">www.simplemachines.org</a>.  Eğer bilgisayarınız <a href="http://www.simplemachines.org/">www.simplemachines.org</a> adresine bağlanamadıysa bu alanda bilgi göremeyebilirsiniz.';

$helptxt['secret_why_blank'] = 'Sizin güvenliğiniz için verilen cevap ve şifre otomatik olarak şifrelenir ve hiç bir koşulda kimseye verilmez.';
$helptxt['moderator_why_missing'] = 'Moderatörler oda bazında yapıldığı için ,  <a href="javascript:window.open(\'%s?action=manageboards\'); self.close();">Oda yönetimi biriminden moderatörleri belirleyebilirsiniz.</a>.';

$helptxt['permissions'] = 'İzinler size belirli konular hakkında yasaklama,izin verme gibi haklar sağlar.<br /><br />İzinleri kutulara tik atarak kolaylık belirleyebilir ve \'Düzenle. tuşu ile bitirebilirsiniz.';
$helptxt['permissions_board'] = 'Eğer bir oda  \'Genel,\' olarak belirtildiyse bu oda herkes tarafından görülebilir.  \'Yerel\' özel izinler karşılığında görülebilen ve girilebilen odaları belirtir.';
$helptxt['permissions_quickgroups'] = 'Bunlar size &quot;varsayılan&quot; izinlerin yapılandırılmasındada yardımcı olur - standart \'özel bir şey yok\' anlamına gelir, kısıtlı ise \'ziyaretçi gibi\' manasına gelir, moderatör \'moderatör ne yaparsa\'anlamına gelir, ve son olarak \'bakım\' admin seviyesine en yakın gruptur.';
$helptxt['permissions_deny'] = 'İzinleri yasaklamak belli üyelere forum\'da belli eylemleri yasaklamak istediğiniz zaman size çok yardımcı olabilirler.<br /><br />Belli üyelere yasaklama getirmek için onlar için bir üye grubu yaratın ve izinlerini yasaklayıp üyeleri bu gruba dahil edin. Unutmayın eğer bir üye bir izni yasaklanmış bir gruba dahilse, diğer gruplardan hangi haklar gelirse gelsin yasaklanmış hakkını kullanamayacaktır.';
$helptxt['permissions_postgroups'] = 'İletiye bağlı gruplar için izin ayarlanmasını aktif etmek, belli ileti sayısındaki kullanıcılara belli izinleri vermenizi sağlayacaktır. Bu gruplardan alınan yeni izinler ana üye grubunun izinlerine <em>eklenecektir</em>.';
$helptxt['membergroup_guests'] = 'Ziyaretçiler, forum\'a giriş yapmamış tüm kullanıcıları içeren gruptur.';
$helptxt['membergroup_regular_members'] = 'Normal üyeler forum\'a giriş yapmış ama herhangi bir üye grubuna dahil edilmemiş üyelerdir.';
$helptxt['membergroup_administrator'] = 'Administrator\'lar forum\'da tüm bölümleri görebilir istedikleri her şeyi yapabilmektedirler. Admin\'ler için izin sınırlaması yapılamamaktadır.';
$helptxt['membergroup_moderator'] = 'Moderatör grubu özel bir üye grubudur, <em>sadece moderatörü oldukları bölümlerde</em> belli başlı izinlere sahiplerdir. Bu bölümler dışında mod\'ların diğer üyelerden bir farkı yoktur.';
$helptxt['membergroups'] = 'SMF de üyelerinizin ayrıldığı iki çeşit grup vardır. Bunlar:
	<ul>
		<li><b>Düzenli Gruplar:</b> Düzenli gruplar &quot;Üyelik Ayarları&quot;ndan girilerek yapılabilir.Bu sayede üyeleri istediğini sayıda düzenli gruba üye yapabilirsiniz.</li>
		<li><b>İleti Yapılı Gruplar:</b> Düzenli grupların aksine üyeler atanamaz. Grubun minimum ileti sayısına ulaşan üye o gruba girmiş olur.</li>
	</ul>';

$helptxt['calendar_how_edit'] = 'Olayları isimlerinin sağ tarafında bulunan kırmızı (*) işarete tıklayarak düzenleyebilirsiniz.';

$helptxt['maintenance_backup'] = 'Forumunuzdaki tüm bilgileri büyük bir dosya halinde kopyalamanızı sağlar.<br /><br />Haftalık olarak güvenliğiniz açısından yapılmasını tavsiye ederiz.';
$helptxt['maintenance_rot'] = 'Bu seçenek <strong>Geri Dönülemeyecek Şekilde</strong> eski konularınızı silmenizi sağlar. Herhangi birşey yapmadan önce forumunuzun yedeğini almanız önerilir. <br /><br />Bu seçeneği dikkatli kullanmalısınız.';
$helptxt['maintenance_members'] = 'Bu forumunuzdan üye hesaplarını <strong>tamamen</strong> silebilmenizi sağlar. <strong>İstenmeyen sonuçlarla</strong> karşılaşmamak için yedek almanız önerilir.<br /><br /> Bu seçeneği dikkatli kullanmalısınız.';

$helptxt['avatar_server_stored'] = 'Kullanıcıların avatarlarını sizin serverınızdan almasını sağlar<br />Eğer SMF nin avatarlar klasörü içine dizinler oluşturursanız avatar &quot;kategorisi&quot; yapabilirsiniz.';
$helptxt['avatar_external'] = 'Başka adreslerden link verilmesini ve avatarlarda kullanılabilmeyi sağlar.';
$helptxt['avatar_download_external'] = 'Bu özellik seçilirse, karşı bir sunucudan avatar bu sunucuya transfer edilir ve öntanımlı boyuta küçültülür.';
$helptxt['avatar_upload'] = 'Bu seçenek üyelerinizin avatlarını sizin sunucunuza yüklemelerine olanak tanır. Bu sayede avatarları yeniden boyutlandırabilirsiniz.<br /><br />Bu seçeneğin kötü bir etkisi ise sunucunuzdaki yer kullanımını artıracak olmasıdır.';
$helptxt['avatar_download_png'] = 'PNG dosyaları daha büyük boyutlu ancak daha kaliteli resim formatıdır. Bu seçenek seçilmediği takdirde JPEG- daha küçük ancak daha az kaliteli- resimler kullanılacaktır.';

$helptxt['disableHostnameLookup'] = 'Host isimlerinin bakılmasını kaldıracaktır.';

$helptxt['search_weight_frequency'] = 'Önemli unsurlar arama sonuçlarının yararlılığı için kullanılır. Önemli unsurları forumunuzun yapısına göre değiştiriniz. Örneğin bir haber forumu yapılacak aramada \'en son uyuştuğu iletiyi göster\' özelliğinin değerinin daha yüksek olması yararlı olacaktır. Tüm rakamlar birbirleri ile belli bir şekilde bağlantılı ve pozitif olmak zorundadırlar.<br /><br />Bu unsur bulunan arama sonuçlarının sayısını toplam ileti sayısına böler.';
$helptxt['search_weight_age'] = 'Önemli unsurlar arama sonuçlarının yararlılığı için kullanılır. Önemli unsurları forumunuzun yapısına göre değiştiriniz. Örneğin bir haber forumu yapılacak aramada \'en son uyuştuğu iletiyi göster\' özelliğinin değerinin daha yüksek olması yararlı olacaktır. Tüm rakamlar birbirleri ile belli bir şekilde bağlantılı ve pozitif olmak zorundadırlar.<br /><br />Bu unsur bulunan ileti süresine dayalıdır. Daha fazla sonuç, daha fazla kazancı gösterir.';
$helptxt['search_weight_length'] = 'Önemli unsurlar arama sonuçlarının yararlılığı için kullanılır. Önemli unsurları forumunuzun yapısına göre değiştiriniz. Örneğin bir haber forumu yapılacak aramada \'en son uyuştuğu iletiyi göster\' özelliğinin değerinin daha yüksek olması yararlı olacaktır. Tüm rakamlar birbirleri ile belli bir şekilde bağlantılı ve pozitif olmak zorundadırlar.<br /><br />Bu unsur konu büyüklüğüne dayalıdır. Konularda bulunan fazla iletiler, daha fazla kazancı gösterir.';
$helptxt['search_weight_subject'] = 'Önemli unsurlar arama sonuçlarının yararlılığı için kullanılır. Önemli unsurları forumunuzun yapısına göre değiştiriniz. Örneğin bir haber forumu yapılacak aramada \'en son uyuştuğu iletiyi göster\' özelliğinin değerinin daha yüksek olması yararlı olacaktır. Tüm rakamlar birbirleri ile belli bir şekilde bağlantılı ve pozitif olmak zorundadırlar.<br /><br />Bu unsur konuların başlığında bulunabilmeye dayalıdır.';
$helptxt['search_weight_first_message'] = 'Önemli unsurlar arama sonuçlarının yararlılığı için kullanılır. Önemli unsurları forumunuzun yapısına göre değiştiriniz. Örneğin bir haber forumu yapılacak aramada \'en son uyuştuğu iletiyi göster\' özelliğinin değerinin daha yüksek olması yararlı olacaktır. Tüm rakamlar birbirleri ile belli bir şekilde bağlantılı ve pozitif olmak zorundadırlar.<br /><br />Bu unsur konuların ilk iletilerinde bulunabilmeye dayalıdır.';
$helptxt['search_weight_sticky'] = 'Arama ağırlıklarının önemini belirler, mesela bir haber sitesi için son gönderilme tarihi aramalarda daha fazla ağırlık taşımalıdır.';
$helptxt['search'] = 'Arama ile ilgili tüm seçenekleri burada ayarlayabilirsiniz.';
$helptxt['search_why_use_index'] = 'Arama indeksi aramaları hızlandırıp sunucu üzerindeki yükü azaltır, 50000 den fazla üyeli bir forumunuz varsa indekslemeyi aktifleştirmeyi düşünebilirsiniz.';

$helptxt['see_admin_ip'] = 'IP adresleri moderatörler ve adminler tarafından görülebilir. Bu özellik yetkili kişilerin kullanıcıları daha rahat takip ederek, forumun yapısını korumalarına yardımcı olur. Unutmayın IP adresleri her zaman kişileri göstermez çünkü çoğu kullanıcının IP si belirli aralıklarla değişir.<br /><br />Kullanıcıların kendi IP lerini görebilmeleride sağlanmıştır.';
$helptxt['see_member_ip'] = 'IP adresiniz sadece siz ve moderatörler tarafından görülebilir, diğer kullanıcılar sizin IP\'nizi göremezler. Unutmayın bu bilgi kimliğini ortaya çıkarmaz, ve çoğu IP dinamiktir yani devamlı değişirler.<br /><br />Ne siz diğer kullanıcıların IP adreslerini görebilirsiniz, ne de onlar sizin IP adresinizi görebilirler.';
$helptxt['whytwoip'] = 'SMF SMFin kullandığı yöntemler birden fazla IP adresi kaydına yol açabilir.';

$helptxt['ban_cannot_post'] = '\'İleti Gönderme Engellemesi\', forum\'u yasaklanmış kullanıcı için sadece-okunulabilir bir hale getirir. Kullanıcı yeni konular açamaz, konulara cevap atamaz, özel iletiler gönderemez veya anketlerde oy kullanamaz. Ama engellenmiş kullanıcı kendi özel iletilerini ve diğer tüm konuları okuma hakkına hala sahiptir.<br /><br />Bu şekilde yasaklanmış kullanıcılara engellenmiş hareketleri yapmak istediklerinde bir uyarı gösterilir.';

$helptxt['posts_and_topics'] = '
	<ul>
		<li>
			<b>İleti Ayarları</b><br />
			İletilerin gönderilme ve gösterimleriyle ilgili ayarları düzenler. Aynı zamanda yazım denetimini de burada aktif edebilirsiniz.
		</li><li>
			<b>Bulletin Board Code</b><br />
			İletilerdeki görünümü değiştirebilen BBC kodları ile ilgili ayarları düzenleyin. Aynı zamanda buradan izin verilen/verilmeyen kodları seçebilirsiniz.
		</li><li>
			<b>Sansürlü Kelimeler</b>
			Forumdaki üslubu kontrol altında tutabilmek için, belli kelimeleri sansürleyebilirsiniz. Bu özellik forumdaki yasak kelimeleri zararsız keilemelere çeverimenizi sağlar.
		</li><li>
			<b>Konu Ayarları</b>
			Konularla ilgili ayarları düzenler. Örneğin, bir sayfada gösterilecek konu sayısı, sabit konulara izin veriliyor mu, verilmiyor mu, bir konunun beğenilen konu sayılması için kaç ileti gerektiği, vb.
		</li>
	</ul>';
$helptxt['spider_group'] = 'Bu özelliği kullanarak arama motorlarına normal ziyaretçilerden daha kısıtlı veya daha fazla içerik gösterebilirsiniz';
$helptxt['show_spider_online'] = 'Bu seçenek arama örümceklerinin anasayfada ve &quot;Kimler Çevrimiçi&quot; sayfalarında görüntülenip görüntülenmeyeceğini belirtir. Seçenekler : <ul class="normallist"> <li> <strong>Gösterme</strong><br /> Örümceler hiçbir yerde ziyaretçi olarak gösterilmeyecek. </li><li> <strong>Örümcek sayısını göster</strong><br /> Forum anasayfasında oan kaç örümcek olduğu görüntülenecek. </li><li> <strong>Örümcek detayını göster</strong><br />Tüm örümcek isimleri görüntülenecek, böylece üyeleriniz hangi örümceklerde kaç tane olduğunu görebilecekler - forum anasayfasın ve kimler çevrim içi bölümümünün her ikisindede geçerli</li><li> <strong>Örümcek detayını göster - sadece yöneticilere</strong><br /> Sadece yöneticiler örümcek isimlerini görebilecek, diğer üyeler örümcekleri ziyaretçi olarak görecekler. </li> </ul> ';

$helptxt['birthday_email'] = 'Doğum günü için kullanılacak e-posta içeriğini seçiniz. Önizleme olarak E-posta içeriği ve başlığı gösterilecektir.<br /><strong>Not:</strong> Bu ayarı aktif ettiğinizde doğum günü kutlamalarının otomatik olarak göndermeyi aktif etmiş olmazsınız. Otomatik doğum günü E-postaları göndermek için <a href="%1$s?action=admin;area=scheduledtasks;%3$s=%2$s" target="_blank" class="new_win">Zamanlanmış Görevler</a> sayfasından Doğum Günü E-Postalarını aktifleştirmelisiniz.';
$helptxt['pm_bcc'] = 'Kişisel iletilerde birden fazla kişiyle (görünmez) ileti gönderilebilmsine olanak tanır.';

$helptxt['move_topics_maintenance'] = 'Bu tüm iletilerin bölümden bölüme taşınmasını sağlar.';
$helptxt['maintain_reattribute_posts'] = 'Bu özelliği kullanarak iletileri üyelere yeniden atayabilirsiniz, özellikle bir üyenin hesabını silindikten sonra eski iletilerinin hesabı ile tekrar ilişkilendirilmesi gerektiğinde faydalı olacaktır.';
$helptxt['chmod_flags'] = 'CHMOD değerlerini buradan atayabilirsiniz fakat Windows sistemlerde bazı seçeneklerin etkisi olmayacaktır.';

$helptxt['postmod'] = 'Bu bölümde moderasyon  ekibi (yeterli izni olanlar) onay gerektiren konuları ve iletileri görünmeden önce onaylayabilirler.';

$helptxt['field_show_enclosed'] = 'Girilen değeri belirli metin veya html içerisinde gösterir. Bu seçenek sayesinde daha fazla ileti paylaşımı servisi ekleyebilir, resim gösterimi veya flash yerleştirimi yapabilirsiniz.
Örneğin:<br /><br />&lt;a href="http://siteniz.com/{INPUT}"&gt;&lt;img src="{DEFAULT_IMAGES_URL}/icon.gif" alt="{INPUT}" /&gt;&lt;/a&gt;<br /><br />Not, şu varyasyonları kullanabilirsiniz : <br /> <ul class="normallist"> <li>{INPUT} - Kullanıcı tarafından girilen değer</li> <li>{SCRIPTURL} - Forumunuzun adresi.</li> <li>{IMAGES_URL} - Kullanılan temanın resim klasörünün URLsi.</li> <li>{DEFAULT_IMAGES_URL} - Varsayılan temanın resim klasörünün URLsi.</li> </ul>';

$helptxt['custom_mask'] = 'Giriş maskesi forumunuzun güvenliği için önemlidir. Bir üyeden gelen girdiyi onaylama, verinin sizin istemediğiniz gibi kullanılmadiğını kesinleştirir. Bazı basit düzenli ifadeler:<br /><br /> <span class="smalltext"> &nbsp;&nbsp;"[A-Za-z]+" - Alfabenin tüm küçük ve büyük harfleriyle eşleşir.<br /> &nbsp;&nbsp;"[0-9]+" - Tüm sayılar ile eşleşir.<br /> &nbsp;&nbsp;"[A-Za-z0-9]{7}" -  Alfabenin tüm küçük ve büyük harfleriyle ve sayılar ile 7 defa eşleşir.<br /> &nbsp;&nbsp;"[^0-9]?" - Bir sayının eşleşmiş olmasını engeller.<br /> &nbsp;&nbsp;"^([A-Fa-f0-9]{3}|[A-Fa-f0-9]{6})$" - Sadece 3 veya 6 hexcode karakterine izin verir.<br /> </span><br /><br /> Ayrıca, özel karakterler ?+*^$ ve {xx} karakterleri tanımlanabilir. <span class="smalltext"> &nbsp;&nbsp;? - önceki ifadeden 0 veya 1 eşleşme<br /> &nbsp;&nbsp;+ - önceki ifadeden 1 veya daha fazla<br /> &nbsp;&nbsp;* - önceki ifadeden 0 yada daha fazla<br /> &nbsp;&nbsp;{xx} - önceki ifadeyle aynı<br /> &nbsp;&nbsp;{xx,} - önceki ifadeyle aynı veya daha fazla<br /> &nbsp;&nbsp;{,xx} - önceki ifadeyle aynı veya daha az<br /> &nbsp;&nbsp;{xx,yy} - önceki ifadeden iki sayı arasında bir eşleşme<br /> &nbsp;&nbsp;$ - ifade baslangıcı.<br /> &nbsp;&nbsp;^ - ifade bitişi.<br /> &nbsp;&nbsp;\\ - yanındaki karakteri kurtarır.<br /> </span><br /><br /> İnternette daha fazla bilgi bulabilirsiniz.';
$helptxt['image_proxy_enabled'] = 'Whether to enable the image proxy';
$helptxt['image_proxy_secret'] = 'Keep this a secret, protects your forum from hotlinking images. Change it in order to render current hotlinked images useless';
$helptxt['image_proxy_maxsize'] = 'Maximum image size that the image proxy will cache: bigger images will be not be cached. Cached images are stored in your SMF cache folder, so make sure you have enough free space.';

?>