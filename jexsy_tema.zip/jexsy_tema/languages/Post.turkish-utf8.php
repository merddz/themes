<?php
// Version: 2.0; Post

global $context;

$txt['post_reply'] = 'Yanıt gönder';
$txt['enter_verification_details'] = 'Doğrulama detaylarını tamamlayın';
$txt['message_icon'] = 'İleti Simgesi';
$txt['subject_not_filled'] = 'İletinin konu başlığı boş bırakılamaz.';
$txt['message_body_not_filled'] = 'İleti bölümü boş bırakılamaz.';
// Use numeric entities in the below string.
$txt['regards_team'] = "Saygılar,\nThe " . $context['forum_name'] . ' Ekibi.';
$txt['add_bbc'] = 'BBC Kodu Ekle';
$txt['bold'] = 'Kalın';
$txt['italic'] = 'İtalik';
$txt['underline'] = 'Altını Çiz';
$txt['center'] = 'Ortala';
$txt['hyperlink'] = 'Bağlantı Ekle';
$txt['insert_email'] = 'E-Posta Ekle';
$txt['bbc_code'] = 'Kod Ekle';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['bbc_quote'] = 'Alıntı Yap';
$txt['list'] = 'Liste Ekle';
$txt['list_unordered'] = 'Düzensiz Liste Ekle';
$txt['list_ordered'] = 'Düzenli Liste Ekle';

$txt['change_color'] = 'Renk Değiştir';
$txt['black'] = 'Siyah';
$txt['red'] = 'Kırmızı';
$txt['yellow'] = 'Sarı';
$txt['pink'] = 'Pembe';
$txt['green'] = 'Yeşil';
$txt['orange'] = 'Turuncu';
$txt['purple'] = 'Mor';
$txt['blue'] = 'Mavi';
$txt['beige'] = 'Bej';
$txt['brown'] = 'Kahverengi';
$txt['teal'] = 'Mat Yeşil';
$txt['navy'] = 'Deniz Mavisi';
$txt['maroon'] = 'Kestane Rengi';
$txt['lime_green'] = 'Açık Yeşil';
$txt['white'] = 'Beyaz';
$txt['disable_smileys'] = 'Gülümsemeler Devre Dışı';
$txt['dont_use_smileys'] = 'Gülümseme kullanma.';
// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.
$txt['posted_on'] = 'Tarih';
$txt['standard'] = 'Standart';
$txt['thumbs_up'] = 'Yukarı Parmak';
$txt['thumbs_down'] = 'Aşağı Parmak';
$txt['excamation_point'] = 'Ünlem İşareti';
$txt['question_mark'] = 'Soru İşareti';
$txt['lamp'] = 'Lamba';
$txt['add_smileys'] = 'Gülümseme Ekle';
$txt['flash'] = 'Flash Ekle';
$txt['ftp'] = 'FTP Adresi Ekle';
$txt['image'] = 'Resim Ekle';
$txt['table'] = 'Tablo Ekle';
$txt['table_td'] = 'Tablo Sütunu Ekle';
$txt['topic_notify_no'] = 'Haber verilecek konu yok.';
$txt['marquee'] = 'Kayan Yazı';
$txt['teletype'] = 'Daktilo Tarzı Yazı';
$txt['strike'] = 'Üstü Çizili';
$txt['glow'] = 'Işıldayan Yazı';
$txt['shadow'] = 'Gölgeli Yazı';
$txt['preformatted'] = 'Formatlı Yazı';
$txt['left_align'] = 'Sola Dayalı';
$txt['right_align'] = 'Sağa Dayalı';
$txt['superscript'] = 'Üst Yazı';
$txt['subscript'] = 'Alt Yazı';
$txt['table_tr'] = 'Tabloya Satır Ekle';
$txt['post_too_long'] = 'İletiniz çok uzun. Lütfen geri dönüp iletinizi kısaltın, akabinde tekrar deneyin.';
$txt['horizontal_rule'] = 'Yatay Çizgi';
$txt['font_size'] = 'Metin Boyutu';
$txt['font_face'] = 'Metin Tipi';
$txt['toggle_view'] = 'Görünümü Değiştir';
$txt['unformat_text'] = 'Formatlamayı Sıfırla';

$txt['rich_edit_wont_work'] = 'Tarayıcınız zengin metin düzenlemesini desteklememektedir.';
$txt['rich_edit_function_disabled'] = 'Tarayıcınız bu fonksiyonu desteklememektedir.';

// Use numeric entities in the below five strings.
$txt['notifyUnsubscribe'] = 'Buraya tıklayarak bu konudaki aboneliğinizi kaldırabilirsiniz';

$txt['lock_after_post'] = 'Gönderdikten sonra kilitle';
$txt['notify_replies'] = 'Yanıt gönderildiğinde haberdar et.';
$txt['lock_topic'] = 'Bu konuyu kilitle.';
$txt['shortcuts'] = 'kısayollar: göndermek için alt+s veya önizleme yapmak için alt+p\\\'ye basın';
$txt['shortcuts_firefox'] = 'kısayollar: göndermek için shift+alt+s veya önizleme yapmak için shift+alt+p\\\'ye basın';
$txt['option'] = 'Seçenek';
$txt['reset_votes'] = 'Oyları Sıfırla';
$txt['reset_votes_check'] = 'Eğer verilen tüm oyları 0lamak isterseniz bunu işaretleyin.';
$txt['votes'] = 'oylar';
$txt['attach'] = 'Dosya Ekle';
$txt['clean_attach'] = 'Eki Temizle';
$txt['attached'] = 'Eklentide Olan';
$txt['allowed_types'] = 'İzin verilen dosya türleri';
$txt['cant_upload_type'] = 'Dosyanız yüklenemiyor. İzin verilen dosya türleri şunlar;';
$txt['uncheck_unwatchd_attach'] = 'Ekte olan dosyayı çıkartmak istiyorsanız  işareti kaldırın';
$txt['restricted_filename'] = 'Dosya adı geçersiz. Lütfen farklı bir dosya adı deneyin.';
$txt['topic_locked_no_reply'] = 'Uyarı: Konu şu anda kilitlidir!<br />Sadece yöneticiler yanıt verebilir.';
$txt['awaiting_approval'] = 'Onay bekliyor';
$txt['attachment_requires_approval'] = 'Bir moderatör tarafından onaylanana dek ekli dosyalar görüntülenmeyecektir.';
$txt['error_temp_attachments'] = 'Daha önceden eklediğiniz fakat iletmediğiniz ekler bulundu. Bu ekler şimdi bu iletiye eklenecektir. Eğer onları bu iletiye eklemek istemezseniz, <a href="#postAttachment">buraya</a> tıklayarak kaldırabilirsiniz.';
// Use numeric entities in the below string.
$txt['js_post_will_require_approval'] = 'Hatırlatma: Bu ileti bir moderatör tarafından onaylanana dek görüntülenmeyecektir.';

$txt['enter_comment'] = 'Yorum ekle';
// Use numeric entities in the below two strings.
$txt['reported_post'] = 'İletiyi rapor';
$txt['reported_to_mod_by'] = 'eden';
$txt['rtm10'] = 'Gönder';
// Use numeric entities in the below four strings.
$txt['report_following_post'] = '"1$s" başlıklı iletiyi gönderen';
$txt['reported_by'] = 'adlı üye';
$txt['board_moderate'] = 'tarafından rapor edilmiştir.';
$txt['report_comment'] = 'Raporu gönderenin yorumu';

$txt['attach_restrict_attachmentPostLimit'] = 'Toplam Boyut ( En Fazla ) %1$dKB';
$txt['attach_restrict_attachmentSizeLimit'] = 'Kişisel Boyut ( En Fazla ) %1$dKB ';
$txt['attach_restrict_attachmentNumPerPostLimit'] = '%1$d post başına';
$txt['attach_restrictions'] = 'Kısıtlama:';

$txt['post_additionalopt'] = 'Ekler ve diğer seçenekler';
$txt['sticky_after'] = 'Konuyu sabitle.';
$txt['move_after2'] = 'Konuyu taşı.';
$txt['back_to_topic'] = 'Konuya geri dön.';
$txt['approve_this_post'] = 'Bu İletiyi Onayla';

$txt['retrieving_quote'] = 'Alıntı yapılıyor...';

$txt['post_visual_verification_label'] = 'Doğrulama';
$txt['post_visual_verification_desc'] = 'Bu iletiyi gönderebilmek için lütfen yukarıdaki resimdeki kodu giriniz.';

$txt['poll_options'] = 'Anket Seçenekleri';
$txt['poll_run'] = 'Anketi';
$txt['poll_run_limit'] = '(Limitsiz olması için boş bırakın)';
$txt['poll_results_visibility'] = 'Sonuç görünümü';
$txt['poll_results_anyone'] = 'Anket sonuçlarını herhangi biri görebilir.';
$txt['poll_results_voted'] = 'Sonuçları sadece üye oy verince göster.';
$txt['poll_results_after'] = 'Sonuçları sadece anket bittikten sonra göster.';
$txt['poll_max_votes'] = 'Her üyenin verebileceği en çok oy.';
$txt['poll_do_change_vote'] = 'Kullanıcılara oylarını değiştirebilmelerine izin ver.';
$txt['poll_too_many_votes'] = 'Çok fazla seçenek seçtiniz. Bu anket için en fazla %1$s seçenekte bulunabilirsiniz.';
$txt['poll_add_option'] = 'Seçenek Ekle';
$txt['poll_guest_vote'] = 'Ziyaretçilerin oy vermesine izin ver.';

$txt['spellcheck_done'] = 'Yazım denetimi tamamlandı.';
$txt['spellcheck_change_to'] = 'Bununla değiştir:';
$txt['spellcheck_suggest'] = 'Öneriler:';
$txt['spellcheck_change'] = 'Değiştir';
$txt['spellcheck_change_all'] = 'Tümünü Değiştir';
$txt['spellcheck_ignore'] = 'Yoksay';
$txt['spellcheck_ignore_all'] = 'Tümünü yoksay';

$txt['more_attachments'] = 'daha çok eklenti';
// Don't use entities in the below string.
$txt['more_attachments_error'] = 'Üzgünüm, izin verilenden fazla eklenti gönderemezsiniz.';

$txt['more_smileys'] = 'daha';
$txt['more_smileys_title'] = 'Daha Fazla Gülümseme';
$txt['more_smileys_pick'] = 'Bir gülümseme seç';
$txt['more_smileys_close_window'] = 'Pencereyi kapat';

$txt['error_new_reply'] = 'Uyarı: Siz iletinizi yazarken yeni bir ileti daha gönderildi. Gönderilen iletiyi incelemeniz önerilir.';
$txt['error_new_replies'] = 'Uyarı: Siz iletinizi yazarken %1$d yeni ileti daha gönderildi. Gönderilen iletiyi incelemeniz önerilir.';
$txt['error_new_reply_reading'] = 'Uyarı: Siz iletinizi okurken yeni bir ileti daha gönderildi. Gönderilen iletiyi incelemeniz önerilir.';
$txt['error_new_replies_reading'] = 'Uyarı: Siz iletinizi okurken %1$d yeni ileti daha gönderildi.  Gönderilen iletiyi incelemeniz önerilir.';

$txt['announce_this_topic'] = 'Üyelere bu konu hakkında duyuru gönder:';
$txt['announce_title'] = 'Duyuru Gönderimi';
$txt['announce_desc'] = 'Bu form, konuyu seçili üye gruplarına göndermenizi sağlar.';
$txt['announce_sending'] = 'Konu Duyurusu Gönderiliyor';
$txt['announce_done'] = 'tamam';
$txt['announce_continue'] = 'Devam Et';
$txt['announce_topic'] = 'Duyuruyu gönder.';
$txt['announce_regular_members'] = 'Normal Üyeler';

$txt['digest_subject_daily'] = 'Günlük Derleme';
$txt['digest_subject_weekly'] = 'Haftalık Derleme';
$txt['digest_intro_daily'] = 'Aşağıda %1$s de/da bulunan, haberdar olmayı seçtiğiniz tüm bölümler ve konularda bugünki değişiklikler bulunmaktadır. Haberdar olmak istemiyorsanız lütfen aşağıdaki bağlantıya tıklayınız.';
$txt['digest_intro_weekly'] = 'Aşağıda %1$s de/da bulunan, haberdar olmayı seçtiğiniz tüm bölümler ve konularda bu haftaki değişiklikler bulunmaktadır. Haberdar olmak istemiyorsanız lütfen aşağıdaki bağlantıya tıklayınız.';
$txt['digest_new_topics'] = 'Şu konular başlatılmıştır';
$txt['digest_new_topics_line'] = '"%1$s" - "%2$s" ';
$txt['digest_new_replies'] = 'Şu konulara yanıtlar gönderilmiştir';
$txt['digest_new_replies_one'] = '1 yanıt - "%1$s"';
$txt['digest_new_replies_many'] = '%1$d yanıt - "%2$s"';
$txt['digest_mod_actions'] = 'Şu moderasyonlar gerçekleştirilmiştir';
$txt['digest_mod_act_sticky'] = '"%1$s" sabitlenmiştir';
$txt['digest_mod_act_lock'] = '"%1$s" kilitlenmiştir';
$txt['digest_mod_act_unlock'] = '"%1$s" kilidi açılmıştır';
$txt['digest_mod_act_remove'] = '"%1$s" kaldırılmıştır';
$txt['digest_mod_act_move'] = '"%1$s" taşınmıştır';
$txt['digest_mod_act_merge'] = '"%1$s" birleştirilmiştir';
$txt['digest_mod_act_split'] = '"%1$s" bölünmüştür';

?>