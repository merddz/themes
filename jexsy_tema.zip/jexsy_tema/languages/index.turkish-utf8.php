<?php

// Version: 2.0.12; Index



global $forum_copyright, $forum_version, $webmaster_email, $scripturl, $context, $boardurl;



// Locale (strftime, pspell_new) and spelling. (pspell_new, can be left as '' normally.)

// For more information see:

//   - http://www.php.net/function.pspell-new

//   - http://www.php.net/function.setlocale

// Again, SPELLING SHOULD BE '' 99% OF THE TIME!!  Please read this!

$txt['lang_locale'] = 'tr_TR.utf8';

$txt['lang_dictionary'] = 'tr';

$txt['lang_spelling'] = '';



// Ensure you remember to use uppercase for character set strings.

$txt['lang_character_set'] = 'UTF-8';

// Character set and right to left?

$txt['lang_rtl'] = false;

// Capitalize day and month names?

$txt['lang_capitalize_dates'] = true;



$txt['days'] = array('Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi');

$txt['days_short'] = array('Paz', 'Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt');

// Months must start with 1 => 'January'. (or translated, of course.)

$txt['months'] = array(1 => 'Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık');

$txt['months_titles'] = array(1 => 'Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık');

$txt['months_short'] = array(1 => 'Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Ekm', 'Ksm', 'Ara');



$txt['time_am'] = 'öö';

$txt['time_pm'] = 'ös';



$txt['newmessages0'] = 'tane yeni';

$txt['newmessages1'] = 'tanesi yeni';

$txt['newmessages3'] = 'Yeni';

$txt['newmessages4'] = ',';



$txt['admin'] = 'Yönetim';

$txt['moderate'] = 'Moderasyon';



$txt['save'] = 'Kaydet';



$txt['modify'] = 'Değiştir';

$txt['forum_index'] = '%1$s - Anasayfa';

$txt['members'] = 'Üye';

$txt['board_name'] = 'Forum Adı';

$txt['posts'] = 'İleti';



$txt['member_postcount'] = 'İleti';

$txt['no_subject'] = '(Konu Yok)';

$txt['view_profile'] = 'Profili Görüntüle';

$txt['guest_title'] = 'Ziyaretçi';

$txt['author'] = 'Gönderen';

$txt['on'] = '';

$txt['remove'] = 'Sil';

$txt['start_new_topic'] = 'Yeni Konu Başlat';



$txt['login'] = 'Giriş Yap';

// Use numeric entities in the below string.

$txt['username'] = 'Kullanıcı Adı';

$txt['password'] = 'Şifre';



$txt['username_no_exist'] = 'Kullanıcı adı bulunamadı.';

$txt['no_user_with_email'] = 'Bu e-posta ile bağlantılı bir kullanıcı adı bulunmamaktadır.';



$txt['board_moderator'] = 'Bölüm Moderatörü';

$txt['remove_topic'] = 'Konuyu Kaldır';

$txt['topics'] = 'Konu';

$txt['modify_msg'] = 'İletiyi düzenle';

$txt['name'] = 'Kullanıcı Adı';

$txt['email'] = 'E-Posta';

$txt['subject'] = 'Konu';

$txt['message'] = 'İleti';

$txt['redirects'] = 'Yönlendirme';

$txt['quick_modify'] = 'Satır İçi Değişiklik Yap';



$txt['choose_pass'] = 'Şifrenizi seçin';

$txt['verify_pass'] = 'Şifrenizi doğrulayın';

$txt['position'] = 'Pozisyon';



$txt['profile_of'] = 'Profilini görüntüle:';

$txt['total'] = 'Toplam';

$txt['posts_made'] = 'İleti';

$txt['website'] = 'Web';

$txt['register'] = 'Kayıt Ol';

$txt['warning_status'] = 'Uyarı Durumu';

$txt['user_warn_watch'] = 'Üye moderatör izleme listesindedir';

$txt['user_warn_moderate'] = 'Üyenin iletileri onaydan geçmektedir';

$txt['user_warn_mute'] = 'Üye ileti gönderememektedir';

$txt['warn_watch'] = 'İzlemede';

$txt['warn_moderate'] = 'Moderasyonda';

$txt['warn_mute'] = 'Susturulmuş';



$txt['message_index'] = 'İleti Listesi';

$txt['news'] = 'Haberler';

$txt['home'] = 'Ana Sayfa';



$txt['lock_unlock'] = 'Konuyu Kilitle | Kilidi Kaldır';

$txt['post'] = 'Gönder';

$txt['error_occured'] = 'Bir Hata Meydana Geldi!';

$txt['at'] = '-';

$txt['logout'] = 'Çıkış';

$txt['started_by'] = 'Başlatan';

$txt['replies'] = 'Yanıt';

$txt['last_post'] = 'Son İleti';

$txt['admin_login'] = 'Yönetici Girişi';

// Use numeric entities in the below string.

$txt['topic'] = 'Konu';

$txt['help'] = 'Yardım';

$txt['notify'] = 'Haberdar Et';

$txt['unnotify'] = 'Haberdar Etme';

$txt['notify_request'] = 'Bu konuya yanıt verildiğinde, e-posta ile haberdar edilmek ister misiniz?';

// Use numeric entities in the below string.

$txt['regards_team'] = 'Teşekkürler,' . "\n" . '' . $context['forum_name'] . ' Ekibi.';

$txt['notify_replies'] = 'Yanıtlardan haberdar et';

$txt['move_topic'] = 'Konuyu taşı';

$txt['move_to'] = 'Şuraya taşı';

$txt['pages'] = 'Sayfa';

$txt['users_active'] = 'Son %1$d dakika içinde aktif olan üyeler';

$txt['personal_messages'] = 'Kişisel İletiler';

$txt['reply_quote'] = 'Alıntı yaparak yanıtla';

$txt['reply'] = 'Yanıtla';

$txt['reply_noun'] = 'Yanıtla';

$txt['approve'] = 'Onayla';

$txt['approve_all'] = 'hepsini onayla';

$txt['awaiting_approval'] = 'Onay Bekliyor';

$txt['attach_awaiting_approve'] = 'Onay bekleyen ekler';

$txt['post_awaiting_approval'] = 'Not: Bu ileti bir moderatörden onay beklemektedir.';

$txt['there_are_unapproved_topics'] = 'Bu bölüme ait onaylanmamış %1$s konu ve %2$s ileti bulunmaktadır. Tümünü görüntülemek için <a href="%3$s">buraya</a> tıklayınız.';



$txt['msg_alert_none'] = 'İleti Yok...';

$txt['msg_alert_you_have'] = 'size ait';

$txt['msg_alert_messages'] = 'ileti var';

$txt['remove_message'] = 'Bu iletiyi sil';



$txt['online_users'] = 'Çevrimiçi Üyeler';

$txt['personal_message'] = 'Kişisel İleti';

$txt['jump_to'] = 'Gitmek istediğiniz yer';

$txt['go'] = 'git';

$txt['are_sure_remove_topic'] = 'Bu konuyu kaldırmak istediğinden emin misin?';

$txt['yes'] = 'Evet';

$txt['no'] = 'Hayır';



$txt['search_end_results'] = 'Arama Sonu';

$txt['search_on'] = '-';



$txt['search'] = 'Ara';

$txt['all'] = 'Hepsi';



$txt['back'] = 'Geri';

$txt['password_reminder'] = 'Şifre Hatırlatması';

$txt['topic_started'] = 'Konuyu başlatan';

$txt['title'] = 'Başlık';

$txt['post_by'] = 'Gönderen';

$txt['memberlist_searchable'] = 'Aranabilir kayıtlı kullanıcı listesi.';

$txt['welcome_member'] = 'En son üyemiz';

$txt['admin_center'] = 'Yönetim Merkezi';

$txt['last_edit'] = 'Son Düzenleme';

$txt['notify_deactivate'] = 'Bu konu\'ya gönderilen yanıtlardan haberdar olmamak istediğinize emin misiniz?';



$txt['recent_posts'] = 'Son İletiler';



$txt['location'] = 'Yer';

$txt['gender'] = 'Cinsiyet';

$txt['date_registered'] = 'Kayıt Tarihi';



$txt['recent_view'] = 'En son gönderilen iletileri göster';

$txt['recent_updated'] = 'en son güncellenmiş konudur';



$txt['male'] = 'Bay';

$txt['female'] = 'Bayan';



$txt['error_invalid_characters_username'] = 'Kullanıcı adında geçersiz karakter kullanılmıştır.';



$txt['welcome_guest'] = 'Hoşgeldiniz <b>%1$s</b>. Lütfen <a href="' . $scripturl . '?action=login">giriş yapın</a> veya <a href="' . $scripturl . '?action=register">kayıt olun</a>.';

$txt['login_or_register'] = 'Lütfen <a href="' . $scripturl . '?action=login">giriş yapın</a> veya <a href="' . $scripturl . '?action=register">üye olun</a>.';

$txt['welcome_guest_activate'] = '

<a href="' . $scripturl . '?action=activate">Aktivasyon eposta</a>nız mı yok?';

$txt['hello_member'] = 'Merhaba,';

// Use numeric entities in the below string.

$txt['hello_guest'] = 'Hoş Geldiniz,';

$txt['welmsg_hey'] = 'Merhaba,';

$txt['welmsg_welcome'] = 'Hoş Geldiniz,';

$txt['welmsg_please'] = 'Lütfen';

$txt['select_destination'] = 'Gitmek istediğiniz yer';



// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.

$txt['posted_by'] = 'Gönderen';



$txt['icon_smiley'] = 'Mutlu';

$txt['icon_angry'] = 'Kızgın';

$txt['icon_cheesy'] = 'Şımarık';

$txt['icon_laugh'] = 'Kahkahalı';

$txt['icon_sad'] = 'Üzgün';

$txt['icon_wink'] = 'Göz kırpıyor';

$txt['icon_grin'] = 'Sırıtıyor';

$txt['icon_shocked'] = 'Şaşırmış';

$txt['icon_cool'] = 'Karizmatik';

$txt['icon_huh'] = 'Kafası karışmış';

$txt['icon_rolleyes'] = 'Masum';

$txt['icon_tongue'] = 'Dil çıkartıyor';

$txt['icon_embarrassed'] = 'Utanmış';

$txt['icon_lips'] = 'Suskun';

$txt['icon_undecided'] = 'Kararsız';

$txt['icon_kiss'] = 'Öpücük';

$txt['icon_cry'] = 'Ağlayıyor';



$txt['moderator'] = 'Moderatör';

$txt['moderators'] = 'Moderatörler';



$txt['mark_board_read'] = 'Bu Bölümdeki Konuları Okunmuş Say';

$txt['views'] = 'Gösterim';

$txt['new'] = 'Yeni';



$txt['view_all_members'] = 'Tüm Üyeler';

$txt['view'] = 'Göster';



$txt['viewing_members'] = 'Üyeleri Görüntülüyor %1$s - %2$s';

$txt['of_total_members'] = 'Toplam üye: %1$s';



$txt['forgot_your_password'] = 'Şifreni mi unuttun ?';



$txt['date'] = 'Tarih';

// Use numeric entities in the below string.

$txt['from'] = 'Kimden';

$txt['check_new_messages'] = 'Yeni mesajları kontrol et';

$txt['to'] = 'Kime';



$txt['board_topics'] = 'Konu';

$txt['members_title'] = 'Üyeler';

$txt['members_list'] = 'Üye Listesi';

$txt['new_posts'] = 'Yeni ileti var';

$txt['old_posts'] = 'Yeni ileti yok';

$txt['redirect_board'] = 'Yönlendirmeler';



$txt['sendtopic_send'] = 'Gönder';

$txt['report_sent'] = 'Raporunuz başarılı bir şekilde gönderilmiştir.';



$txt['time_offset'] = 'Zaman dengesi';

$txt['or'] = 'veya';



$txt['no_matches'] = 'Üzgünüz, istediğiniz kriterlerle eşleşen bir sonuç bulunamadı.';



$txt['notification'] = 'Duyurular';



$txt['your_ban'] = 'Üzgünüz %1$s, bu forum\'dan yasaklandınız!.';

$txt['your_ban_expires'] = 'Yasağınızın bitiş süresi %1$s.';

$txt['your_ban_expires_never'] = 'Yasağınızın bitiş süresi bulunmamaktadır.';

$txt['ban_continue_browse'] = 'Bu forumu ziyaretçi olarak görüntülemeye devam edebilirsiniz.';



$txt['mark_as_read'] = 'TÜMÜNÜ Okunmuş Say';



$txt['hot_topics'] = 'Beğenilen konu (%1$d veya fazlası ileti içermektedir)';

$txt['very_hot_topics'] = 'Çok beğenilen konu (%1$d veya fazlası ileti içermektedir)';

$txt['locked_topic'] = 'Kilitli Konu';

$txt['normal_topic'] = 'Normal Konu';

$txt['participation_caption'] = 'İletinizin bulunduğu konu';



$txt['go_caps'] = 'Git';



$txt['print'] = 'Yazdır';

$txt['profile'] = 'Profil';

$txt['topic_summary'] = 'Konu Özeti';

$txt['not_applicable'] = 'Yok';

$txt['message_lowercase'] = 'ileti';

$txt['name_in_use'] = 'Bu kullanıcı adı zaten başka bir üye tarafından kullanılmaktadır.';



$txt['total_members'] = 'Toplam Üye';

$txt['total_posts'] = 'Toplam İleti';

$txt['total_topics'] = 'Toplam Konu';



$txt['mins_logged_in'] = 'Bağlı kalmak istediğiniz süre';



$txt['preview'] = 'Önizleme';

$txt['always_logged_in'] = 'Sürekli bağlı kal';



$txt['logged'] = 'Kayıtlı';

// Use numeric entities in the below string.

$txt['ip'] = 'IP';



$txt['www'] = 'WWW';



$txt['by'] = 'Gönderen:';



$txt['hours'] = 'saat';

$txt['days_word'] = 'gün';



$txt['newest_member'] = ', en yeni üyemiz.';



$txt['search_for'] = 'Kelime(ler)';



$txt['aim'] = 'AIM';

// In this string, please use +'s for spaces.

$txt['aim_default_message'] = 'Selam.+Orada+mısın?';

$txt['aim_title'] = 'AOL Instant Messenger';

$txt['icq'] = 'ICQ';

$txt['icq_title'] = 'ICQ Messenger';

$txt['msn'] = 'MSN';

$txt['msn_title'] = 'MSN Messenger';

$txt['yim'] = 'YIM';

$txt['yim_title'] = 'Yahoo Instant Messenger ';



$txt['maintain_mode_on'] = 'Unutmayın, site şuan bakım modundadır.';



$txt['read'] = 'Okunma sayısı';

$txt['times'] = 'defa';



$txt['forum_stats'] = 'Forum İstatistikleri';

$txt['latest_member'] = 'Son Üye';

$txt['total_cats'] = 'Toplam Kategori';

$txt['latest_post'] = 'Son İleti';



$txt['you_have'] = 'Size gönderilmiş';

$txt['click'] = 'Görüntülemek için';

$txt['here'] = 'buraya';

$txt['to_view'] = 'görmek için.';



$txt['total_boards'] = 'Toplam Bölüm';



$txt['print_page'] = 'Sayfayı Yazdır';



$txt['valid_email'] = 'Geçerli bir e-posta adresi olmalıdır.';



$txt['geek'] = 'Ben bir ineğim!!';

$txt['info_center_title'] = '%1$s - Bilgi Merkezi';



$txt['send_topic'] = 'Arkadaşına gönder';



$txt['sendtopic_title'] = '&quot;%1$s&quot; başlıklı konuyu bir arkadaşa gönder.';

$txt['sendtopic_sender_name'] = 'Adınız';

$txt['sendtopic_sender_email'] = 'E-Posta adresiniz';

$txt['sendtopic_receiver_name'] = 'Alıcının adı';

$txt['sendtopic_receiver_email'] = 'Alıcının e-posta adresi';

$txt['sendtopic_comment'] = 'Yorum ekle';



$txt['allow_user_email'] = 'Üyelerin bana e-posta göndermesine izin ver';



$txt['check_all'] = 'Tümünü seç';



// Use numeric entities in the below string.

$txt['database_error'] = 'Veritabanı Hatası';

$txt['try_again'] = 'Lütfen kısa bir süre sonra tekrar deneyiniz. Eğer hata iletisini tekrar alırsanız, yönetici ile iletişime geçiniz.';

$txt['file'] = 'Dosya';

$txt['line'] = 'Satır';

// Use numeric entities in the below string.

$txt['tried_to_repair'] = 'Veritabanınızda bir hata saptandı ve otomatik olarak onarım işlemi denendi. Eğer sorun devam eder veya bu iletiyi tekrar alırsanız, lütfen sunucu yöneticinizle temas kurun.';

$txt['database_error_versions'] = '<b>Not:</b> Veritabanızın güncellemesi gerekiyor. Sizin dosyalarınızın şuanki sürümü %1$s, <em>ama</em> veritabanın sürümü %2$s. Upgrade.php\'yi çalıştırmanız tavsiye ediliyor.';

$txt['template_parse_error'] = 'Tema Ayrıştırma Hatası!';

$txt['template_parse_error_message'] = 'Tema içerisinde hatalı bir kod bulundu. Bu problem geçicidir, Lütfen daha sonra tekrar deneyin. Eğer sürekli bu iletiyle karşılaşıyorsanız yönetici ile iletişime geçiniz.<br /><br />Hatayı düzeltildikten sonra sayfayı <a href="javascript:location.reload();">yenileyiniz</a>.';

$txt['template_parse_error_details'] = '<tt><b>%1$s</b></tt> adındaki terma veya dil dosyasının yüklenmesinde sorun var. Lütfen söz dizimini denetleyin ve tekrar deneyin, tek tire işaretleri önünde tek yatık çizgiler olmalı (<tt>\'</tt>) ve tek yatık çizgi kullanacaksanız iki tane yazmalısınız (<tt>\\</tt>). PHP kodlarında hatayı daha belirgin görmek istiyorsanız, <a href="' . $boardurl . '%1$s">doğrudan dosyaya erişmeyi</a> deneyin.<br /><br />Tekrar denemek istiyorsanız <a href="javascript:location.reload();">sayfayı yenileyin</a> veya <a href="' . $scripturl . '?theme=1">varsayılan temayı kullanın</a>.';



$txt['today'] = '<b>Bugün</b>, ';

$txt['yesterday'] = '<b>Dün</b>, ';

$txt['new_poll'] = 'Yeni Anket';

$txt['poll_question'] = 'Soru';

$txt['poll_vote'] = 'Oyla';

$txt['poll_total_voters'] = 'Toplam Oy Verenler';

$txt['shortcuts'] = 'Kısayollar: ileti gönderme; ALT+S - ileti önizleme; ALT+P';

$txt['shortcuts_firefox'] = 'Kısayollar: ileti gönderme; shift+alt+s - ileti önizleme; shift+alt+p';

$txt['poll_results'] = 'Sonuçları görüntüle';

$txt['poll_lock'] = 'Oylamayı Kilitle';

$txt['poll_unlock'] = 'Oylamanın Kilidini Kaldır';

$txt['poll_edit'] = 'Anketi Düzenle';

$txt['poll'] = 'Anket';

$txt['one_day'] = '1 Gün';

$txt['one_week'] = '1 Hafta';

$txt['one_month'] = '1 Ay';

$txt['forever'] = 'Her zaman';

$txt['quick_login_dec'] = 'Kullanıcı adınızı, şifrenizi ve aktif kalma süresini giriniz';

$txt['one_hour'] = '1 Saat';

$txt['moved'] = 'TAŞINDI';

$txt['moved_why'] = 'Lütfen konuyu taşıma sebebinize dair<br />bir açıklama yazın.';

$txt['board'] = 'Forumun';

$txt['in'] = '';

$txt['sticky_topic'] = 'Sabit Konu';



$txt['delete'] = 'Sil';



$txt['your_pms'] = 'Kişisel İletileriniz';



$txt['kilobyte'] = 'KB ';



$txt['more_stats'] = '[Daha fazla istatistik]';



// Use numeric entities in the below three strings.

$txt['code'] = 'Kod';

$txt['code_select'] = '[Seç]';

$txt['quote_from'] = 'Alıntı yapılan';

$txt['quote'] = 'Alıntı';



$txt['merge_to_topic_id'] = 'Hedef konunun ID\'si';

$txt['split'] = 'Konuyu Böl';

$txt['merge'] = 'Konuları Birleştir';

$txt['subject_new_topic'] = 'Konunun Yeni Başlığı';

$txt['split_this_post'] = 'Sadece bu iletiyi böl.';

$txt['split_after_and_this_post'] = 'Bu ileti ve sonrasından itibaren böl.';

$txt['select_split_posts'] = 'Bölünecek iletileri seçin.';

$txt['new_topic'] = 'Yeni Konu';

$txt['split_successful'] = 'Konu başarılı bir şekilde bölünmüştür.';

$txt['origin_topic'] = 'Orjinal Konu';

$txt['please_select_split'] = 'Lütfen hangi iletileri bölmek istediğinizi seçin';

$txt['merge_successful'] = 'Konuların birleştirilmesi tamamlandı.';

$txt['new_merged_topic'] = 'Yeni birleştirilen konu';

$txt['topic_to_merge'] = 'Birleştirilecek Konu';

$txt['target_board'] = 'Hedef Bölüm';

$txt['target_topic'] = 'Hedef Konu';

$txt['merge_confirm'] = 'Birleştirmek istediğinize emin misiniz';

$txt['with'] = 'ile';

$txt['merge_desc'] = 'Bu fonksiyon iki konunun birleştirilmesini sağlar. Tarihe göre sınıflandırılma yapılacaktır.';



$txt['set_sticky'] = 'Konuyu sabitle';

$txt['set_nonsticky'] = 'Sabitlemeyi kaldır';

$txt['set_lock'] = 'Kilitle';

$txt['set_unlock'] = 'Kilidi aç';



$txt['search_advanced'] = 'Gelişmiş Arama';



$txt['security_risk'] = 'BÜYÜK GÜVENLİK TEHLİKESİ:';

$txt['not_removed'] = 'Silmeniz gereken dosya: ';

$txt['not_removed_extra'] = '%1$s dosyası, %2$s dosyasının bir yedeğidir ve SMF tarafından oluşturulmamıştır. Bu dosya forumunuzda izinsiz yetki kazanabilmek için kullanılabilir. Dosyayı hemen silmelisiniz.';



$txt['cache_writable_head'] = 'Performance Uyarısı';

$txt['cache_writable'] = 'Önbellek dizini yazılabilir değildir - bu durum forum\'unuzun performansını kötü yönde etkileyeektir.';



$txt['page_created'] = 'Bu sayfa ';

$txt['seconds_with'] = ' saniyede ';

$txt['queries'] = ' sorgu ile oluşturulmuştur';



$txt['report_to_mod_func'] = 'Bu fonksiyonu, yanlış veya kötü amaçlı iletileri yönetici ve moderatörlere bildirmek için kullanınız.<br /><i>Unutmayın, bu fonksiyonu kullandığınız takdirde, e-posta adresinizi gizlemeyi seçtiyseniz bile, e-posta adresiniz moderatörlere de gösterilecektir.</i>';



$txt['online'] = 'Çevrimiçi';

$txt['offline'] = 'Çevrimdışı';

$txt['pm_online'] = 'Kişisel İleti Gönder (Çevrimiçi)';

$txt['pm_offline'] = 'Kişisel İleti Gönder (Çevrimdışı)';

$txt['status'] = 'Durumu';



$txt['go_up'] = 'Yukarı git';

$txt['go_down'] = 'Aşağı git';



$forum_copyright = '<a style="color: #23272a;" href="' . $scripturl . '?action=credits" title="Simple Machines Forum" target="_blank" class="new_win">%1$s</a> |

 <a style="color: #23272a;" href="http://www.simplemachines.org/about/smf/license.php" title="License" target="_blank" class="new_win">SMF &copy; 2017</a>, <a style="color: #23272a;" href="http://www.simplemachines.org" title="Simple Machines" target="_blank" class="new_win">Simple Machines</a>';



$txt['birthdays'] = 'Doğum Günleri:';

$txt['events'] = 'Etkinlikler:';

$txt['birthdays_upcoming'] = 'Yaklaşan Doğum Günleri:';

$txt['events_upcoming'] = 'Yaklaşan Etkinlikler:';

// Prompt for holidays in the calendar, leave blank to just display the holiday's name.

$txt['calendar_prompt'] = '';

$txt['calendar_month'] = 'Ay:';

$txt['calendar_year'] = 'Yıl:';

$txt['calendar_day'] = 'Gün:';

$txt['calendar_event_title'] = 'Etkinlik Başlığı';

$txt['calendar_event_options'] = 'Olay Ayarları';

$txt['calendar_post_in'] = 'Ekleneceği Bölüm:';

$txt['calendar_edit'] = 'Etkinliği Düzenle';

$txt['event_delete_confirm'] = 'Bu Etkinlik Silinsin mi?';

$txt['event_delete'] = 'Etkinliği Sil';

$txt['calendar_post_event'] = 'Etkinlik Gönder';

$txt['calendar'] = 'Takvim';

$txt['calendar_link'] = 'Takvime ekle';

$txt['calendar_upcoming'] = 'Takvim';

$txt['calendar_today'] = 'Takvimde Bugün';

$txt['calendar_week'] = 'Hafta';

$txt['calendar_week_title'] = '%2$d senesinin %1$d. haftası ';

$txt['calendar_numb_days'] = 'Süreceği Gün:';

$txt['calendar_how_edit'] = 'Etkinlikleri nasıl düzenleyeceksin?';

$txt['calendar_link_event'] = 'İletiye Hatırlatma Bağla:';

$txt['calendar_confirm_delete'] = 'Bu hatırlatmayı silmek istediğinizden eminmisiniz ?';

$txt['calendar_linked_events'] = 'Bağlanılan Hatırlatmalar';

$txt['calendar_click_all'] = 'Tümünü görüntüle: %1$s';



$txt['moveTopic1'] = 'Taşıma bilgilendirmesi ile ilgili konu aç';

$txt['moveTopic2'] = 'Konunun başlığını değiştir';

$txt['moveTopic3'] = 'Yeni konu';

$txt['moveTopic4'] = 'Tüm iletilerin konu başlığını değiştir';

$txt['move_topic_unapproved_js'] = 'Uyarı! Bu konu henüz onaylanmamıştır.\\n\\nTaşıma işleminden hemen sonra konuyu onaylamayı planlamıyorsanız, konuyu taşımamanız önerilir.';



$txt['theme_template_error'] = '\'%1$s\' adlı tema yüklenemiyor.';

$txt['theme_language_error'] = '\'%1$s\' adlı dil dosyası yüklenemiyor.';



$txt['parent_boards'] = 'Alt Bölümler';



$txt['smtp_no_connect'] = 'SMTP sunucusuna bağlanılamadı';

$txt['smtp_port_ssl'] = 'SMTP bağlantı noktası yanlış; eğer sunucu SSL ise 465 olarak girin.';

$txt['smtp_bad_response'] = 'E-Posta sunucusundan yanıt alınamadı';

$txt['smtp_error'] = 'E-Posta yollanırken hata oluştu: ';

$txt['mail_send_unable'] = '\'%1$s\' adresine e-posta gönderilemedi.';



$txt['mlist_search'] = 'Üyelerde ara';

$txt['mlist_search_again'] = 'Tekrar ara';

$txt['mlist_search_email'] = 'E-Posta adresine göre ara';

$txt['mlist_search_messenger'] = 'MSN adresine göre ara';

$txt['mlist_search_group'] = 'Pozisyona göre ara';

$txt['mlist_search_name'] = 'İsme Göre Ara';

$txt['mlist_search_website'] = 'Web sitesine göre ara';

$txt['mlist_search_results'] = 'Arama sonuçları:';

$txt['mlist_search_by'] = '%1$s göre ara';

$txt['mlist_menu_view'] = 'Üye listesini görüntüle';



$txt['attach_downloaded'] = 'Yükleme:';

$txt['attach_viewed'] = 'Gösterim:';

$txt['attach_times'] = 'kez';



$txt['settings'] = 'Seçenekler';

$txt['never'] = 'Asla';

$txt['more'] = 'daha çok';



$txt['hostname'] = 'Sunucu adı';

$txt['you_are_post_banned'] = 'Üzgünüz %1$s, yasaklı olduğunuz için normal veya kişisel ileti gönderemezsiniz.';

$txt['ban_reason'] = 'Sebep';



$txt['tables_optimized'] = 'Veritabanı tabloları en iyi hale getirildi.';



$txt['add_poll'] = 'Anket ekle';

$txt['poll_options6'] = 'Sadece %1$s adet seçim yapabilirsiniz.';

$txt['poll_remove'] = 'Anketi Kaldır';

$txt['poll_remove_warn'] = 'Konudan anketi kaldırmak istediğinizden emin misiniz?';

$txt['poll_results_expire'] = 'Sonuçlar oylama sona erdiğinde gösterilecektir';

$txt['poll_expires_on'] = 'Oylamanın kapancağı tarih:';

$txt['poll_expired_on'] = 'Oylama kapandı';

$txt['poll_change_vote'] = 'Oyu Kaldır';

$txt['poll_return_vote'] = 'Oylama seçenekleri';

$txt['poll_cannot_see'] = 'Bu anketin sonuçlarını şu anda görüntüleyemezsiniz.';



$txt['quick_mod_approve'] = 'Seçilenleri onayla';

$txt['quick_mod_remove'] = 'Seçilenleri kaldır';

$txt['quick_mod_lock'] = 'Seçilenleri Kilitle/Aç';

$txt['quick_mod_sticky'] = 'Seçilenleri Sabitle/Normalleştir';

$txt['quick_mod_move'] = 'Seçilenleri taşı';

$txt['quick_mod_merge'] = 'Seçilenleri birleştir';

$txt['quick_mod_markread'] = 'Seçilenleri okundu say';

$txt['quick_mod_go'] = 'Git!';

$txt['quickmod_confirm'] = 'Emin misiniz?';



$txt['spell_check'] = 'İmla Kontrolü';



$txt['quick_reply'] = 'Hızlı Yanıt';

$txt['quick_reply_desc'] = '<i>Hızlı yanıt</i>\'ı kullanarak çabukça ileti gönderebilir, iletilerinizde gülümseme ve bbc kullanabilirsiniz.';

$txt['quick_reply_warning'] = 'UYARI: Bu konu Kilitlenmiştir!<br />Sadece yöneticiler yanıt yazabilir.';

$txt['quick_reply_verification'] = 'İletinizi gönderdikten sonra iletinizi doğrulamak için geri gönderileceksiniz: %1$s. ';

$txt['quick_reply_verification_guests'] = '(ziyaretçiler için zorunlu)';

$txt['quick_reply_verification_posts'] = '(%1$d iletiden daha az sayıda ileti göndermiş üyeler için zorunlu) ';

$txt['wait_for_approval'] = 'Not: Bu konu bir moderatör tarafından onaylanmadan görüntülenmeyecektir.';



$txt['notification_enable_board'] = 'Bu bölümde açılacak yeni konulardan haberdar edilmek istediğinize emin misiniz?';

$txt['notification_disable_board'] = 'Bu bölümde açılacak yeni konulardan haberdar edilmeyi iptal etmek istediğinize emin misiniz?';

$txt['notification_enable_topic'] = 'Bu konuya gönderilecek yeni iletilerden haberdar edilmek istediğinize emin misiniz?';

$txt['notification_disable_topic'] = 'Bu konuya gönderilecek yeni iletilerden haberdar edilmeyi iptal etmek istediğinize emin misiniz?';



$txt['report_to_mod'] = 'Moderatöre rapor et';

$txt['issue_warning_post'] = 'Bu ileti sebebiyle uyarı gönder';



$txt['unread_topics_visit'] = 'Okunmamış son konular';

$txt['unread_topics_visit_none'] = 'Son ziyaretinizden beri yeni ileti gönderilmemiştir. <a href="' . $scripturl . '?action=unread;all">Tüm yeni iletileri görüntülemek için tıklayın.</a>';

$txt['unread_topics_all'] = 'Okumadığım tüm konular';

$txt['unread_replies'] = 'Değişiklik Olmuş Konular';



$txt['who_title'] = 'Kimler Çevrimiçi';

$txt['who_and'] = ' ve ';

$txt['who_viewing_topic'] = ' konuyu incelemekte.';

$txt['who_viewing_board'] = ' bölümü incelemekte.';

$txt['who_member'] = 'Üye';



// No longer used by default theme, but for backwards compat

$txt['powered_by_php'] = 'PHP Kullanıyor';

$txt['powered_by_mysql'] = 'MySQL Kullanıyor';

$txt['valid_css'] = 'CSS Uyumlu!';



// Current footer strings

$txt['valid_html'] = 'HTML 4.01 Uyumlu!';

$txt['valid_xhtml'] = 'XHTML 1.0 Uyumlu!';

$txt['wap2'] = 'WAP2';

$txt['rss'] = 'RSS';

$txt['xhtml'] = 'XHTML';

$txt['html'] = 'HTML';



$txt['guest'] = 'Ziyaretçi';

$txt['guests'] = 'Ziyaretçi';

$txt['user'] = 'Üye';

$txt['users'] = 'Üye';

$txt['hidden'] = 'Gizli';

$txt['buddy'] = 'Arkadaş';

$txt['buddies'] = 'Arkadaşlar';

$txt['most_online_ever'] = 'En Çok Çevrimiçi';

$txt['most_online_today'] = 'Bugün En Çok Çevrimiçi';



$txt['merge_select_target_board'] = 'Birleştirilmiş konunun oluşturulacağı bölüm';

$txt['merge_select_poll'] = 'Birleştirilecek konudaki anketi seçin';

$txt['merge_topic_list'] = 'Birleştirilecek konular';

$txt['merge_select_subject'] = 'Birleştirilmiş konunun başlığı';

$txt['merge_custom_subject'] = 'Özel başlık';

$txt['merge_enforce_subject'] = 'Tüm iletilerin başlığın değiştir';

$txt['merge_include_notifications'] = 'Haberdar edilme saklansın?';

$txt['merge_check'] = 'Birleştir?';

$txt['merge_no_poll'] = 'Anket yok';



$txt['response_prefix'] = 'Ynt: ';

$txt['current_icon'] = 'İleti İkonu';

$txt['message_icon'] = 'İleti İkonu';



$txt['smileys_current'] = 'Kullanılan gülümseme seti';

$txt['smileys_none'] = 'Gülümseme yok';

$txt['smileys_forum_board_default'] = 'Forum/Bölüm Standartı';



$txt['search_results'] = 'Arama Sonuçları';

$txt['search_no_results'] = 'Üzgünüz, eşleşen bir sonuç bulunamadı';



$txt['totalTimeLogged1'] = 'Çevrimiçi olunan toplam süre: ';

$txt['totalTimeLogged2'] = ' gün, ';

$txt['totalTimeLogged3'] = ' saat ve ';

$txt['totalTimeLogged4'] = ' dakika.';

$txt['totalTimeLogged5'] = 'gün ';

$txt['totalTimeLogged6'] = 'saat ';

$txt['totalTimeLogged7'] = 'dk';



$txt['approve_thereis'] = 'Şu anda';

$txt['approve_thereare'] = 'Şu anda';

$txt['approve_member'] = 'bir üye';

$txt['approve_members'] = 'üye';

$txt['approve_members_waiting'] = 'onay beklemektedir.';



$txt['notifyboard_turnon'] = 'Bu bölümde yeni bir konu açıldığında e-posta ile uyarı alacaksınız.\\n\\nDevam etmek istiyor musunuz?';

$txt['notifyboard_turnoff'] = 'Artık bu bölüme yeni konular eklendiğinde e-posta ile uyarı almayacaksınız.\\n\\nDevam etmek istiyor musunuz?';



$txt['activate_code'] = 'Aktivasyon kodunuz';



$txt['find_members'] = 'Üye Ara';

$txt['find_username'] = 'Adı, kullanıcı adı, veya e-posta adresi';

$txt['find_buddies'] = 'Sadece Arkadaşları Göster?';

$txt['find_wildcards'] = 'Joker Karakterleri: * ve ?';

$txt['find_no_results'] = 'Hiç sonuç bulunamadı';

$txt['find_results'] = 'Sonuçlar';

$txt['find_close'] = 'Kapat';



$txt['unread_since_visit'] = 'Yeni gönderilen iletileri göster.';

$txt['show_unread_replies'] = 'İletilerime yazılan yeni yanıtları göster.';



$txt['change_color'] = 'Rengi Değiştir';



$txt['quickmod_delete_selected'] = 'Seçilenleri sil';



// In this string, don't use entities. (&amp;, etc.)

$txt['show_personal_messages'] = 'Bir veya daha fazla kişisel ileti aldınız.\\nGörüntülemek istiyor musunuz?';



$txt['previous_next_back'] = '&laquo; önceki';

$txt['previous_next_forward'] = 'sonraki &raquo;';



$txt['movetopic_auto_board'] = '[BÖLÜM]';

$txt['movetopic_auto_topic'] = '[KONU ADRESİ]';

$txt['movetopic_default'] = 'Bu konu ' . $txt['movetopic_auto_board'] . " isimli bölüme taşınmıştır.\n\n" . $txt['movetopic_auto_topic'];



$txt['upshrink_description'] = 'Alanı gizle/göster';



$txt['mark_unread'] = 'Okunmadı say';



$txt['ssi_not_direct'] = 'Lüften SSI.php dosyasına doğrudan URL olarak erişmeyin; SSI fonksiyonuna erişmek istiyorsanız \'?ssi_function=birsey\' yolunu kullanın.';

$txt['ssi_session_broken'] = 'SSI.php oturumu yükleyemedi!  Bu çıkış fonksiyonu veya diğer birkaç fonksiyonların işleyişinde sorunlara sebep olabilir - lütfen SSI.php\'yi içerten kodun sayfanın en başında olduğuna emin olun!';



// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.

$txt['preview_title'] = 'İletiyi önizle';

$txt['preview_fetch'] = 'Önizleme oluşturuluyor...';

$txt['preview_new'] = 'Yeni ileti';

$txt['error_while_submitting'] = 'İleti gönderilirken şu hatalar oluştu:';

$txt['error_old_topic'] = 'Uyarı: bu konuya en az %1$d gündür yanıt gönderilmemiş.<br />Yanıt vermek yerine yeni bir konu açmanız önerilir.';



$txt['split_selected_posts'] = 'Seçili iletiler';

$txt['split_selected_posts_desc'] = 'Aşağıdaki iletiler bölme işlemi tamamlandıktan sonra yeni bir konu oluşturacaklar.';

$txt['split_reset_selection'] = 'seçimi sıfırla';



$txt['modify_cancel'] = 'İptal';

$txt['mark_read_short'] = 'Okunmuş Say';



$txt['pm_short'] = 'İletilerim';

$txt['pm_menu_read'] = 'İletilerinizi Okuyun';

$txt['pm_menu_send'] = 'İleti Gönder';



$txt['hello_member_ndt'] = 'Merhaba';



$txt['unapproved_posts'] = 'Onaylanmamış İletiler (Konular: %1$d, İletiler: %2$d)';



$txt['ajax_in_progress'] = 'Yükleniyor...';



$txt['mod_reports_waiting'] = 'Şu anda %1$d sayıda moderatör raporu bulunmaktadır.';



$txt['view_unread_category'] = 'Okunmamış İletiler';

$txt['verification'] = 'Doğrulama';

$txt['visual_verification_description'] = 'Resimde gördüğünüz harfleri giriniz';

$txt['visual_verification_sound'] = 'Harfleri dinle';

$txt['visual_verification_request_new'] = 'Farklı bir resim göster';



// Sub menu labels

$txt['summary'] = 'Özet';

$txt['account'] = 'Hesap Ayarları';

$txt['forumprofile'] = 'Forum Profili';



$txt['modSettings_title'] = 'Özellikler ve Seçenekler';

$txt['package'] = 'Paket Yöneticisi';

$txt['errlog'] = 'Hata Günlüğü';

$txt['edit_permissions'] = 'İzinler';

$txt['mc_unapproved_attachments'] = 'Onaylanmamış Eklentiler';

$txt['mc_unapproved_poststopics'] = 'Onaylanmamış Konu ve İletiler';

$txt['mc_reported_posts'] = 'Rapor Edilmiş İletiler';

$txt['modlog_view'] = 'Moderasyon Günlüğü';

$txt['calendar_menu'] = 'Takvimi Görüntüle';



//!!! Send email strings - should move?

$txt['send_email'] = 'E-Posta Gönder';

$txt['send_email_disclosed'] = 'Alıcıya görünür olacaktır.';

$txt['send_email_subject'] = 'E-Posta Konusu';



$txt['ignoring_user'] = 'Bu kullanıcıyı yoksayıyorsunuz.';

$txt['show_ignore_user_post'] = 'İletiyi göster.';



$txt['spider'] = 'Örümcek';

$txt['spiders'] = 'Örümcek';

$txt['openid'] = 'OpenID';



$txt['downloads'] = 'İndirilme';

$txt['filesize'] = 'Dosya Boyutu';

$txt['subscribe_webslice'] = 'Webslice\'a Abone Ol';



// Restore topic

$txt['restore_topic'] = 'Konuyu Geri Yükle';

$txt['restore_message'] = 'Eski Haline Getir';

$txt['quick_mod_restore'] = 'Seçilileri Geri Yükle';



// Editor prompt.

$txt['prompt_text_email'] = 'Lütfen e-posta adresini giriniz.';

$txt['prompt_text_ftp'] = 'Lütfen ftp adresini giriniz.';

$txt['prompt_text_url'] = 'Lütfen bağlantı oluşturmak istediğiniz adresi giriniz.';

$txt['prompt_text_img'] = 'Resim konumunu giriniz';



// Escape any single quotes in here twice.. 'it\'s' -> 'it\\\'s'.

$txt['autosuggest_delete_item'] = 'Öğeyi Sil';



// Debug related - when $db_show_debug is true.

$txt['debug_templates'] = 'Temalar: ';

$txt['debug_subtemplates'] = 'Alt Temalar: ';

$txt['debug_language_files'] = 'Dil Dosyaları: ';

$txt['debug_stylesheets'] = 'Sitil Tabloları: ';

$txt['debug_files_included'] = 'Eklenmiş dosyalar: ';

$txt['debug_kb'] = 'KB.';

$txt['debug_show'] = 'Göster';

$txt['debug_cache_hits'] = 'Önbellek Hiti';

$txt['debug_cache_seconds_bytes'] = '%1$ss - %2$s byte';

$txt['debug_cache_seconds_bytes_total'] = '%1$ss e rağmen %2$s byte';

$txt['debug_queries_used'] = '%1$d sorgu kullanıldı.';

$txt['debug_queries_used_and_warnings'] = 'Kullanılan sorgu: %1$d, %2$d uyarı.';

$txt['debug_query_in_line'] = 'dosya: <em>%1$s</em>, satır: <em>%2$s</em> - ';

$txt['debug_query_which_took'] = '%1$s saniye sürdü.';

$txt['debug_query_which_took_at'] = 'toplam %2$s saniyede %1$s saniye sürdü.';

$txt['debug_show_queries'] = 'Sorguları Göster';

$txt['debug_hide_queries'] = 'Sorguları Gizle';

$txt['youtube_default_width'] = 'Varsayılan video genişliği ayarla<div class="smalltext"><strong>0</strong> kullanmak responsive bir görünüm sunar</div>';
$txt['youtube_default_height'] = 'Varsayılan video yüksekliği ayarla<div class="smalltext"><strong>0</strong> kullanmak responsive bir görünüm sunar</div>';
?>