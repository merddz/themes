<?php
// Version: 2.0; ManageMaintenance

// Important! Before editing these language files please read the text at the top of index.english.php.
$txt['repair_zero_ids'] = 'İleti veya Konu ID\'si 0 olan iletiler ve konular bulundu.';
$txt['repair_missing_topics'] = 'İleti #%1$d  var olmayan #%2$d konusuna aittir.';
$txt['repair_missing_messages'] = 'Konu #%1$d herhangi bir ileti bulundurmamaktadır.';
$txt['repair_stats_topics_1'] = 'Konu #%1$d doğru olmayan %2$d ilk ileti ID\'sine sahiptir.';
$txt['repair_stats_topics_2'] = 'Konu %1$d doğru olmayan %2$d son ileti ID\'sine sahiptir.';
$txt['repair_stats_topics_3'] = 'Konu %1$d doğru olmayan %2$d ileti sayısına sahiptir.';
$txt['repair_stats_topics_4'] = 'Konu %1$d doğru olmayan %2$d onaylanmamış ileti sayısına sahiptir.';
$txt['repair_stats_topics_5'] = 'Konu %1$d doğru olmayan onay işaretine sahiptir.';
$txt['repair_missing_boards'] = 'Konu %1$d varolmayan %2$d bölümüne aittir.';
$txt['repair_missing_categories'] = 'Bölüm %1$d varolmayan %2$d kategorisine aittir.';
$txt['repair_missing_posters'] = 'İleti %1$d varolmayan üye %2$d tarafından gönderilmiştir.';
$txt['repair_missing_parents'] = 'Bölüm #%1$d varolmayan #%2$d bölümünün bir alt bölümüdür.';
$txt['repair_missing_polls'] = 'Konu #%1$d varolmayan #%2$d anketi ile ilişkilendirilmiştir.';
$txt['repair_polls_missing_topics'] = '#%1$d , anket olmayan bir konuya bağlanmış #%2$d.';
$txt['repair_missing_calendar_topics'] = '#%1$d başlıklı olay varolmayan #%2$d başlıklı konuyla ilişkilendirilmiş.';
$txt['repair_missing_log_topics'] = 'Varolmayan konu #%1$d birden çok kişi için okunmuş olarak işaretlidir.';
$txt['repair_missing_log_topics_members'] = 'Varolmayan üye #%1$d birden çok iletiyi okunmuş olarak işaretlemiştir.';
$txt['repair_missing_log_boards'] = 'Varolmayan bölüm #%1$d birden çok kişi için okunmuş olarak işaretlidir.';
$txt['repair_missing_log_boards_members'] = 'Varolmayan üye #%1$d birden çok bölümü okunmuş olarak işaretlemiştir.';
$txt['repair_missing_log_mark_read'] = 'Varolmayan bölüm #%1$d birden çok kişi için okunmuş olarak işaretlidir.';
$txt['repair_missing_log_mark_read_members'] = 'Varolmayan üye #%1$d birden çok bölümü okunmuş olarak işaretlemiştir.';
$txt['repair_missing_pms'] = 'Varolmayan kişisel ileti #%1$d birden çok kişiye gönderilmiştir.';
$txt['repair_missing_recipients'] = 'Varolmayan üye #%1$d birden çok kişisel ileti almıştır.';
$txt['repair_missing_senders'] = 'Varolmayan kişisel ileti #%1$d varolmayan üye #%2$d tarafından gönderilmiştir.';
$txt['repair_missing_notify_members'] = 'Varolmayan üye #%1$d, tarafından istenen haberdar edilmeler bulunmaktadır.';
$txt['repair_missing_cached_subject'] = '#%1$d konusunun başlığı başlık önbelleğinde kayıtlı değildir.';
$txt['repair_missing_topic_for_cache'] = 'Önbellekte bulunan \'%1$s\' kelimesi varolmayan bir konuya bağlıdır.';
$txt['repair_missing_log_poll_member'] = '#%1$d anketine varolmayan #%2$d üyesi tarafından oy verilmiştir.';
$txt['repair_missing_log_poll_vote'] = '#%1$d üyesi tarafından varolmayan #%2$d anketine oy verilmiştir.';
$txt['repair_missing_thumbnail_parent'] = 'Ana resmi var olmayan %1$s başlıklı bir küçük resim bulunmuştur.';
$txt['repair_report_missing_comments'] = '#%1$d konusuna ait rapora ait yorum bulunmamaktadır.';
$txt['repair_comments_missing_report'] = '#%1$d rapor yorumu, %2$s tarafından gönderilmiştir ve ait olduğu rapor yoktur.';
$txt['repair_group_request_missing_member'] = 'Silinmiş üye #%1$d için halen bir grup isteği bulunmaktadır.';
$txt['repair_group_request_missing_group'] = 'Silinmiş grup #%1$d için halen bir grup isteği bulunmaktadır..';

$txt['repair_currently_checking'] = 'Kontrol Ediliyor: &quot;%1$s&quot;';
$txt['repair_currently_fixing'] = 'Tamir Ediliyor: &quot;%1$s&quot;';
$txt['repair_operation_zero_topics'] = 'Alanı (id_topic) 0 olarak ayarlanmış konular';
$txt['repair_operation_zero_messages'] = 'Alanı (id_topic) 0 olarak ayarlanmış iletiler';
$txt['repair_operation_missing_topics'] = 'Konu girdisi kayıp iletileri';
$txt['repair_operation_missing_messages'] = 'İletisi olmayan konular';
$txt['repair_operation_stats_topics'] = 'Yanlış ilk veya son iletisi kaydına sahip konular';
$txt['repair_operation_stats_topics2'] = 'Yanlış yanıt sayısına sahip konular';
$txt['repair_operation_stats_topics3'] = 'Yanlış onaylanmamış ileti sayısına sahip konular';
$txt['repair_operation_missing_boards'] = 'Varolmayan bölümlerdeki konular';
$txt['repair_operation_missing_categories'] = 'Varolmayan kategorilerdeki bölümler';
$txt['repair_operation_missing_posters'] = 'Varolmayan üyelere bağlı iletiler';
$txt['repair_operation_missing_parents'] = 'Varolmayan bölümlere bağlı alt bölümler';
$txt['repair_operation_missing_polls'] = 'Varolmayan anketlere bağlı konular';
$txt['repair_operation_missing_calendar_topics'] = 'Varolmayan konulara bağlı olaylar';
$txt['repair_operation_missing_log_topics'] = 'Varolmayan konulara bağlı konu kayıtları';
$txt['repair_operation_missing_log_topics_members'] = 'Varolmayan üyelere bağlı konu kayıtları';
$txt['repair_operation_missing_log_boards'] = 'Varolmayan bölümlere bağlı bölüm kayıtları';
$txt['repair_operation_missing_log_boards_members'] = 'Varolmayan üyelere bağlı bölüm kayıtları';
$txt['repair_operation_missing_log_mark_read'] = 'Varolmayan bölümlere bağlı okunmuş say verisi';
$txt['repair_operation_missing_log_mark_read_members'] = 'Varolmayan üyelere bağlı okunmuş say verisi';
$txt['repair_operation_missing_pms'] = 'Ana iletisi kayıp Kişisel İleti alıcıları';
$txt['repair_operation_missing_recipients'] = 'Silinmiş üyelere gönderilmiş kişisel iletiler';
$txt['repair_operation_missing_senders'] = 'Varolmayan üyelere bağlı kişisel iletiler';
$txt['repair_operation_missing_notify_members'] = 'Varolmayan üyelere bağlı haberdar edilme kayıtları';
$txt['repair_operation_missing_cached_subject'] = 'Arama önbelleği verisi kayıp konular';
$txt['repair_operation_missing_topic_for_cache'] = 'Varolmayan konulara bağlı arama önbellek verisi';
$txt['repair_operation_missing_member_vote'] = 'Varolmayan üyelere bağlı anket oyları';
$txt['repair_operation_missing_log_poll_vote'] = 'Varolmayan anketlere bağlı anket oyları';
$txt['repair_operation_report_missing_comments'] = 'Yorumu olmayan konu raporları';
$txt['repair_operation_comments_missing_report'] = 'Konu raporları olmayan rapor yorumları';
$txt['repair_operation_group_request_missing_member'] = 'Talepte bulunan üyesi kayıp üye grupları';
$txt['repair_operation_group_request_missing_group'] = 'Varolmayan gruplar için üyelik talepleri';

$txt['salvaged_category_name'] = 'Kurtarma Alanı';
$txt['salvaged_category_error'] = 'Kurtarma Alanı kategorisi oluşturulamadı!';
$txt['salvaged_board_name'] = 'Kurtarılan Konular';
$txt['salvaged_board_description'] = 'Konusu var olmayan iletiler için oluşturulmuş kurtarma konuları';
$txt['salvaged_board_error'] = 'Kurtarılmış Konular bölümü oluşturulamadı!';
$txt['salvaged_poll_topic_name'] = 'Kurtarılmış Anket';
$txt['salvaged_poll_message_body'] = 'Bu anketin konusu bulunmuyor.';

$txt['database_optimize'] = 'Veritabanını İyileştir';
$txt['database_numb_tables'] = 'Veritabanınızda %1$d tablo bulunmaktadır.';
$txt['database_optimize_attempt'] = 'Veritabanınız iyileştirilmeye çalışılıyor...';
$txt['database_optimizing'] = '%1$s İyileştiriliyor... %2$01.2f kb iyileştirildi.';
$txt['database_already_optimized'] = 'Tüm tablolar zaten iyileştirilmiş.';
$txt['database_opimize_unneeded'] = 'Herhangi bir tablonun iyileştirilmesi gerekli görülmedi.';
$txt['database_optimized'] = ' tablo iyileştirildi.';
$txt['database_no_id'] = 'varolmayan üye ID\'sine sahip';

$txt['apply_filter'] = 'Filtreyi Uygula';
$txt['applying_filter'] = 'Filtre Uygulanıyor';
$txt['filter_only_member'] = 'Sadece bu üyeye ait hata iletilerini görüntüle';
$txt['filter_only_ip'] = 'Sadece bu IP Adresine ait hata iletilerini görüntüle';
$txt['filter_only_session'] = 'Sadece bu oturuma ait hata iletilerini görüntüle';
$txt['filter_only_url'] = 'Sadece bu URL\'ye ait hata iletilerini görüntüle';
$txt['filter_only_message'] = 'Sadece aynı iletiye ait hata iletilerini görüntüle';
$txt['session'] = 'Oturum';
$txt['error_url'] = 'Hataya yol açan sayfanın adresi';
$txt['error_message'] = 'Hata iletisi';
$txt['clear_filter'] = 'Filtre oluştur';
$txt['remove_selection'] = 'Seçilileri Kaldır';
$txt['remove_filtered_results'] = 'Tüm Filtrelenmiş Sonuçları kaldır';
$txt['sure_about_errorlog_remove'] = 'Tüm hata iletilerini kaldırmak istediğinizden emin misiniz?';
$txt['reverse_direction'] = 'Listenin kronolojik sıralamasını ters çevir';
$txt['error_type'] = 'Hata türü';
$txt['filter_only_type'] = 'Sadece bu türdeki hataları göster';
$txt['filter_only_file'] = 'Sadece bu dosyaya ait hataları göster';
$txt['apply_filter_of_type'] = 'Bu filtreyi uygula';

$txt['errortype_all'] = 'Tüm hatalar';
$txt['errortype_general'] = 'Genel';
$txt['errortype_general_desc'] = 'Bir tür içersine kategorize edilmemiş genel hatalar';
$txt['errortype_critical'] = '<span style="color:red;">Kritik</span>';
$txt['errortype_critical_desc'] = 'Kritik hatalar. Bu hatalar olabildiğince çabuk çözülmelidirler.  Bu hataların görmezden görülmesi forumunuzun çökmesine veya forum güvenliğinin tehlikeye girmesine sebep olabilir.';
$txt['errortype_database'] = 'Veritabanı';
$txt['errortype_database_desc'] = 'Bozuk sorgular yüzünden oluşan veritabanı hataları. Bu hatalar SMF ekibine iletilmelidir.';
$txt['errortype_undefined_vars'] = 'Tanımlanmamış';
$txt['errortype_undefined_vars_desc'] = 'Tanımlanmamış değişkenlerin kullanımından kaynaklanan hatalar.';
$txt['errortype_template'] = 'Tema';
$txt['errortype_template_desc'] = 'Temaların yüklenmesi ile ilgili hatalar.';
$txt['errortype_user'] = 'Kullanıcı';
$txt['errortype_user_desc'] = 'Kullanıcı hatalardan kaynaklanan hatalardır.  Örneğin yanlış parolalar, yasaklı olunmasına rağmen giriş girişimi veya erişim izni olunmayan yerlere erişim girişimleri.';

$txt['maintain_recount'] = 'Tüm Forum Toplamlarını ve İstatistiklerini Tekrar Hesapla';
$txt['maintain_recount_info'] = 'Olası bir \'ileti sayım\' veya \'toplam kişisel ileti sayım\' hatasında : bu fonksiyon sizin için kaydedilmiş sayı ve istatistikleri tekrar sayar';
$txt['maintain_errors'] = 'Hataları bul ve varsa düzelt';
$txt['maintain_errors_info'] = 'Örneğin, eğer server hataları sonucunda bazı iletiler ve konular eksilmişse , bu fonksiyon bulunmasına yardım edecektir';
$txt['maintain_logs'] = 'Gereksiz Kayıtları Temizle';
$txt['maintain_logs_info'] = 'Bu fonksiyon gereksiz logları temizliyecek. Bir sorun olmadıkça bu işlemden kaçınılmalıdır, fakat her hangi bir şeye zarar vermez';
$txt['maintain_cache'] = 'Dosya Önbelleğini Temizle';
$txt['maintain_cache_info'] = 'Ne sebeple olursa olsun, eğer ara belleğin temizlenmesi gerekiyorsa, bu link tam aradığınız işlevi gösterir.';
$txt['maintain_optimize'] = 'Tüm tabloları iyileştir';
$txt['maintain_optimize_info'] = 'Bu görev tüm tabloları en uygun hale getirmenizi sağlar. Efektleri ; Ek yüklerden kurtularak , tabloların boyutların küçülerek forumun hızlanmasını sağlar.';
$txt['maintain_version'] = 'Dosyaları Güncel Sürümleriyle Karşılaştır';
$txt['maintain_version_info'] = 'Bu bakım görevi size forum dosyalarınızın sürümü hakkında detaylı bilgi verecek ve resmi sitedeki liste ile karşılaştıracaktır ';
$txt['maintain_run_now'] = 'Görevi Çalıştır';
$txt['maintain_return'] = 'Forum Bakımına Geri Dön';

$txt['maintain_backup'] = 'Veritabanını Yedekle';
$txt['maintain_backup_info'] = 'Acil durumlar için veritabanınızın bir yedeğini indirin.';
$txt['maintain_backup_struct'] = 'Tablo yapısını kaydet.';
$txt['maintain_backup_data'] = 'Tablo verisini(lerini) kaydet. (Önemli!)';
$txt['maintain_backup_gz'] = 'Gzip sıkıştırması kullan.';
$txt['maintain_backup_save'] = 'İndir';

$txt['maintain_old'] = 'Eski İletileri Temizle';
$txt['maintain_old_since_days1'] = '';
$txt['maintain_old_since_days2'] = ' günden eski şu iletileri temizle:';
$txt['maintain_old_nothing_else'] = 'Herhangi bir konu.';
$txt['maintain_old_are_moved'] = 'Taşınma bilgilendirme konuları.';
$txt['maintain_old_are_locked'] = 'Kilitli konular.';
$txt['maintain_old_are_not_stickied'] = 'Sabit konuları sayma.';
$txt['maintain_old_all'] = 'Tüm Bölümler (belirli bölümleri seçmek için tıkla)';
$txt['maintain_old_choose'] = 'Belli Bölümleri Seç (tümünü seçmek için tıkla)';
$txt['maintain_old_remove'] = 'Kaldır';
$txt['maintain_old_confirm'] = 'Eski iletileri temizlemek istediğinizden emin misiniz?\\n\\nBu işlem geri alınamaz!';

$txt['maintain_members'] = 'Aktif Olmayan Üyeleri Temizle';
$txt['maintain_members_ungrouped'] = 'Gruplandırılmamış Üyeler <span class="smalltext">(Herhangi bir üye grubuna dahil olmayan üyeler)</span>';
$txt['maintain_members_since1'] = '';
$txt['maintain_members_since2'] = ' şu tarihten eski';
$txt['maintain_members_since3'] = ' tüm üyeleri temizle.';
$txt['maintain_members_activated'] = 'Üyeliklerini aktifleştirmemiş';
$txt['maintain_members_logged_in'] = 'Giriş yapmamış';
$txt['maintain_members_all'] = 'Tüm Üye Grupları';
$txt['maintain_members_choose'] = 'Seçili Üye Grupları';
$txt['maintain_members_confirm'] = 'Aktif olmayan üyeleri temizlemek istediğinizden emin misiniz?\\n\\nBu işlem geri alınamaz!';

$txt['utf8_title'] = 'Veritabanını ve Veriyi UTF-8\'e Dönüştür';
$txt['utf8_introduction'] = 'UTF-8 uluslararası bir karakter seti olup neredeyse varolan tüm dilleri içermektedir. Veritabanınızı ve verinizi UTF-8\'e dönüştürmek forum\'unuzda birden fazla dili desteklemeyi daha kolay kılacaktır. Ayrıca latin alfabesinde olmayan aramalar ve sıralamalarda daha doğru sonuçlar elde edilebilmesini sağlayacaktır.';
$txt['utf8_warning'] = 'Veri ve veritabanınızı UTF-8\'e dönüştürmeden önce aşağıdaki üç maddeyi okumanız önerilir:
<ul class="normallist">
	<li>Karakter setlerini dönüştürmek veriniz için <em>tehlikeli</em> olabilir! Dönüştürme işleminden <i>önce</i> veritabanınızın yedeğini aldığınızdan emin olunuz.</li>
	<li>UTF-8 diğer karakter setlerinden daha zengin olduğu için, <strong>geriye dönüş yoktur</strong>. Ancak yedek aldıysanız, yedek aldığınız tarihteki hale dönüş mümkündür.</li>
	<li>Veri ve veritabanınızı UTF-8\'e dönüştürdükten sonra, UTF-8 uyumlu dil dosyalarını edinip etkinleştirmeniz gerekecektir.</li>
</ul>';
$txt['utf8_charset_not_supported'] = '%1$s dilinden UTF-8\'e dönüşüm desteklenmemektedir.';
$txt['utf8_detected_charset'] = 'Dil dosyanız (\'%1$s\') olduğu için, karakter setiniz muhtemelen \'%2$s\' olacaktır.';
$txt['utf8_already_utf8'] = 'Veritabanı ve veriniz zaten UTF-8 olarak depolanmaktadır. Dönüştürme işlemine gerek yoktur.';
$txt['utf8_source_charset'] = 'Verinin karakter seti';
$txt['utf8_proceed'] = 'Devam Et';
$txt['utf8_database_charset'] = 'Veritabanı karakter seti';
$txt['utf8_target_charset'] = 'Dönüştürülecek karakter seti';
$txt['utf8_utf8'] = 'UTF-8';
$txt['utf8_db_version_too_low'] = 'Veritabanını sunucunuzun kullandığı MySQL sürümü UTF-8\'i desteklememektedir. En az 4.1.2 olmalıdır.';
$txt['utf8_cannot_convert_fulltext'] = 'İleti tablonuz  tam-metin içerik arama metodunu kullanmaktadır. UTF-8 çevirme işlemine içerik silinmedikçe devam edemessiniz. Çevirme işlemi tamamlandıktan sonra içeriği tekrar oluşturabilirsiniz';

$txt['entity_convert_title'] = 'HTML elemanlarını UTF-8 karakterlere dönüştür';
$txt['entity_convert_only_utf8'] = 'HTML elemanlarının dönüştürülebilmesi için öncelikle veritabanının UTF-8 biçminde olması gereklidir.';
$txt['entity_convert_introduction'] = 'Bu fonksiyon veritabanında saklanan tüm HTML elemanları UTF-8 karakterlere çevirecektir. Bu özellik veritabanını ISO-8859-1 gibi latin bir karakter setinden UTF-8\'e dönüştürenler fakat veritabanında latin olmayan karakterler bulunduranlar için gereklidir. Tarayıcı tüm karakterleri HTML elemanlar olarak gönderir. Örneğin, HTML elemanı &amp;#945; yunanca harf &#945; (alfa) yı temsil eder. Elemanların UTF-8\'e dönüştürülmesi arama ve sıralama verimliliğini artıracak ve alandan kazanç sağlatacaktır.';
$txt['entity_convert_proceed'] = 'Devam Et';

// Move topics out.
$txt['move_topics_maintenance'] = 'Konuları Taşı';
$txt['move_topics_select_board'] = 'Bölüm Seç';
$txt['move_topics_from'] = 'Taşıma İşlemi:';
$txt['move_topics_to'] = '->';
$txt['move_topics_now'] = 'Şimdi Taşı';
$txt['move_topics_confirm'] = '&quot;%board_from%&quot; bölümündeki TÜM konuları &quot;%board_to%&quot; bölümüne taşımak istediğinize emin misiniz?';

$txt['maintain_reattribute_posts'] = 'Kullanıcı İletilerini İlişkilendir';
$txt['reattribute_guest_posts'] = 'Şu şekilde gönderilmiş ziyaretçi iletilerini';
$txt['reattribute_email'] = 'E-Posta';
$txt['reattribute_username'] = 'Kullanıcı Adı';
$txt['reattribute_current_member'] = 'Üye ile ilişkilendir';
$txt['reattribute_increase_posts'] = 'İleti sayısını güncelle';
$txt['reattribute'] = 'İlişkilendir';
// Don't use entities in the below string.
$txt['reattribute_confirm'] = '"%find%" (%type%) tarafından gönderilmiş tüm iletileri "%member_to%" üyesiyle ilişkilendirmek istediğinize emin misiniz?';
$txt['reattribute_confirm_username'] = 'kullanıcı adı';
$txt['reattribute_confirm_email'] = 'e-posta adresi';
$txt['reattribute_cannot_find_member'] = 'İlişkilendirilecek üye bulunamadı.';

?>