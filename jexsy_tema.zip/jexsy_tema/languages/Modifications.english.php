<?php
// Version: 2.0; Modifications

	$txt['mentions'] = 'Etiketlenmeler';
	$txt['scheduled_task_removeMentions'] = 'Remove seen mentions';
	$txt['scheduled_task_desc_removeMentions'] = 'Automatically removes seen mentions older than the specified days';
	
?>